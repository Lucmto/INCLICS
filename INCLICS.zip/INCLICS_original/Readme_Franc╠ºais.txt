Ce logiciel est le fruit des recherches r�alis�es par Luc Yannick Andr�as Randriamarolaza � l'Universit� de Rovira i Virgili, Tarragona, Espagne.

Pour lancer ce logiciel, il faut pr�parer un fichier appel� "stations.txt" qui contient la liste des stations suivant le mod�le ci-dessous.

ID	STAT_NAME	LATITUDE	LONGITUDE	ALTITUDE	COUNTRY
22138	Ambohitsilaozana	-17.7	48.5	786	MG
32022	Analalava	-14.6	47.8	57	MG
21011	Antalaha	-15	50.3	6	MG
34155	Antananarivo	-18.9	47.5	1310	MG

Puis pr�parer les donn�es journali�res de chaque station sous le format Rclimdex (voir aussi exemple ci-dessous) et l'enregistrer avec son ID. Par exemple, les donn�es ci-dessous sont observ�es au niveau de la station d'Antananarivo donc on l'enregistre sous "34155.txt"

1950	01	01	1.5	24.5	17.1
1950	01	02	18.5	26	18.7
1950	01	03	41.1	25.9	16.7
1950	01	04	13.8	25.6	17.8
1950	01	05	20.6	26.2	17.6
1950	01	06	6.7	25.3	18.3
1950	01	07	0	26.7	16.4
1950	01	08	0	25.7	17.5
1950	01	09	0	25.8	16.5
1950	01	10	0.1	24.9	17.9
1950	01	11	0	25.8	16.4
1950	01	12	34.7	27.6	17.4
1950	01	13	0	25.2	18.6
1950	01	14	0.3	22.6	18.9
1950	01	15	2.3	23.8	18.5
1950	01	16	0	27.5	19.2
1950	01	17	0	27	20.3
1950	01	18	60.8	26.3	19.2

Enfin, le fichier "stations.txt" et les donn�es des stations sont plac�es dans le dossier "Controle_Qualite". Ouvrir le fichier "INCLICS.Rmd" dans Rstudio, puis "run" pour lancer le logiciel.



