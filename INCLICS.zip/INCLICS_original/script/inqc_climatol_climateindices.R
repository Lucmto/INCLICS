### THIS CODE IS MADE by LUC RANDRIAMAROLAZA, ENRIC AGUILAR and JOSE GUIJJARO, Centre for Climate Change, C3, URV, Tarragona, Spain - Directorate General of Meteorology, Madagascar, Agencia Estatal de Meteorología (AEMET), Spain  
### It is provided free under the terms of the GNU Lesser General Public License as published by the Free Software Foundation,
# version 3.0 of the License. It is distributed under the terms of this license 'as-is' and has not been designed or prepared to meet any Licensee's particular requirements. 
# The author and its institution make no warranty, either express or implied, including but not limited to, warranties of merchantability or fitness for a particular
# purpose. In no event will they will be liable for any indirect, special, consequential or other damages attributed to the Licensee's use of The Library. 
# In downloading The Library you understand and agree to these terms and those of the associated LGP License. See the GNU Lesser General Public License for more details.
# <http://www.gnu.org/licenses/lgpl.html> or contact the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

###### missing data #####
library(DataCombine)

miss1<-function(y){
  
  ka<-read.table(as.character(y),header = F,na.strings = c('-99.9','','-999.9'))
  tab<-seq.Date(as.Date(paste(ka$V1[1],ka$V2[1],ka$V3[1],sep = '-')),as.Date(paste(ka$V1[nrow(ka)],ka$V2[nrow(ka)],ka$V3[nrow(ka)],sep = '-')),
                by='day')
  if(nrow(ka)!=length(tab)){
    id<-which(!(tab %in% as.Date(paste(ka$V1,ka$V2,ka$V3,sep = '-'))))
    for(i in id){
      ka<-InsertRow(ka,NewRow = c(matrix(as.numeric(as.character(unlist(strsplit(as.character(tab[i]),'-')))),ncol=3,byrow=T),rep(-99.9,3)),
                    RowNum = i)
    }
  }
  return(ka)
  
}
###
######### Cumulated anommalies method####
calculation<-function(x,sta='',conf.lev=0.95,N=1000,anarana='./'){
  
  dat<-miss1(x)
  
  if(length(which(sta < 0))==length(sta)){
    hemi_sud=T
  }else{
    hemi_sud=F
  }
  
  
  BB=unique(dat[,1])
  LL=length(BB)
  
  
  daty<-as.Date(paste(dat[,1],dat[,2],dat[,3],sep="-"))
  
  jour<-c(31,28,31,30,31,30,31,31,30,31,30,31)
  
  # init<-rep(NA,3)
  val<-array(NA,c(LL,2))
  i<-1
  for ( year in BB[1]:BB[LL]){ 
    
    #######################################################################
    #compute onset
    
    if(hemi_sud){
      fst.date<-as.Date(paste(year,"-8-1",sep=""))
      fst.date2<-as.Date(paste(year,"-12-31",sep=""))
    }else{
      fst.date<-as.Date(paste(year,"-1-1",sep=""))
      fst.date2<-as.Date(paste(year,"-5-31",sep=""))
    }
    
    id<-which(daty>=fst.date & daty<=fst.date2)
    
    don<-dat[id,4]
    ons<-onset(don,conf.lev,N)
    if(ons$is.onset){
      debut<-as.character(fst.date+ons$onset.index)
      conf.lev.o<-ons$onset.confidence*100
    }else{
      debut<-'NA'
      conf.lev.o<-ons$onset.confidence*100
    }
    
    ######################################################################
    #compute withdraw
    
    if(hemi_sud){
      fst.date1<-as.Date(paste(year+1,"-3-1",sep=""))
      fst.date3<-as.Date(paste(year+1,"-7-31",sep=""))
    }else{
      fst.date1<-as.Date(paste(year,"-8-1",sep=""))
      fst.date3<-as.Date(paste(year,"-12-31",sep=""))
    }
    id1<-which(daty>=fst.date1 & daty<=fst.date3)
    
    don1<-dat[id1,4]
    with<-withdraw(don1,conf.lev,N)
    if(with$is.withdraw){
      fin<-as.character(fst.date1+with$withdraw.index)
      conf.lev.w<-with$withdraw.confidence*100
    }else{
      fin<-'NA'
      conf.lev.w<-with$withdraw.confidence*100
    }
    val[i,1]<-as.character(debut)
    val[i,2]<-as.character(fin)
    i<-i+1
  }
  if(file.exists(anarana)) {file.remove(anarana)}
  
  write.table(t(c('Debut','Fin')),anarana,append = T,col.names = F,row.names = F,quote = F,sep='\t')
  write.table(val,anarana,append = T,col.names = F,row.names = F,quote = F,sep='\t')
  #return(val)
  id<-which(val[,1]=='NA')
  # 
  if(length(id) !=0){
    debut<-format(mean(as.Date(paste(format(Sys.Date(), "%Y"),matrix(unlist(strsplit(val[-id,1],'-')),ncol=3,byrow = T)[,-1][,1],
                                     matrix(unlist(strsplit(val[-id,1],'-')),ncol=3,byrow = T)[,-1][,2],sep = '-')),na.rm=TRUE),'%b-%d')
  }else{
    debut<-format(mean(as.Date(paste(format(Sys.Date(), "%Y"),matrix(unlist(strsplit(val[,1],'-')),ncol=3,byrow = T)[,-1][,1],
                                     matrix(unlist(strsplit(val[,1],'-')),ncol=3,byrow = T)[,-1][,2],sep = '-')),na.rm=TRUE),'%b-%d')
  }
  
  id<-which(val[,2]=='NA')
  if(length(id) !=0){
    fin<-format(mean(as.Date(paste(format(Sys.Date(), "%Y"),matrix(unlist(strsplit(val[,2],'-')),ncol=3,byrow = T)[,-1][,1],
                                   matrix(unlist(strsplit(val[-id,2],'-')),ncol=3,byrow = T)[,-1][,2],sep = '-')),na.rm=TRUE),'%b-%d')
  }else{
    fin<-format(mean(as.Date(paste(format(Sys.Date(), "%Y"),matrix(unlist(strsplit(val[,2],'-')),ncol=3,byrow = T)[,-1][,1],
                                   matrix(unlist(strsplit(val[,2],'-')),ncol=3,byrow = T)[,-1][,2],sep = '-')),na.rm=TRUE),'%b-%d')
  }
  
  write.table(t(c(debut,fin)),anarana,append = T,col.names = F,row.names = F,quote = F,sep='\t')
  
}
####### long-term mean #####
Smean<-function(x){
  moy<-mean(x,na.rm=T)
  return(moy)
}

### cumul sum calculation ####
Sfun<-function(x){
  
  y<-x-mean(x,na.rm=T)
  y[is.na(y)]<-0
  S<-cumsum(y)
  Sdiff<-max(S)-min(S)
  S<-abs(S)
  idx <- which(S == max(S))
  return(c(idx[1],Sdiff))
}
######## Bootstrapping to calculate confidence level #####
CLfun<-function(x,N){
  Sdiff<-Sfun(x)[2]
  res <- lapply(1:N, function(i) sample(x))
  Sdiff0<- sapply(res, Sfun)
  Nhit<-length(which(Sdiff0[2,]<Sdiff))
  CL<-Nhit/N
  return(CL)
}
###### rainy season onset #####
#onset<-function(x,conf.lev=0.95,N){
onset<-function(x,conf.lev,N){
  cl<-CLfun(x,N)
  ch.pt<-Sfun(x)
  if(cl>=conf.lev){
    return(list(is.onset=TRUE,onset.index=ch.pt[1],onset.confidence=cl))
  }
  else{
    return(list(is.onset=FALSE,onset.index=ch.pt[1],onset.confidence=cl))
  }
}
#### rainy season cessation ##### 
#withdraw<-function(x,conf.lev=0.95,N){
withdraw<-function(x,conf.lev,N){
  cl<-CLfun(x,N)
  ch.pt<-Sfun(x)
  if(cl>=conf.lev){
    return(list(is.withdraw=TRUE,withdraw.index=ch.pt[1],withdraw.confidence=cl))
  }
  else{
    return(list(is.withdraw=FALSE,withdraw.index=ch.pt[1],withdraw.confidence=cl))
  }
}
########## nomination des zones climatiques #########
station_new<-function(chemin='.',entete='QC_',stat=dat,dir.out='./../spcc/'){
  if(file.exists(paste0(dir.out,'stations.txt'))) file.remove(paste0(dir.out,'stations.txt'))
  for(id in stat$ID){
    ind<-which(stat$ID==id)
    done<-read.table(paste0(chemin,'normals_',entete,id,'.txt'),header = T)
    tot<-sum(done$RR)
    if(tot < 250) ZONE<-'Saharaneienne'
    if(tot >= 250 & tot < 500) ZONE<-'Sahelienne'
    if(tot >= 500 & tot < 900) ZONE<-'Soudano_sahelienne'
    if(tot >= 900 & tot < 1100) ZONE<-'Soudanienne'
    if(tot >= 1100) ZONE<-'Guineenne'
    write.table(cbind(stat[ind,],ZONE),paste0(dir.out,'stations.txt'),col.names = F,row.names = F,quote=T,append = T)
  }
}
#### cartographie des stations ####
shape<-function(chemin='~/Documents/Tchad/script/'){
  ff<-list.files(chemin,'shp')
  shp<-readOGR(paste0(chemin,ff))
  return(shp)
}

mnt<-function(chemin='~/Documents/Tchad/script/'){
  #ff<-list.files(chemin,'grd')
  ff<-list.files(chemin,'img')
  dem<-raster(paste0(chemin,ff))
  dem[dem < 0]<-NA
  return(dem)
}

####
def_indice<-function(chemin='~/Documents/Tchad/climate_indices/',langue='Français'){
  dind<-read.table(paste0(chemin,'/definicion_indices_',langue,'.txt'),header = F,as.is = T)
  dind<-as.data.frame(dind)
  return(dind)
}

####
miss<-function(ka){
  tab<-seq.Date(as.Date(paste(ka$V1[1],ka$V2[1],ka$V3[1],sep = '-')),as.Date(paste(ka$V1[nrow(ka)],ka$V2[nrow(ka)],ka$V3[nrow(ka)],sep = '-')),
                by='day')
  if(nrow(ka)!=length(tab)){
    id<-which(!(tab %in% as.Date(paste(ka$V1,ka$V2,ka$V3,sep = '-'))))
    for(i in id){
      ka<-InsertRow(ka,NewRow = c(matrix(as.numeric(as.character(unlist(strsplit(as.character(tab[i]),'-')))),ncol=3,byrow=T),rep(-99.9,3)),
                    RowNum = i)
    }
  }
  return(ka)
  
}
#######
# plot_carte<-function(chemin='~/Documents/Tchad/script/',dem,shp,dat,pts){
plot_carte<-function(chemin='~/Documents/Tchad/script/',dem,dat,shp){
  jpeg(file=paste0(chemin,"carte.jpeg"),width = 1500, height = 1500)
  breakpoints <- seq(0,4000,500)
  colours <- topo.colors(length(breakpoints))
  shp<-shp[shp$COUNTRY == dat$COUNTRY[1],]
  dem<-crop(dem,extent(shp))
  arg <- list(at=breakpoints, labels = breakpoints ,cex.axis=2,lwd=2,font=2)
  plot(dem,col=colours,breaks=breakpoints,font=2,font.lab=2,cex.lab=1.5,cex.axis=1.5,horizontal = TRUE,
       legend.width=1, legend.shrink=0.75,axis.args=arg,
       legend.args=list(text='Elevation (m)', side=3, font=2, line=1, cex=2))
 myproj <- "+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"
 proj4string(dem) <- CRS(myproj)
 shp = spTransform(shp, crs(dem))
 plot(shp,add=T,lwd=2)
  par(new=T)
  pts<-as.data.frame(cbind(as.numeric(as.character(dat$LONGITUDE)),as.numeric(as.character(dat$LATITUDE))))
  colnames(pts)<-c("X","Y")
  coordinates(pts)<-~X+Y
  proj4string(pts) <- CRS(myproj)
  pts = spTransform(pts, crs(dem))
  plot(pts,pch=16,col="red",add=TRUE,cex=3,font=2)
  par(new=T)
  text(pts$X, pts$Y, labels=dat$STAT_NAME, cex= 3,pos=1,font=2,col='black')
  dev.off()
}

#######
plot_jpeg = function(path, add=FALSE,titre='')
  ### modified from https://stackoverflow.com/questions/9543343/plot-a-jpg-image-using-base-graphics-in-r
{
  require('jpeg')
  jpg = readJPEG(path, native=T) # read the file
  res = dim(jpg)[2:1] # get the resolution, [x, y]
  if (!add) # initialize an empty plot area if add==FALSE
    plot(1,1,xlim=c(1,res[1]),ylim=c(1,res[2]),asp=1,type='n',xaxs='i',yaxs='i',xaxt='n',yaxt='n',xlab='',ylab='',bty='n',main=titre)
 rasterImage(jpg,1,1,res[1],res[2])
}

indice<-function(chemin='~/Documents/Tchad/climate_indices/',langue='Français'){
  ind<-read.table(paste0(chemin,'/indices_',langue,'.txt'),header = F,as.is = T)
  ind<-as.data.frame(ind)
  return(ind)
}
station<-function(chemin='~/Documents/Tchad/Controle_Qualite/'){
don<-read.table(paste0(chemin,'/stations.txt'),as.is = T)
don<-don[-1,]
colnames(don)<-c('ID','STAT_NAME','LATITUDE','LONGITUDE','ALTITUDE','COUNTRY')
don<-as.data.frame(don)
return(don)
}
                   

transform<-function(stationlist='madagascar_stations.csv'){
if(!dir.exists(paste0('raw'))){dir.create(paste0('raw'))}
colnamestx<-c('SOUID',    'DATE',   'TX', 'Q_TX')
colnamestn<-c('SOUID',    'DATE',   'TN', 'Q_TN')
colnamesrr<-c('SOUID',    'DATE',   'RR', 'Q_RR')
colnamesstations<-c('STAID','STANAME','CN','LON','LAT','HGHT')

stats<-read.table(stationlist,na.strings='-99.9',header = T)
n<-nrow(stats)
for(i in 1:n){
filename<-paste0(as.character(stats$ID[i]),'.txt')
if(file.exists(filename)){
y<-read.table(filename,na.strings='-99.9')
y<-miss(y)
y[,4]<-round(suppressWarnings(as.numeric(y[,4])),1)
y[,5]<-round(y[,5],1)
y[,6]<-round(y[,6],1)

date<-as.numeric(paste0(y[,1],sprintf("%02d",y[,2]),sprintf("%02d",y[,3])))

RR<-data.frame(i,as.numeric(date),as.numeric(y[,4])*10,0);RR[which(is.na(RR[,3])),4]<-9;names(RR)<-colnamesrr  
TX<-data.frame(i,as.numeric(date),as.numeric(y[,5])*10,0);TX[which(is.na(TX[,3])),4]<-9;names(TX)<-colnamestx    
TN<-data.frame(i,as.numeric(date),as.numeric(y[,6])*10,0);TN[which(is.na(TN[,3])),4]<-9;names(TN)<-colnamestn
write.table(RR,paste0('raw/RR_STAID',sprintf("%06d",stats$ID[i]),'.txt'),sep=',',col.names=TRUE,row.names = FALSE, quote=FALSE,na='-9999')
write.table(TX,paste0('raw/TX_STAID',sprintf("%06d",stats$ID[i]),'.txt'),sep=',',col.names=TRUE,row.names = FALSE, quote=FALSE,na='-9999')
write.table(TN,paste0('raw/TN_STAID',sprintf("%06d",stats$ID[i]),'.txt'),sep=',',col.names=TRUE,row.names = FALSE, quote=FALSE,na='-9999')
}}

stats[,7]<-stats$ID
stats[,8]<-stats$STAT_NAME
stats[,9]<-stats$COUNTRY
stats[,10]<-sapply(stats$LONGITUDE, dex2sex)
stats[,11]<-sapply(stats$LATITUDE, dex2sex)
stats[,12]<-stats$ALTITUDE
stits<-stats[,7:12];names(stits)<-colnamesstations
write.table(stits,'raw/stations.txt',sep=',',col.names=TRUE,row.names=FALSE,quote=FALSE)
}

dex2sex <- function(angle){
# modified from  https://github.com/gkonstantinoudis/GeoSwiss/blob/master/R/180709_dex2sex.R thanks :-)  
  ## Extract DMS
  if(angle < 0){nyu<-TRUE;angle = angle*-1}else{nyu=FALSE}
  angle_chr <- as.character(angle)
  deg <- as.numeric(strsplit(angle_chr, "\\.")[[1]][1])
  min <- as.numeric(strsplit(as.character((angle-deg)*60), "\\.")[[1]][1])
  sec <- round((((angle-deg)*60) - min) * 60)
  sec<-sprintf("%02d",sec)
  min<-sprintf("%02d",min)
  
  ## Result in seconds
  if(nyu){deg<-deg*-1}
  return(paste(deg,min,sec,sep=':'))
  
}

reform<-function(homefolder='~/Documents/Tchad/Controle_Qualite/',stationlist='madagascar_stations.csv',txlevel=1,tnlevel=1,rrlevel=1){

stats<-read.table(paste0(homefolder,stationlist),na.strings='-99.9',header = T)  
n<-nrow(stats)
for(i in 1:n){
nameRR<-paste0(homefolder,'QCConsolidated/RR_STAID',sprintf("%06d",stats$ID[i]),'.txt')  
nameTX<-paste0(homefolder,'QCConsolidated/TX_STAID',sprintf("%06d",stats$ID[i]),'.txt')  
nameTN<-paste0(homefolder,'QCConsolidated/TN_STAID',sprintf("%06d",stats$ID[i]),'.txt')  
RR<-read.csv(nameRR,header=FALSE,skip=2)[,3:5];names(RR)<-c('date','RR','QC_RR')
TX<-read.csv(nameTX,header=FALSE,skip=2)[,3:5];names(TX)<-c('date','TX','QC_TX')
TN<-read.csv(nameTN,header=FALSE,skip=2)[,3:5];names(TN)<-c('date','TN','QC_TN')
RR[,2]<-round(RR[,2]/10,1)
RR[which((RR[,3] !=0 &  RR[,3] <= rrlevel) | RR[,3] == 9) ,2]<--99.9

TX[,2]<-round(TX[,2]/10,1)
TX[which((TX[,3] !=0 &  TX[,3] <= txlevel) | TX[,3] == 9) ,2]<--99.9

TN[,2]<-round(TN[,2]/10,1)
TN[which((TN[,3] !=0 &  TN[,3] <= tnlevel) | TN[,3] == 9) ,2]<--99.9



cdx<-merge(RR[,1:2],TX[,1:2],all=TRUE)
cdx<-merge(cdx,TN[,1:2],all=TRUE)
cdx$year<-as.numeric(substring(cdx[,1],1,4))
cdx$month<-as.numeric(substring(cdx[,1],5,6))
cdx$day<-as.numeric(substring(cdx[,1],7,8))
cdx<-cdx[,c(5,6,7,2,3,4)]
namecdx<-paste0('QC_',stats$ID[i],'.txt')
write.table(cdx,paste0(homefolder,namecdx),sep='\t',col.names=FALSE,row.names=FALSE,quote=FALSE,na='-99.9')
}  
if(!dir.exists('./../spcc/donnees/')){dir.create('./../spcc/donnees/',recursive = T)}
if(!dir.exists('./../climate_indices/donnees/')){dir.create('./../climate_indices/donnees/',recursive = T)}
file.copy(list.files(homefolder,pattern = 'QC_'),'./../spcc/donnees/',overwrite = T)
file.copy(list.files(homefolder,pattern = 'QC_'),'./../climate_indices/donnees/',overwrite = T)
}


help_console <- function(topic, format=c("text", "html", "latex", "Rd"),
                         lines=NULL, before=NULL, after=NULL) {  
  
  # taken from https://www.r-bloggers.com/2013/06/printing-r-help-files-in-the-console-or-in-knitr-documents/
  # thanks :-)
  
  format=match.arg(format)
  if (!is.character(topic)) topic <- deparse(substitute(topic))
  helpfile = utils:::.getHelpFile(help(topic))
  hs <- capture.output(switch(format, 
                              text=tools:::Rd2txt(helpfile),
                              html=tools:::Rd2HTML(helpfile),
                              latex=tools:::Rd2latex(helpfile),
                              Rd=tools:::prepare_Rd(helpfile)
  )
  )
  if(!is.null(lines)) hs <- hs[lines]
  hs <- c(before, hs, after)
  cat(hs, sep="\n")
  invisible(hs)
}

QCsummary<-function(homefolder='~/Documents/Tchad/Controle_Qualite/',element='RR'){
  sta<-read.table(paste0(homefolder,'/stations.txt'),header = F)
  liste<-c('0','1','2','3','4','9')
    i<-1
    ff<-list.files(path=paste0(homefolder,'/QCSummary/'),pattern = element)
    res<-as.data.frame(matrix(NA,nrow=length(ff),ncol=length(liste)+1))
    for(nom in ff){
      don<-NULL
      dat<-read.table(paste0(homefolder,'/QCSummary/',nom))
      nr<-nrow(dat)
      id<-which(dat[,1]=='QC_Code')
      id1<-liste %in% dat[(id+1):nr,1]
      don[id1 == TRUE]<-as.character(dat[(id+1):nr,2])
      don[id1 == FALSE]<-0
      don<-matrix(unlist(don),ncol=length(liste),nrow=1)
      anar<-strsplit(matrix(unlist(strsplit(nom,'_')),ncol=2,nrow=1)[,2],'.txt')
      if(length(ff) < 10){
        n<-0
      }
      if(length(ff) >=10 & length(ff) < 100){
        n<-1
      }
      if(length(ff) >= 100 & length(ff) < 1000){
        n<-2
      }
      
      don<-cbind(sta[substring(anar,nchar(anar)-n,nchar(anar)),4],don)
      for(j in 1:ncol(don)){
        res[i,j]<-don[1,j]
      }
    }
    colnames(res)<-c('QC_Code','0','1','2','3','4','9')
  return(res)
}

# Créer le fichier station pour Climatol

preparation<-function(deb=1983,fin=2020){
  dts=seq(as.Date(paste0(deb,'-01-01')),as.Date(paste0(fin,'-12-31')),by='1 day') 
  nd=length(dts) #nombre de jours dans la période
  dfd=data.frame(date=dts)
  #lire la liste des stations:
  ds=read.table('./../Controle_Qualite/stations.txt',header=TRUE,as.is=TRUE) 
  ne=nrow(ds) #nombre de stations
  #ouvrir les fichiers pour enregistrer les données:
  F1=file(paste0('RR_',deb,'-',fin,'.dat'),'w') 
  F2=file(paste0('TX_',deb,'-',fin,'.dat'),'w') 
  F3=file(paste0('TN_',deb,'-',fin,'.dat'),'w')
  for(i in 1:ne) { #pour chaque station:
   cat(i,'') 
    df=read.table(sprintf('./../Controle_Qualite/QC_%d.txt',ds[i,1]),na.strings=c('-99.9','-999.9'))
    df<-miss(df)
    dd=data.frame(date=as.Date(sprintf('%d-%02d-%02d',df[,1],df[,2],df[,3])),df[,4:6])
    df=merge(dfd,dd,by='date',all.x=TRUE) #affecter les données à ses dates
    write(df$V4,F1) #enregistrer les données de précipitation
    write(df$V5,F2) #enregistrer les données de température maximal
    write(df$V6,F3) #enregistrer les données de température minimale
  }
  
  close(F1)
  close(F2)
  close(F3)
  
  #enregistrer les fichiers des estations:
  if(file.exists(paste0('RR_',deb,'-',fin,'.est'))) { file.remove(paste0('RR_',deb,'-',fin,'.est'))}
  if(file.exists(paste0('TX_',deb,'-',fin,'.est'))) { file.remove(paste0('TX_',deb,'-',fin,'.est'))}
  if(file.exists(paste0('TN_',deb,'-',fin,'.est'))) { file.remove(paste0('TN_',deb,'-',fin,'.est'))}
  write.table(ds[,c(4,3,5,1,2)],paste0('RR_',deb,'-',fin,'.est'),row.names=F,col.names=F) 
  file.copy(paste0('RR_',deb,'-',fin,'.est'),paste0('TX_',deb,'-',fin,'.est')) 
  file.copy(paste0('RR_',deb,'-',fin,'.est'),paste0('TN_',deb,'-',fin,'.est'))
}

getDistance<-function(lat1,lon1,lat2,lon2) {
   R = 6371 #Radius of the earth in km
  dLat = deg2rad(lat2-lat1) #deg2rad below
  dLon = deg2rad(lon2-lon1) 
  a = sin(dLat/2) * sin(dLat/2) + cos(deg2rad(lat1)) * cos(deg2rad(lat2)) * 
    sin(dLon/2) * sin(dLon/2)
  c = 2 * atan2(sqrt(a), sqrt(1-a))
  d = R * c # Distance in km
  return(d)
}

deg2rad<-function(deg) {
  return(deg * (pi/180))
}
##### new staff #######

##### test des données manquantes ####
manquantes<-function(deb=1983,fin=2020){
  for(para in c('RR','TX','TN')){
    home<-try(homogen(para,deb,fin,gp=1),silent = TRUE)
    if(inherits(home,'try-error')){
      next
    }
  }
}
#### conversion decimal ##
my_fun <- function(k){
    a <- gsub(",", ".", k, fixed = TRUE)
    b <- as.numeric(a)
  return(b)
}


###### homogenisation ########
homogenisation<-function(deb=1983,fin=2020){
  ######## preparation de station de référence #####
  ll<-list.files('.','ClimateEngine')
  if(length(ll) != 0){
    i<-1
    k<-1
    for(j in seq(3,length(ll),3)){
      for(nom in ll[i:j]){
        title<-read.csv(nom,nrows = 1,header = F,sep = ';')
        
        matches <- as.matrix(unlist(re_matches(title$V2,
                                               rex(
                                                 "(",
                                                 capture(name = "text", except_any_of(")")),
                                                 ")"),
                                               global = TRUE)),ncol=2,nrow=2)
        
        id <- which(str_detect(title$V2,c('Prec','Max','Min')))
        if(id==1) file.rename(nom,paste0('ref',k,'-',matches[2,1],'.csv'))
        if(id==2) file.rename(nom,paste0('ref',k,'-',matches[2,1],'-TX.csv'))
        if(id==3) file.rename(nom,paste0('ref',k,'-',matches[2,1],'-TN.csv'))
      }
      i<-i+j
      k<-k+1
    }
  }
  
for(para in c('RR','TX','TN')){
    # données journalières en données mensuelles et homogénisation de données mensuelles puis de données journalières
  
    if(para == 'RR'){
 ll<-list.files('./../homogenisation/','CHIRPS')
        if(length(ll)!=0){
          ds=read.table('./../Controle_Qualite/stations.txt',header=TRUE,as.is=TRUE)
          for(nom in ll){
            title<-read.csv(nom,nrows = 1,header = F,sep=';')
            d<-read.csv(nom,as.is = T,sep = ";")
            dd=data.frame(date=seq(as.Date(paste0(deb,'-01-01')),as.Date(paste0(fin,'-12-31')),1))
            df=data.frame(date=as.Date(d[,1]),val=my_fun(d[,2]))
            df=merge(dd,df,by='date',all.x=T)
            write(paste0('',df$val),paste0(para,'_',deb,'-',fin,'.dat'),append=T)
            
            i<-as.numeric(substr(nom,unlist(gregexpr('f',nom))+1,unlist(gregexpr('-',nom))-1))
            longitude<-substr(title$V2,unlist(gregexpr(as.character('at'),as.character(title$V2)))[length(unlist(gregexpr(as.character('at'),as.character(title$V2))))]+3,
                              unlist(gregexpr('E,',title$V2))-1)
            latitude<-substr(title$V2,unlist(gregexpr('E,',title$V2))+2,unlist(gregexpr(as.character('N,'),as.character(title$V2)))-1)
            altitude<-ds$ALTITUDE[which.min(getDistance(ds$LATITUDE,ds$LONGITUDE,as.numeric(latitude),as.numeric(longitude)))]
            teny<-paste0(as.character(longitude),' ',as.character(latitude),' ',as.character(altitude),' *rf',i,' *Référence_',i)
            
            write(teny,paste0(para,'_',deb,'-',fin,'.est'),append = T)
          }
        }
          dd2m(para,deb,fin,valm=1)
          homogen(paste0(para,'-m'),deb,fin,std=2,nref=1,dz.max=10,force=TRUE)
          homogen(para,deb,fin,std=2,metad=T,force=TRUE,dz.max=10,nref=1)
          }else{
            ##### minimum and maximum temperatures ####
   ll<-list.files('./../homogenisation/',paste0('ERA5-',para))
        if(length(ll)!=0){
          ds=read.table('./../Controle_Qualite/stations.txt',header=TRUE,as.is=TRUE)
          for(nom in ll){
            title<-read.csv(nom,nrows = 1,header = F,sep=';')
            d<-read.csv(nom,as.is = T,sep=';')
            dd=data.frame(date=seq(as.Date(paste0(deb,'-01-01')),as.Date(paste0(fin,'-12-31')),1))
            df=data.frame(date=as.Date(d[,1]),val=my_fun(d[,2]))
            df=merge(dd,df,by='date',all.x=T)
            write(paste0('',df$val),paste0(para,'_',deb,'-',fin,'.dat'),append=T)
            
            i<-as.numeric(substr(nom,unlist(gregexpr('f',nom))+1,unlist(gregexpr('-',nom))-1))
            longitude<-substr(title$V2,unlist(gregexpr(as.character('at'),as.character(title$V2)))[length(unlist(gregexpr(as.character('at'),as.character(title$V2))))]+3,
                              unlist(gregexpr('E,',title$V2))-1)
            latitude<-substr(title$V2,unlist(gregexpr('E,',title$V2))+2,unlist(gregexpr(as.character('N,'),as.character(title$V2)))-1)
            altitude<-ds$ALTITUDE[which.min(getDistance(ds$LATITUDE,ds$LONGITUDE,as.numeric(latitude),as.numeric(longitude)))]
            teny<-paste0(as.character(longitude),' ',as.character(latitude),' ',as.character(altitude),' *rf',i,' *Référence_',i)
            write(teny,paste0(para,'_',deb,'-',fin,'.est'),append = T)
          }
        }
          dd2m(para,deb,fin)
          homogen(paste0(para,'-m'),deb,fin,nref=1,std=1,dz.max=10,force=TRUE)
          homogen(para,deb,fin,nref=1,metad=T,std=1,dz.max=10,force=TRUE)
      }
    }
  # corriger les erreurs tx < tn avant de sauvegarder les données homogénéisées sous le format RClimdex
  load(paste0('TX_',deb,'-',fin,'.rda')); tx=dah[,1:nei]
  load(paste0('TN_',deb,'-',fin,'.rda')); tn=dah[,1:nei]
  k=which(tx<tn)
  length(k)
  
  z=tx[k]; tx[k]=tn[k]; tn[k]=z #échanger les mauvaises données
  #enregistrez à nouveau les fichiers de résultats:
  load(paste0('TX_',deb,'-',fin,'.rda')); dah[,1:nei]=tx
  save(dat,dah,est.c,nd,ne,nei,nm,x,ndec,std,ini, file=paste0('TX_',deb,'-',fin,'.rda'))
  load(paste0('TN_',deb,'-',fin,'.rda')); dah[,1:nei]=tn
  save(dat,dah,est.c,nd,ne,nei,nm,x,ndec,std,ini, file=paste0('TN_',deb,'-',fin,'.rda'))
  
  climatol2rclimdex(varRR = 'RR',varTX = 'TX',varTN = 'TN',deb,fin)
  if(length(list.files('.',pattern = 'rf'))!=0) file.remove(list.files('.',pattern = 'rf'))
  if(!dir.exists('./../spcc/donnees/')){dir.create('./../spcc/donnees/',recursive = T)}
  if(!dir.exists('./../climate_indices/donnees/')){dir.create('./../climate_indices/donnees/',recursive = T)}
  file.copy(list.files('.',pattern = 'hoclm'),'./../spcc/donnees/',overwrite = T)
  file.copy(list.files('.',pattern = 'hoclm'),'./../climate_indices/donnees/',overwrite = T)
}

#### Indices climatiques ##### 

objectclimdex<-function(infolder='./',prefix='hoclm',outfolder='./climdexobject',mindata=1000,NH=FALSE,
                        base1=1971,base2=2000){
  if(!require(climdex.pcic)){install.packages('climdex.pcic')}
  library(climdex.pcic)  
  if(!dir.exists(outfolder)){dir.create(outfolder)}
  nyu<-nchar(outfolder)
  if(substring(outfolder,nyu,nyu)!='/'){outfolder<-paste0(outfolder,'/')} #genious
  if(!dir.exists(infolder)){return('Infolder does not exist')}
  
  nyu<-nchar(infolder)
  if(substring(infolder,nyu,nyu)!='/'){infolder<-paste0(infolder,'/')} #genious
  
  stats<-list.files(path=infolder,pattern=prefix)
  n<-length(stats)
  if(n == 0){print('No input files available');stop()}
  for(i in 1:n){
    nombre<-unlist(strsplit(stats[i],'.',fixed=TRUE))[1]
    x<-read.table(paste0(infolder,stats[i]),na.strings='-99.9')
    date<-paste(sprintf("%04d",x[,1]) ,sprintf("%02d",x[,2]),sprintf("%02d",x[,3]),sep='-')
    
    txdate<-as.PCICt(date,cal='gregorian')
    tndate<-as.PCICt(date,cal='gregorian')
    rrdate<-as.PCICt(date,cal='gregorian')
    
    #browser()
    largorr<-length(which(!is.na(x[,4])));if(largorr<mindata){rr=NULL;rrdate=NULL}else{rr=x[,4]}
    largotn<-length(which(!is.na(x[,6])));if(largotn<mindata){tn=NULL;tndate=NULL}else{tn=x[,6]}
    largotx<-length(which(!is.na(x[,5])));if(largotx<mindata){tx=NULL;txdate=NULL}else{tx=x[,5]}

    deldeseo<-climdexInput.raw(tmax=tx,tmin=tn,prec=rr,tmax.dates=txdate,tmin.dates = tndate,prec.dates=rrdate,
                               northern.hemisphere=FALSE,base.range=c(base1,base2))
    saveRDS(deldeseo,file=paste0(outfolder,nombre,'.rds'))
  }
}

computeclimdex<-function(prefix='hoclm',outfolder='./climdexindices',infolder='./climdexobject',
                         plotfolder='./climindplot'){
  
  if(!require(climdex.pcic)){install.packages('climdex.pcic')}
  library(climdex.pcic)  
  if(!dir.exists(outfolder)){dir.create(outfolder)}
  nyu<-nchar(outfolder)
  if(substring(outfolder,nyu,nyu)!='/'){outfolder<-paste0(outfolder,'/')} #genious
  if(!dir.exists(infolder)){dir.create(infolder)}
  nyu<-nchar(infolder)
  if(substring(infolder,nyu,nyu)!='/'){infolder<-paste0(infolder,'/')} #genious
  
  if(!dir.exists(plotfolder)){dir.create(plotfolder)}
  nyu<-nchar(plotfolder)
  if(substring(plotfolder,nyu,nyu)!='/'){plotfolder<-paste0(plotfolder,'/')} #genious
  
  
  stats<-list.files(path=infolder,pattern=prefix)
  n<-length(stats)
  if(n == 0){print('No input files available');stop()}
  for(i in 1:n){
    nombre<-unlist(strsplit(stats[i],'.',fixed=TRUE))[1]
    print(nombre)
    
    x<-readRDS(paste0(infolder,nombre,'.rds'))
    available<-climdex.get.available.indices(x, function.names = TRUE)
    ix<-length(available)
    for(j in 1:ix){
      
      nyi<-eval(parse(text=paste0(available[j],'(x)')))
      fecha<-names(nyi);index<-as.vector(nyi)
      indice<-data.frame(Date=fecha,Value=index)
      if(nchar(fecha[1])==4){tag='_ANN_'}else{tag='_MON_'}
      indexname<-paste0(outfolder,nombre,tag,available[j],'.txt')
      plotname<-paste0(plotfolder,nombre,tag,available[j],'.jpg')
      
      write.csv(indice,indexname,quote=FALSE,row.names=FALSE,na='-99.9')
      if(tag=='_ANN_'){plotindex(indice,indexname,plotname)}
    }
    annuals<-c("climdex.txn",'climdex.txx','climdex.tnn','climdex.tnx','climdex.tx90p','climdex.tx10p',
               'climdex.tn90p','climdex.tn10p','climdex.dtr','climdex.rx1day','climdex.rx5day')
    n<-length(annuals)
    for(j in 1:n){
      nyi<-eval(parse(text=paste0(annuals[j],'(x,freq="annual")')))
      fecha<-names(nyi);index<-as.vector(nyi)
      indice<-data.frame(Date=fecha,Value=index)
      indexname<-paste0(outfolder,nombre,'_ANN_',annuals[j],'.txt')
      plotname<-paste0(plotfolder,nombre,'_ANN_',annuals[j],'.jpg')
      write.csv(indice,indexname,quote=FALSE,row.names=FALSE,na='-99.9')
      plotindex(indice,indexname,plotname)
    }
  }
}

#### Koppen ###
iternormRCL=function(infolder='./',outfolder='./koppen',prefix='hoclm',fyear=1900,lyear=2200,mindata=10000){
  # OBJECTIVE: iterates from list the production of normals
  
  if(!dir.exists(outfolder)){dir.create(outfolder)}
  nyu<-nchar(outfolder)
  if(substring(outfolder,nyu,nyu)!='/'){outfolder<-paste0(outfolder,'/')} #genious
  
  if(!dir.exists(infolder)){return('infolder does not exist!')}
  nyu<-nchar(infolder)
  if(substring(infolder,nyu,nyu)!='/'){infolder<-paste0(infolder,'/')} #genious
  
  
  listo<-list.files(path=infolder,pattern=prefix)
  
  j<-length(listo)
  for (i in 1:j){
    plotty<-unlist(strsplit(listo[i],'.',fixed=TRUE))[1]
    print(noquote(paste('Working with series ',listo[i],sep='')))
    series<-read.table(paste0(infolder,listo[i]),na.strings=c('-99.9','-99.90'))		
    target<-which(series[,1] >= fyear & series[,1] <= lyear)
    series<-series[target,]
    good<-length(which(!is.na(series[,4]) & !is.na(series[,5]) & !is.na(series[,6])))
    if(good >= mindata){
      bocata<-normy(series,paste0(outfolder,plotty,'.jpg'),paste0(outfolder,'normals_',listo[i]))
    }
  }
  
}

normy<-function(series,filena='climograma.jpg',outnorm=climograma.txt){
  
  # OBJECTIVE: uses an RClimdex formatted series to compute a climogram and produce a climograph. 
  # PARAMETERS:
  # $series: an RClidmex formatted series
  # OUTPUT
  # $salida: the climate normals (tx,tn,tm,pc). Each variable is preceeded by another column with 1:12,
  # as needed by the function preparing the climogram
  # CALLS: 
  # Calls daytomonth, climograma (and produces all its objects) and koppen (and produces all its objects). 
  
  print('Doing precip!')
  pcm<-daytomonth(series[,1],series[,2],series[,4],compile=2)
  pcnorm<-calnorm(pcm)
  print('Doing tx!')
  txm<-daytomonth(series[,1],series[,2],series[,5])
  txnorm<-calnorm(txm)
  print('Doing tn!')
  tnm<-daytomonth(series[,1],series[,2],series[,6])
  tnnorm<-calnorm(tnm)
  print('Doing tm!')
  tm<-(series[,5]+series[,6])/2
  tmm<-daytomonth(series[,1],series[,2],tm)
  tmnorm<-calnorm(tmm)
  salida<-cbind(txnorm,tnnorm,tmnorm,pcnorm) # this is in the order requested by climogram Function 
  pepe<-climograma(salida[,6],salida[,8],fitxer=filena,titol=filena)
  pepito<-koppen(pepe)
  salida<-cbind(txnorm,tnnorm,tmnorm,pcnorm) # this is in the order requested by climogram Function 
  salida<-data.frame(salida[,c(1,2,4,6,8)])
  names(salida)<-c('Month','TX','TN','TM','RR')
  write.table(salida,outnorm,sep='\t',quote=FALSE,col.names=TRUE,row.names = FALSE)
}

koppen=function(tmnormal,pcnormal,ccut=-3){
  # Objectiu: determinar el tipus climatic de KOPPEN a partir d'un objecte generat per climograma
  # PARAMETRES:
  # ccut: Gabler situa el tall C/D en 0; Ahrens en -3
  # climodata: objecte generat per climograma
  if(length(which(!is.na(tmnormal)))!=12){return('Manquen dades per classificar')}
  if(length(which(!is.na(pcnormal)))!=12){return('Manquen dades per classificar')}
  pacum<-sum(pcnormal)
  anual<-mean(tmnormal)
  maxanual<-max(tmnormal)
  minanual<-min(tmnormal)	
  
  # Es polar? 
  if(maxanual<0){return('EF')} # Casquet
  if(maxanual<10 & maxanual>0){return('ET')} # Tundra
  # No polar? Determinem "p" per saber si es un clima "B"
  p<-2*anual+14 ## precipitacio repartida tot l'any
  orden<-order(tmnormal,decreasing=T) ## busca els sis mesos mes calids (1 a 6 d'orden)
  warmrain<-sum(pcnormal[orden[1:6]])/pacum*100	
  if(warmrain >= 70){ # 70 per cent o mes de la precipitacio cau en els mesos d'estiu
    p<-2*anual+28
  }
  coolrain<-sum(pcnormal[orden[7:12]])/pacum*100
  if(coolrain >= 70){ # 70 per cent o mes de la precipitacio cau en els mesos d'hivern 
    p<-2*anual
  }
  
  if( p/2>pacum/10){ # Desert
    # Es un clima tipus BW, necessitem determinar el subtipus
    if(anual >=18){return('BWh')}else{return('BWk')}
    
  }
  if( p>pacum/10){ # Estepa
    # Es un clima tipus BS, necessitem determinar el subtipus
    if(anual >=18){return('BSh')}else{return('BSk')}
  }
  # Si no polar i no sec, es tropical?
  
  if(minanual>=18){ # Tropical
    if(min(pcnormal)>=60){return('Af')}
    cutpoint<-10-pacum/250
    if(min(pcnormal)<60 & min(pcnormal)< cutpoint){return('Aw')}	
    if(min(pcnormal)<60 & min(pcnormal)>= cutpoint){return('Am')}	
  }
  
  ### Preparing Seasonality of the precipitation (second letter of middle latitudes)
  
  if(orden[1]>5 & orden[1]<10){summer=c(6,7,8);winter=c(1,2,12)}else{summer=c(1,2,12);winter=c(6,7,8)}
  wetsu<-max(pcnormal[summer])		
  drywi<-min(pcnormal[winter])
  second<-'f' # if the next conditions are not met, rains all year
  if(wetsu/drywi>=10){second='w'} # Dry winters
  if(min(pcnormal[summer]/10<4) & max(pcnormal[winter])>min(pcnormal[summer]*3)){second='s'} # Dry summers
  
  ### Preparing summer qualification (third letter)
  
  mas10<-length(which(tmnormal>10))
  if(maxanual >= 22 & mas10 >=4){third='a'}		
  if(maxanual < 22 & mas10 >=4){third='b'}			
  if(maxanual < 22 & mas10 <4 & mas10 > 0){third='c'}
  if(minanual < -38){third='d'}		
  # Si no es polar, ni sec, ni tropical, es mesotermic?
  if(minanual<18 & minanual >= ccut){ # Mesotermic # Achtuuung! Ahrens Says -3
    elregreso<-paste('C',second,third,sep='')
    return(elregreso)
  }
  
  if(minanual < ccut & maxanual > 10){ # Microtermic
    elregreso<-paste('D',second,third,sep='')
    return(elregreso)
    return('No Classificable')	
  }
}

##################### KOPPEN ZONE ######

climograma<-function(tmnormal,pcnormal,titol='Climograma',position='topleft',fitxer='climograma.jpg') # realitza un climograma 
{
  # PARAMETRES
  # tmnormal serie de tempeartures mitjanes normals
  # pcnormal: serie de precipitació normal
  # titol: titol de la serie
  # position: posicio de la llegenda. Un de "bottomright", "bottom", "bottomleft","left", "topleft", "top", "topright", "right" o "center"
  # fitxer: nom del fitxer de sortida
  jpeg(fitxer) # REDIRIGEIX OUTPUT A JPG
  plot.new= TRUE # COMENCEM UNA GRAFICA NOVA
  
  meses <- c("J","F","M","A","M","J","J","A","S","O","N","D")
  
  titulo <- titol
  anual<-round(mean(tmnormal,na.rm=TRUE),1)
  range<-round(max(tmnormal,na.rm=TRUE)-min(tmnormal,na.rm=TRUE),1)
  pacum<-round(sum(pcnormal,na.rm=TRUE),1)
  
  subtitol=paste('Tm Year: ',round(anual,1),' C. Range: ',round(range,1), ' C. Annual Acum Precip: ', pacum,' mm.', sep='')
  mintemp<-round(min(tmnormal,na.rm=TRUE)-1)*2
  maxtemp<-round(max(tmnormal,na.rm=TRUE)+1)*2
  criterio=max(maxtemp,max(pcnormal,na.rm=TRUE))
  valores<-seq(mintemp,criterio,length.out=10)
  if(valores[1]!=0){valores[1]=valores[1]-valores[1]%%10-10}
  if(valores[10]!=0){valores[10]=valores[10]-valores[10]%%10+10}
  valores<-seq(valores[1],valores[10],by=10)
  sortida<-list(tmnormal=tmnormal,pcnormal=pcnormal,anual=anual,range=range,pacum=pacum)
  tipo<-koppen(tmnormal,pcnormal)
  dev.off
  x<-barplot(pcnormal, axes = FALSE, main = '' , sub=paste(subtitol,'.Tipo: ',tipo,sep=''),
             ylim=c(min(valores[1],0),valores[length(valores)]),cex.main=0.5,cex.sub=1,adj=0,col='skyblue2',font=2)
  
  
  precval<-subset(valores,valores >= 0)
  
  ### new to try to avoid weird axis when precip is low (does not work)
  if(precval[1]!=0){precval=seq(0,max(precval),10)}
  
  axis(side=4, at = precval, lab=round(precval))
  axis(side=2, at = valores, lab = round(valores/2))
  axis(side=1, at = x, lab = meses)	
  
  lines(x,tmnormal*2,col="red",lwd=3)
  points(x,tmnormal*2,col="red",cex=2,pch=19)
  
  legend(x=position,legend=c("TM","PC"),lty=c(1,1),lwd=c(2,4),col=c("red","skyblue2"),cex=0.75)
  
  dev.off()
}

##########
daytomonth=function(x,y,z,feos='NA',allow=5,compile=1,write=0,filename='monthly.txt'){
  # OBJECTIVE: computes monthly series from rclimdex-style data
  # and places the result in nx13 grid
  # PARAMETERS: 
  # x: vector with year values
  # y: vector with month values
  # z: vector with data
  # feos: missing value
  # allow: percentage of missing tolerated to compute the mean
  # compile: how will you compile the monthly vals: 1 = mean; 2 = sum
  # write: 1 will produce a data file; other will do nothing
  # filename: filename to be used if write is 1
  # RETURNS:
  # t: nx13 monthly means grid
  datos<-cbind(x,y,z)
  diasmes<-c(31,28,31,30,31,30,31,31,30,31,30,31)
  x1<-min(x,na.rm=TRUE) # first year
  x2<-max(x,na.rm=TRUE) # second year
  x3<-x2-x1+1 # number of years
  t<-array(dim=c(x3,13))
  t[,1]<-x1:x2	
  
  for(i in x1:x2){
    #		print(i)
    for(j in 1:12){
      #			print(j)
      validos<-subset(datos[,3],datos[,1]==i & datos[,2]==j & datos[,3]!=feos)
      if(j==2 & i%%4==0 & i!=1900){bisiesto=1}else{bisiesto=0}
      contraste<-diasmes[j]+bisiesto
      permiso<-contraste-round(allow*contraste/100,0)
      if(length(validos)>0){	
        if(permiso<=length(validos)){
          if(compile==1){valor<-mean(validos,na.rm=TRUE)}
          if(compile==2){valor<-sum(validos,na.rm=TRUE)}
        }else{valor<-NA}
      }else{valor<-NA}
      fila<-i-x1+1
      columna<-j+1
      if(!is.na(valor)){t[fila,columna]<-round(valor,1)}else{t[fila,columna]<-NA} # not necessary. Learned NA rounds to NA!!!
    }
    
  }
  
  if(write==1){write.table(t,file=filename,quote = FALSE, sep = '\t',row.names = FALSE,col.names = FALSE,na='-999.9')}
  return(t)
}
#######
calnorm<-function(series,pany=1971,fany=2000,perdua=5,fitxer='normals.txt'){ # calcula normals a partir de series mensuals
  
  # PARAMETRES
  # series: serie: serie de dades en format grid (13 files x n columnes, primera columna any
  # fitxer: nom del fitxer per escritura de dades. Defecte: normals.txt	
  # pany: primer any pel calcul de normals (passat). Per defecte = 1971
  # fany: darrer any pel calcul de normals (present). Per defecte = 2000
  # perdua: percentatge de valors perduts per comput de normal. Defecte, 5.
  
  normals<-apply(series[,2:13],2,mean,na.rm=T) 
  for(k in 2:13){ 
    dummy<-series[,k]
    presents<-which(!is.na(dummy))  
    presents<-length(presents)     
    potencials<-fany-pany+1	       
    perduts<-potencials-presents	
    
    tall<-perduts/potencials	 
    tall<-tall*100			
    if(tall > perdua){normals[(k-1)]<-NA}			
  }
  sortida<-cbind(1:12,round(normals,1)) 
  write.table(sortida,fitxer,quote=F,sep='\t',row.names=F,col.names=F)  
  return(sortida)
}
#######
plotindex<-function(indice,indexname,plotname,largeur=1800,hauteur=900){
  
  kus<-unlist(strsplit(indexname,'/'))
  kus<-kus[length(kus)]
  station<-unlist(strsplit(kus,'_'))[1]
  ti<-unlist(strsplit(indexname,'.',fixed=TRUE))
  titi<-length(ti)-1
  titulo<-toupper(ti[titi])
  stats<-round(zyp.trend.vector(indice[,2],method='zhang'),3)
  mytable<-data.frame(trends=stats)
  
  ## temp: dias y % dias
  
  if(titulo == "SU" | titulo == "TR" | titulo == "WSDI" | titulo == "CSDI"){
    
    par(mar = c(5,4,4,5))
    nyu<-ggplot(data=indice,aes(x=as.numeric(Date),y=Value)) +
      geom_bar(stat='identity',aes(fill = Value)) 
    nyu <- nyu +scale_fill_gradient(low = "orange",high = "orange")
    nyu<-nyu+theme_bw()
    nyu<-nyu+theme(axis.text.x = element_text(color = "#993333", size = 40, angle = 0, hjust = .5, vjust = .5, face = "bold"),
                   axis.text.y = element_text(color = "#993333", size = 40, angle = 0, hjust = 1, vjust = 0, face = "bold"),  
                   axis.title.x = element_text(color = "black", size = 40, angle = 0, hjust = .5, vjust = 0, face = "bold"),
                   axis.title.y = element_text(color = "black", size = 40, angle = 90, hjust = .5, vjust = .5, face = "bold"))
    
    nyu<-nyu+xlab('Year') + ylab("Jours") 
    nyu<-nyu+geom_smooth(formula='y~x',method='loess',size=2, color = "red")
    #nyu<-nyu+geom_line(size=2)
    nyu<-nyu+ggtitle(titulo) + theme(plot.title = element_text(size=40))
    
    tbl<-tableGrob(t(mytable),theme=ttheme_minimal(base_size = 30))
    jpeg(plotname,width=largeur,height=hauteur)
    grid.arrange(nyu,tbl,as.table=TRUE,heights=c(4,1))
    dev.off()
    
  } else if (titulo == "TN10P" | titulo == "TN90P" | titulo == "TX90P" | titulo == "TX10P"){
    par(mar = c(5,4,4,5))
    nyu<-ggplot(data=indice,aes(x=as.numeric(Date),y=Value)) +
      geom_bar(stat='identity',aes(fill = Value)) 
    nyu <- nyu + scale_fill_gradient(low = "orange", high = "orange")
    
    nyu<-nyu+theme_bw()
    nyu<-nyu+theme(axis.text.x = element_text(color = "#993333", size = 40, angle = 0, hjust = .5, vjust = .5, face = "bold"),
                   axis.text.y = element_text(color = "#993333", size = 40, angle = 0, hjust = 1, vjust = 0, face = "bold"),  
                   axis.title.x = element_text(color = "black", size = 40, angle = 0, hjust = .5, vjust = 0, face = "bold"),
                   axis.title.y = element_text(color = "black", size = 40, angle = 90, hjust = .5, vjust = .5, face = "bold"))
    
    nyu<-nyu + xlab('Year') + ylab("% Jours") 
    nyu<-nyu+geom_smooth(formula='y~x',method='loess',size=2,color=ifelse(titulo == "TX10P" | titulo == "TN10P","blue","red"))
    #nyu<-nyu+geom_line(size=2)
    nyu<-nyu+ggtitle(titulo) + theme(plot.title = element_text(size=40))
    
    tbl<-tableGrob(t(mytable),theme=ttheme_minimal(base_size = 30))
    jpeg(plotname,width=largeur,height=hauteur)
    grid.arrange(nyu,tbl,as.table=TRUE,heights=c(4,1))
    dev.off()
    
    ### temp en °C 
  } else if (titulo == "TNN" | titulo == "TXX" | titulo == "TXN" | titulo == "TNX" | titulo == "DTR"){
    par(mar = c(5,4,4,5))
    nyu<-ggplot(data=indice,aes(x=as.numeric(Date),y=Value))+
      geom_bar(stat='identity',aes(fill = Value)) 
    nyu <- nyu + scale_fill_gradient(low = "orange", high = "orange")
    
    nyu<-nyu+theme_bw()
    nyu<-nyu+theme(axis.text.x = element_text(color = "#993333", size = 40, angle = 0, hjust = .5, vjust = .5, face = "bold"),
                   axis.text.y = element_text(color = "#993333", size = 40, angle = 0, hjust = 1, vjust = 0, face = "bold"),  
                   axis.title.x = element_text(color = "black", size = 40, angle = 0, hjust = .5, vjust = 0, face = "bold"),
                   axis.title.y = element_text(color = "black", size = 40, angle = 90, hjust = .5, vjust = .5, face = "bold"))
    
    nyu<-nyu + xlab('Year') + ylab("°C") 
    nyu<-nyu+geom_smooth(formula='y~x',method='loess',size=2,color=ifelse(titulo == "TNN" | titulo == "TXN","blue","red"))
    #nyu<-nyu+geom_line(size=2)
    nyu<-nyu+ggtitle(titulo) + theme(plot.title = element_text(size=40))
    
    tbl<-tableGrob(t(mytable),theme=ttheme_minimal(base_size = 30))
    jpeg(plotname,width=largeur,height=hauteur)
    grid.arrange(nyu,tbl,as.table=TRUE,heights=c(4,1))
    dev.off()
    
    ### Precipitacion: n° dias#
  }  else if (titulo == "CDD" | titulo == "CWD" | titulo == "R10MM" | titulo == "R20MM" | titulo == "RNNMM"){
    par(mar = c(5,4,4,5))
    nyu<-ggplot(data=indice,aes(x=as.numeric(Date),y=Value)) +
      geom_bar(stat='identity',aes(fill = Value)) 
    nyu <- nyu + scale_fill_gradient(low = "cyan",high = "cyan")
    
    nyu<-nyu+theme_bw()
    nyu<-nyu+theme(axis.text.x = element_text(color = "#993333", size = 40, angle = 0, hjust = .5, vjust = .5, face = "bold"),
                   axis.text.y = element_text(color = "#993333", size = 40, angle = 0, hjust = 1, vjust = 0, face = "bold"),  
                   axis.title.x = element_text(color = "black", size = 40, angle = 0, hjust = .5, vjust = 0, face = "bold"),
                   axis.title.y = element_text(color = "black", size = 40, angle = 90, hjust = .5, vjust = .5, face = "bold"))
    
    nyu<-nyu +  xlab('Year') + ylab("Jours") 
    nyu<-nyu+geom_smooth(formula='y~x',method='loess',size=2,color="blue")
    #nyu<-nyu+geom_line(size=2)
    nyu<-nyu+ggtitle(titulo) + theme(plot.title = element_text(size=40))
    
    tbl<-tableGrob(t(mytable),theme=ttheme_minimal(base_size = 30))
    jpeg(plotname,width=largeur,height=hauteur)
    grid.arrange(nyu,tbl,as.table=TRUE,heights=c(4,1))
    dev.off()
    
    ## precipitacion mm #
  } else if (titulo == "PRCPTOT" | titulo == "R95PTOT" | titulo == "R99PTOT" | titulo == "RX1DAY" | titulo == "RX5DAY" | titulo == "SDII"){
    par(mar = c(5,4,4,5))
    nyu<-ggplot(data=indice,aes(x=as.numeric(Date),y=Value)) +
      geom_bar(stat='identity',aes(fill = Value)) 
    nyu <- nyu + scale_fill_gradient(low = "darkgreen",high = "darkgreen")
    
    nyu<-nyu+theme_bw()
    nyu<-nyu+theme(axis.text.x = element_text(color = "#993333", size = 40, angle = 0, hjust = .5, vjust = .5, face = "bold"),
                   axis.text.y = element_text(color = "#993333", size = 40, angle = 0, hjust = 1, vjust = 0, face = "bold"),  
                   axis.title.x = element_text(color = "black", size = 40, angle = 0, hjust = .5, vjust = 0, face = "bold"),
                   axis.title.y = element_text(color = "black", size = 40, angle = 90, hjust = .5, vjust = .5, face = "bold"))
    
    nyu<-nyu + xlab('Year') + ylab("mm") 
    nyu<-nyu+geom_smooth(formula='y~x',method='loess',size=2,color="blue")
    #nyu<-nyu+geom_line(size=2)
    nyu<-nyu+ggtitle(titulo) + theme(plot.title = element_text(size=40))
    
    tbl<-tableGrob(t(mytable),theme=ttheme_minimal(base_size = 30))
    jpeg(plotname,width=largeur,height=hauteur)
    grid.arrange(nyu,tbl,as.table=TRUE,heights=c(4,1))
    dev.off()
  }
  
}

###### old version ###
# plotindex<-function(indice,indexname,plotname,largeur=1800,hauteur=900){
#   
#   kus<-unlist(strsplit(indexname,'/'))
#   kus<-kus[length(kus)]
#   station<-unlist(strsplit(kus,'_'))[1]
#   ti<-unlist(strsplit(indexname,'.',fixed=TRUE))
#   titi<-length(ti)-1
#   titulo<-toupper(ti[titi])
#   stats<-round(zyp.trend.vector(indice[,2],method='zhang'),3)
#   mytable<-data.frame(trends=stats)
#   
#   
#   nyu<-ggplot(data=indice,aes(x=as.numeric(Date),y=Value))
#   nyu<-nyu+theme_bw()
#   nyu<-nyu+theme(axis.text.x = element_text(color = "#993333", size = 40, angle = 0, hjust = .5, vjust = .5, face = "bold"),
#                  axis.text.y = element_text(color = "#993333", size = 40, angle = 0, hjust = 1, vjust = 0, face = "bold"),  
#                  axis.title.x = element_text(color = "black", size = 40, angle = 0, hjust = .5, vjust = 0, face = "bold"),
#                  axis.title.y = element_text(color = "black", size = 40, angle = 90, hjust = .5, vjust = .5, face = "bold"))
#   
#   nyu<-nyu+geom_point(col='red',pch=19)+xlab('Year')+ylab(titulo)  
#   nyu<-nyu+geom_smooth(formula='y~x',method='loess',size=2)
#   nyu<-nyu+geom_line(size=2)
#   
#   tbl<-tableGrob(t(mytable),theme=ttheme_minimal(base_size = 40))
#   jpeg(plotname,width=largeur,height=hauteur)
#   grid.arrange(nyu,tbl,as.table=TRUE,heights=c(4,1))
#   dev.off()
# }
