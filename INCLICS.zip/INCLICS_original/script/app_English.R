
chemin<-getwd()
shiny::runApp(paste0(chemin,'/Saison_de_pluie_et_calendrier_cultural_English.R'), launch.browser = TRUE)
