### THIS CODE IS MADE by LUC RANDRIAMAROLAZA and ENRIC AGUILAR, Centre for Climate Change, C3, URV, Tarragona, Spain - Directorate General of Meteorology, Madagascar  
### It is provided free under the terms of the GNU Lesser General Public License as published by the Free Software Foundation,
# version 3.0 of the License. It is distributed under the terms of this license 'as-is' and has not been designed or prepared to meet any Licensee's particular requirements. 
# The author and its institution make no warranty, either express or implied, including but not limited to, warranties of merchantability or fitness for a particular
# purpose. In no event will they will be liable for any indirect, special, consequential or other damages attributed to the Licensee's use of The Library. 
# In downloading The Library you understand and agree to these terms and those of the associated LGP License. See the GNU Lesser General Public License for more details.
# <http://www.gnu.org/licenses/lgpl.html> or contact the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

if(!require(zoo)){install.packages('zoo')}
if(!require(shiny)){install.packages('shiny')}
if(!require(lubridate)){install.packages('lubridate')}
if(!require(DT)){install.packages('DT')}
if(!require(rstudioapi)){install.packages('rstudioapi')}
if(!require(shinydashboard)){install.packages('shinydashboard')}
if(!require(timeDate)){install.packages('timeDate')}
if(!require(shinyFiles)){ install.packages('shinyFiles')}
if(!require(rlang)){install.packages('rlang')}
if(!require(webshot)){ install.packages('webshot')}
if(!require(kableExtra)){install.packages('kableExtra')}
if(!require(magick)){install.packages('magick')}
if(!require(htmlTable)){install.packages('htmlTable')}
if(!require(png)){install.packages('png')}
if(!require(rmarkdown)){install.packages('rmarkdown')}
if(!require(knitr)){install.packages('knitr')}
if(!require(tinytex)){install.packages('tinytex')}
if(!require(shinybusy)){install.packages('shinybusy')}
if(!require(shinythemes)){install.packages('shinythemes')}
if(!require(shiny.i18n)){install.packages('shiny.i18n')}
##tinytex::install_tinytex()
##sudo chown -R $(whoami) /usr/local/bin (for macOS system)

library(knitr)
library(rmarkdown)
library(zoo)
library(shiny)
library(shinydashboard)
library(htmlTable)
library(lubridate)
library(DT)
library(rstudioapi)
library(timeDate)
library(shinyFiles)
library(webshot)
library(kableExtra)
library(magick)
library(png)
library(shinybusy)
library(shinythemes)
library(shiny.i18n)
#In case that you will ask to install phantomjs, Please run webshot::install_phantomjs()
##########

chemin<-getwd()
source('function_saison_de_pluie_et_calendrier_cultural_Espagnol.r')
sta <- station(chemin='../spcc/')


# Define UI for dataset viewer app ----

ui <-dashboardPage(
  dashboardHeader(
    title = "TEMPORADA DE LLUVIAS Y CALENDARIO DE CULTIVOS (SPCC)",
    titleWidth = 515,
    tags$li(class = "dropdown",shinyFilesButton("crop", "Elegir archivo de cultivos" ,
                                                title = "Elegir archivo de cultivos:", multiple = FALSE,
                                                buttonType = "default", class = NULL,style='padding:15px; font-size:95%;
                              color: white; background-color: blue; border-color: white')),
    tags$li(class = "dropdown",shinyFilesButton("station", "Elige una estación" ,title = "Elige uno estación:", multiple = FALSE,
                                                buttonType = "default", class = NULL,style='padding:15px; font-size:95%;
                            color: white; background-color: blue; border-color: white')),
    tags$li(class = "dropdown",actionButton("update", "Iniciar cálculo",style='padding:15px; font-size:95%;
             color: white; background-color: blue; border-color: white'),
            add_busy_bar(color = "red", height = "8px")),
    tags$li(class = "dropdown",actionButton("tout", "Elige zonas climáticas",style='padding:15px; font-size:95%;
             color: white; background-color: red; border-color: white')),
    tags$li(class = "dropdown",actionButton("figure", "Mostrar resultados",style='padding:15px; font-size:95%;
             color: white; background-color: red; border-color: white')),
    tags$li(class = "dropdown",downloadButton('report1','Generar el informe',style='padding:15px; font-size:95%
    ;color: white; background-color: green; border-color: white'),
            add_busy_bar(color = "red", height = "8px"))
  ),  
  dashboardSidebar(
    width = 515,
      fluidRow(
      column(4,
             dateInput("fOnset", "FECHA_inicio: Primera fecha del inicio",value = "1981-04-01", format = "M-dd"),
             numericInput("xmm","X: Precipitación acumulada (mm)",20,min=1),
             numericInput('yjours','Y: Número de días para acumular el xmm',3,min=1),
             numericInput('njours','N: Duración mínima de los días de lluvia',5,min=0),
             numericInput('seche','S: Definición de día seco en mm',0.85,min=0),
             numericInput('mjours','M: Duración máxima del período seco',10,min=1),
             numericInput('pendant','D: Número de días para contar M',30,min=1)
      ),
      column(4,
             dateInput("fCessation", "FECHA_Cesación: Primera fecha para el final",value = "1981-09-01", format = "M-dd"),
             numericInput('pet',label = 'PET: evapotranspiración',5,min = 0),
             numericInput('cap','C: capacidad de retención de agua del suelo',70,min = 0),
             numericInput('periode','P: número de días sin recuperar a máxima capacidad',15,min=0),
             numericInput('maxend','R: Acumulación de precipitaciones en mm para declarar el final',10,min=1),
             numericInput('endjours','E: Período de acumulación de R mm',7,min=1)
      ),
      column(4,
             actionButton("manual1", "Guía del usuario",style='padding:15px; font-size:100%;
                                            color: black; background-color: Yellow; border-color: Yellow'),
             actionButton('refresh1','Reprogramar sesión',style='padding:15px; font-size:90%;
                                            color: black; background-color: Yellow; border-color: Yellow'),
             selectInput('short',label = 'Elija el mes preferido para el final',choices = c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
                         ,selected = 'Dec'),
             numericInput('seqseche', 'Z: Número de días para contar la duración máxima de la secuencia seca al principio y hacia el final',50,min=1),
             numericInput('available','Número mínimo de datos de precipitación',360,max=366),
             selectInput("entete", label = "Elige en cabeza" ,choices = c('hoclm','QC_'),selected = 'hoclm'),
             selectInput("choix", "Elige la definición del final",choices=c(1,2),selected=1)
      ),
    )
    ),
  dashboardBody(
    tags$head(includeCSS('www/custom.css')),
    fluidRow(
      column(12,
             uiOutput('mytext21'))
    ),
    fluidRow(
      column(12,
             uiOutput('mylogo1'),
             br(),
      )
    ),
    uiOutput('mytext'),
    uiOutput('instrucciones'),
    tableOutput('mytext1'),

    fluidRow(
     
      column(12,offset=1,textOutput("text_file")
             )
      # column(12,
      #        uiOutput("mytable2")
      # )
    ),
    
    fluidRow(
      column(12,
             plotOutput("myplot6", width = "100%")
      )
    ),
    
    fluidRow(
      conditionalPanel('input.tout',
                       column(4,
                              selectInput("zone", "Zonas climáticas",
                                          choices=sta$ZONE,selected=sta$ZONE[1])
                       ),
                       column(4,
                              actionButton('run',cat('Iniciar el cálculo','\n',' para cada zona'),style='padding:15px; font-size:70%')
                              ),
                       add_busy_bar(color = "red", height = "8px"),
                       column(4,
                              actionButton('run1',cat('Iniciar el cálculo','\n','para todas las estaciones'),style='padding:15px; font-size:70%'),
                              add_busy_bar(color = "red", height = "8px")
                       )
     )
    ),
    
    fluidRow(
      column(12,offset = 1,
             uiOutput("text_file1"))
    ),
    
    # fluidRow(
    #   column(4,
    #          uiOutput('mytable3')
    #   ),
    #   column(8,
    #          uiOutput('mytable4')
    #   )
    # ),
    
    fluidRow(
      column(9,
             uiOutput('mytable5')
             ),
       column(3,
             plotOutput('mylegend1')
     )
    ),
    
    fluidRow(
    column(12,offset=1,
           uiOutput('mytext10'))
    ),
    
    fluidRow(
      conditionalPanel('input.figure',
      column(4,
             selectInput('choice','Elige la definición del final',choices=c(1,2),selected=1)
      ),                 
      column(4,
             selectInput('nom','Elige una estación',choices=sta$STAT_NAME)
      ),
  column(4,
         selectInput('res','Elija los resultados que desea mostrar',
                     choices = c('Curva de probabilidad acumulada','Temporada de lluvias en fechas','Duración de la temporada de lluvias','Fechas importantes','Calendario de calendarios'),
                     selected = 'Curva de probabilidad acumulada')
    )
  )
    ),
  conditionalPanel('input.figure !==0 && input.res === "Curva de probabilidad acumulada"',
                   tabPanel("Curva de probabilidad acumulada",plotOutput("myplot5"))
  ),
  
  conditionalPanel('input.figure !==0 && input.res === "Temporada de lluvias en fechas"',
                   tabPanel("Temporada de lluvias en fechas",plotOutput("myplot2"))
  ),
             conditionalPanel('input.figure !==0 && input.res === "Duración de la temporada de lluvias"',
                              tabPanel("Duración de la temporada de lluvias",plotOutput("myplot3"))
    ),
  conditionalPanel('input.figure !==0 && input.res === "Fechas importantes"',
                   tabPanel("Fechas importantes",plotOutput("myplot7"))
  ),
              conditionalPanel('input.figure !==0 && input.res === "Calendario de calendarios"',
                               tabPanel("Calendario de calendarios",plotOutput("myplot4"))),
  )
)

server <- shinyServer(function(input, output,session) {
  
  output$mytext21<-renderUI({
    HTML(paste("<strong>HERRAMIENTA DE SERVICIO CLIMÁTICO PARA LA AGRICULTURA</strong> desarrollada por:",' ',sep="<br/>"))
  }) 
  
  output$mylogo1<-renderUI({
    img(src = "logo_new.png",height='100',width='1000')
  })

  
  output$mytext<-renderUI(
    HTML(paste(' ','SPCC significa "Saison Pluvieuse et Calendrier Cultural" (Temporada de Lluvias y Calendario de cultivos)' ,' ','es una aplicación creada por LUC RANDRIAMAROLAZA(a,b) et ENRIC AGUILAR(a)','',
               'a) Centro de Cambio Climático, C3, URV, Tarragona, España','',
               'b) Dirección General de Meteorología de Madagascar',' ',sep="<br/>"))

  )
  observeEvent(input$manual1,{
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector='#mytext')
      removeUI(selector='#portada')
    }
    
    global$refresh <- FALSE
  })
  
  output$instrucciones <- reactive({
    if(!is.null(req(input$manual1))){
      includeMarkdown(paste0("../script/Manual_SPCC_Espagnol.RMD"))
    }
  })
  
  global <- reactiveValues(refresh = FALSE)
  
  volumes = c("UserFolder"='./../spcc/')
  
  observe({
    shinyFileChoose(input, "station", roots = volumes, session = session)
  })
  
  setwd('./../spcc/')
  stati<-reactive({
    stati<-read.table('stations.txt',as.is = T)
    colnames(stati)<-c('ID','STAT_NAME','LATITUDE','LONGITUDE','ALTITUDE','COUNTRY','ZONE')
    as.data.frame(stati)
  })
  
### Les stations sont entrées une à une ###
  observeEvent(input$station,{
     global$refresh <- TRUE
     if(global$refresh) {
       removeUI(selector='#mytext')
       removeUI(selector='#mytext8')
       removeUI(selector='#mytext9')
       removeUI(selector='#mylogo1')
       removeUI(selector='#mytext21')
     }
     
     global$refresh <- FALSE
  })
  
  x<-reactive({
      if(!is.null(req(input$station))){
        as.character(parseFilePaths(volumes, input$station)$datapath)
      }
  })
  
  res<-reactive({
    if(!is.null(req(input$station))){
      rsoi(x=x(),fOnset=input$fOnset,xmm=input$xmm,yjours=input$yjours,njours=input$njours,
           seche=input$seche,mjours=input$mjours,pendant=input$pendant,available=input$available
           ,fCessation=input$fCessation,maxend=input$maxend,endjours=input$endjours,
           seqseche=input$seqseche,pet = input$pet,cap = input$cap,short=input$short,periode=input$periode)
    }
  })

  observe({
    shinyFileChoose(input, "crop", roots = volumes, session = session)
    })
  
  crop<-reactive({
    if(!is.null(req(input$crop))){
      read.table(as.character(parseFilePaths(volumes, input$crop)$datapath),header = T)
    }
  })
  
  observeEvent(input$station,{
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector='#mytext')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytext8')
      removeUI(selector='#mytext9')
      removeUI(selector='#mylogo1')
      removeUI(selector='#mytext21')
    }
    global$refresh <- FALSE
    
    isolate({
      if(input$entete =='QC_'){
        id<-which(substring(strsplit(as.character(parseFilePaths(volumes, input$station)$name),'.txt'),
                            4,nchar(strsplit(as.character(parseFilePaths(volumes, input$station)$name),'.txt')))==stati()$ID)
      }else{
        id<-which(substring(strsplit(as.character(parseFilePaths(volumes, input$station)$name),'.txt'),
                            6,nchar(strsplit(as.character(parseFilePaths(volumes, input$station)$name),'.txt')))==stati()$ID)
      }
      output$text_file<-renderText({
        paste0('El nombre de la estación es: ',toupper(stati()$STAT_NAME[id]))
      })
    })
  })
  
  observeEvent(input$tout, {
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector='#mytext')
      removeUI(selector='#mytext8')
      removeUI(selector='#mytext9')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytable1')
      removeUI(selector='#mytable2')
      removeUI(selector='#mytable3')
      removeUI(selector='#mytable4')
      removeUI(selector='#myplot')
      removeUI(selector='#myplot1')
      removeUI(selector='#mytable5')
      removeUI(selector='#mytext9')
      removeUI(selector='#mylegend1')
      removeUI(selector='#text_file')
      
    }
    global$refresh <- FALSE
    
    isolate({
          if(!is.null(req(input$zone))){
            output$text_file1<-renderUI(
            HTML(paste0('Todas las estaciones de la zona',input$zone,' son usados'))
            )
          }
    })
  })
  
  observeEvent(input$crop,{
    global$refresh <- TRUE
    if(global$refresh) {
    removeUI(selector='#mytext')
    removeUI(selector='#mytext8')
    removeUI(selector='#mytext9')
    removeUI(selector='#mylogo1')
    removeUI(selector='#mytext21')
    }
    global$refresh <- FALSE
    isolate({
      if(!is.null(req(input$crop))){
    output$mytext1<-renderTable(crop())
    }
      })
  })

  
  observeEvent(input$update, {
    
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector='#mytext')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytext8')
      removeUI(selector='#mytext9')
      removeUI(selector='#mylogo1')
      removeUI(selector='#mytext21')
    }
    global$refresh <- FALSE
    
    write.table(res(), paste0('resultats/',strsplit(as.character(parseFilePaths(volumes, input$station)$name),'.txt'),'_annuelle.txt'),append = F,col.names = T,
                row.names = F,quote = F,sep = '\t')
    
    tab1<-reactive({
      if(!is.null(req(input$station))){
        tablecal1(x=res(),y=x(),fCessation=input$fCessation,fOnset=input$fOnset,
                  seqseche=input$seqseche,seche=input$seche,short=input$short,pet = input$pet,cap = input$cap,choice = input$choix)
      }
    })
    
    tab2<-reactive({
      if(!is.null(req(input$station))){
        rainy_duration(x=res(),choice = input$choix)
      }
      
    })
    
    tab3<-reactive({
      if(!is.null(req(input$crop))){
        late_seeding(x=res(),y=x(),crop=crop(),fOnset=input$fOnset,fCessation = input$fCessation,
                     short=input$short,choice = input$choix)
      }
    })
    
    tab4<-reactive({
      if(!is.null(req(input$crop))){
        growing_calendar(x=res(),y=x(),crop=crop(),fOnset = input$fOnset,short=input$short,choice=input$choix)
      }
    })
    
    output$myplot6<-renderPlot({
      isolate({
        calendrier(res=tab1(),vit=tab3(),short=input$short)
      })
    },height = 800, width = 900 )
    
    # output$mytable2<-renderUI({
    #   isolate({
    #     HTML(tab1())
    #   })
    # })
    
    # output$mytable3<-renderUI({
    #   isolate({
    #     HTML(tab2())
    #   })
    # })
    
    # output$mytable4<-renderUI({
    #   isolate({
    #     HTML(tab3())
    #   })
    # })
    output$mytable5<-renderUI({
      isolate({
        HTML(tab4())
      })
    })
    
    output$mylegend1<-renderPlot({
      isolate({
        plot_jpeg(paste0('legend_new.jpg'),titre = '')
      })
    })

  })

  
  ###### utiliser toutes les stations ######  
  
  observeEvent(input$run,{
    
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector='#mytext')
      removeUI(selector='#mytext8')
      removeUI(selector='#mytext9')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytable1')
      removeUI(selector='#mytable2')
      removeUI(selector='#mytable3')
      removeUI(selector='#mytable4')
      removeUI(selector='#myplot')
      removeUI(selector='#myplot1')
      removeUI(selector='#mytable5')
      removeUI(selector='#mytext9')
      removeUI(selector='#mylegend1')
      removeUI(selector='#text_file')
      
    }
    global$refresh <- FALSE
    
    rsoi_station(zone=input$zone,fOnset=input$fOnset,xmm=input$xmm,yjours=input$yjours,njours=input$njours,
                 seche=input$seche,mjours=input$mjours,pendant=input$pendant,available=input$available,entete = input$entete,
                 fCessation=input$fCessation,maxend=input$maxend,endjours=input$endjours,
                 seqseche=input$seqseche,pet=input$pet,cap=input$cap,short=input$short,periode=input$periode)
    
    dat<-read.table('resultats/ensemble.txt',as.is = T,sep=',')
    dat<-dat[-1,]
    colnames(dat)<-c('Year','Available','Onset_date','Seq_O','Seq_OF','Seq_OE','length_O','P_onset','J_onset','Cessation_date1','Cessation_date2',
                     'J_cessation1','J_cessation2','P_cessation1','P_cessation2','Seq_CT1','Seq_CT1F','Seq_CT1E','Seq_CT2','Seq_CT2F','Seq_CT2E','Seq_CM1',
                     'Seq_CM1F','Seq_CM1E','Seq_CM2','Seq_CM2F','Seq_CM2E','length1','length2','first1','end1','long1','first2','end2','long2','Id')
    dat<-as.data.frame(dat)
    
    
    for(id in as.numeric(as.character(stati()$ID[which(stati()$ZONE==input$zone)]))){
      resu<-as.data.frame(dat[which(id == dat$Id),])
      for(choice in c(1,2)){
        
        HTML(tablecal1(x=resu,y=paste0('donnees/',input$entete,id,'.txt'),fCessation=input$fCessation,fOnset=input$fOnset,
                       seqseche = input$seqseche,seche = input$seche,pet=input$pet,cap = input$cap,short=input$short,choice=choice)) %>%
          save_kable(file = paste0('resultats/',id,'pluiedates',choice,'.jpg'))
        HTML(rainy_duration(x=resu,choice=choice)) %>%
          save_kable(file = paste0('resultats/',id,'longueur',choice,'.jpg'))
        HTML(late_seeding(x=resu,y=paste0('donnees/',input$entete,id,'.txt'),crop=crop(),fOnset = input$fOnset,fCessation=input$fCessation,
                          short=input$short,choice =choice)) %>%
          save_kable(file = paste0('resultats/',id,'calendrierdates',choice,'.jpg'))
        HTML(growing_calendar(x=resu,y=paste0('donnees/',input$entete,id,'.txt'),crop=crop(),fOnset = input$fOnset,short = input$short,
                              choice=choice)) %>% 
          save_kable(file = paste0('resultats/',id,'calendriercouleurs',choice,'.jpg'))
        
        jpeg(paste0(paste0('resultats/',id,'cdf',choice,'.jpg')))
        
        plot_fun(x=resu,y=paste0('donnees/',input$entete,id,'.txt'),fOnset=input$fOnset,fCessation=input$fCessation,short=input$short,choice=choice)
        dev.off()
      }
    }
  })
  
  output$mytext10<-renderUI({
      isolate({
        if(!is.null(req(input$run))){
        removeUI(selector='#text_file1')
        HTML(paste('Puede ver los resultados tocando "Mostrar resultados".'
                   ,sep = "<br/>"))
        }
        })
  })
  observeEvent(input$figure,{
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector='#mytext')
      removeUI(selector='#mytext8')
      removeUI(selector='#mytext9')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytable1')
      removeUI(selector='#mytable2')
      removeUI(selector='#mytable3')
      removeUI(selector='#mytable4')
      removeUI(selector='#myplot')
      removeUI(selector='#myplot1')
      removeUI(selector='#mytable5')
      removeUI(selector='#mytext9')
      removeUI(selector='#mylegend1')
      removeUI(selector='#mytext10')
      removeUI(selector='#text_file')
      removeUI(selector='#text_file1')
      # removeUI(
      #   selector = 'div:has(>> #zone)'
      # )
      # removeUI(
      #   selector = 'div:has(>> #run)'
      # )
      
    }
    global$refresh <- FALSE
  })
  
  output$myplot2 <-renderPlot({
    if(!is.null(req(input$figure))){
      par(mar=rep(2, 4))
      idi<-stati()$ID[which(stati()$STAT_NAME == input$nom)]
      plot_jpeg(paste0('resultats/',idi,'pluiedates',input$choice,'.jpg'),titre = '')
    }
    
  })
  
  output$myplot5 <-renderPlot({
    if(!is.null(req(input$figure))){
      par(mar=rep(2, 4))
      idi<-stati()$ID[which(stati()$STAT_NAME == input$nom)]
      plot_jpeg(paste0('resultats/',idi,'cdf',input$choice,'.jpg'),titre = '')
    }
  })
  
  output$myplot3 <-renderPlot({
    if(!is.null(req(input$figure))){
      par(mar=rep(2, 4))
      idi<-stati()$ID[which(stati()$STAT_NAME == input$nom)]
      plot_jpeg(paste0('resultats/',idi,'longueur',input$choice,'.jpg'),titre = '')
    }
  })
  
  output$myplot7 <-renderPlot({
    if(!is.null(req(input$figure))){
      par(mar=rep(2, 4))
      idi<-stati()$ID[which(stati()$STAT_NAME == input$nom)]
      plot_jpeg(paste0('resultats/',idi,'calendrierdates',input$choice,'.jpg'),titre = '')
    }
  })
  
  output$myplot4 <-renderPlot({
    if(!is.null(req(input$figure))){
      par(mar=rep(2, 4))
      idi<-stati()$ID[which(stati()$STAT_NAME == input$nom)]
      par(mfrow = c(2,1))
      plot_jpeg(paste0('resultats/',idi,'calendriercouleurs',input$choice,'.jpg'),titre = '')
      plot_jpeg(paste0('legend_new.jpg'),titre = '')
      
    }
  })
  
  output$report1 <- downloadHandler(
    filename = "rapport.pdf",
    content = function(file) {
      tempReport <- file.path('../spcc/rapport', "report_Espagnol.Rmd")
      file.copy("report_Espagnol.Rmd", tempReport, overwrite = TRUE)
      
      params <- list(zone=input$zone,fOnset=input$fOnset,xmm=input$xmm,yjours=input$yjours,njours=input$njours,
                     seche=input$seche,mjours=input$mjours,pendant=input$pendant,available=input$available,entete=input$entete,
                     fCessation=input$fCessation,maxend=input$maxend,endjours=input$endjours,
                     seqseche=input$seqseche,short=input$short,
                     sta=stati(),crop=crop(),pet=input$pet,cap=input$cap,periode=input$periode)
      
      rmarkdown::render(tempReport, output_file = file,
                        params = params,
                        envir = new.env(parent = globalenv())
      )
    })
  

observeEvent(input$report1,{
  global$refresh <- TRUE
  if(global$refresh) {
    removeUI(selector='#mytext')
    removeUI(selector='#mytext8')
    removeUI(selector='#mytext9')
    removeUI(selector='#mytext1')
    removeUI(selector='#mytable1')
    removeUI(selector='#mytable2')
    removeUI(selector='#mytable3')
    removeUI(selector='#mytable4')
    removeUI(selector='#myplot')
    removeUI(selector='#myplot1')
    removeUI(selector='#mytable5')
    removeUI(selector='#mytext9')
    removeUI(selector='#mylegend1')
    removeUI(selector='#mytext10')
    removeUI(selector = '#myplot5')
    removeUI(selector = '#myplot6')
    removeUI(selector = '#myplot7')
    removeUI(selector = '#myplot4')
    removeUI(selector = '#myplot3')
    removeUI(selector = '#myplot2')
    removeUI(selector='#text_file')
   removeUI(selector='#text_file1')
    
  }
  global$refresh <- FALSE
  
})

output$mytext11<-renderUI({
  if(!is.null(req(input$report1))){
    HTML(paste('La redacción del informe está completa".'
               ,sep = "<br/>"))
  }
})

observeEvent(input$refresh1,{
  
  global$refresh <- TRUE
  if(global$refresh) { session$reload() }
  
})

})
shinyApp(ui, server)