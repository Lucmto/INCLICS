### THIS CODE IS MADE by LUC RANDRIAMAROLAZA, ENRIC AGUILAR and JOSE GUIJARRO, Centre for Climate Change, C3, URV, Tarragona, Spain - Directorate General of Meteorology, Madagascar, Agencia Estatal de Meteorología (AEMET), Spain  
### It is provided free under the terms of the GNU Lesser General Public License as published by the Free Software Foundation,
# version 3.0 of the License. It is distributed under the terms of this license 'as-is' and has not been designed or prepared to meet any Licensee's particular requirements. 
# The author and its institution make no warranty, either express or implied, including but not limited to, warranties of merchantability or fitness for a particular
# purpose. In no event will they will be liable for any indirect, special, consequential or other damages attributed to the Licensee's use of The Library. 
# In downloading The Library you understand and agree to these terms and those of the associated LGP License. See the GNU Lesser General Public License for more details.
# <http://www.gnu.org/licenses/lgpl.html> or contact the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.


if(!require(zoo)){install.packages('zoo')}
if(!require(shiny)){install.packages('shiny')}
if(!require(lubridate)){install.packages('lubridate')}
if(!require(DT)){install.packages('DT')}
if(!require(rstudioapi)){install.packages('rstudioapi')}
if(!require(shinydashboard)){install.packages('shinydashboard')}
if(!require(timeDate)){install.packages('timeDate')}
if(!require(shinyFiles)){ install.packages('shinyFiles')}
if(!require(INQC)){install.packages('INQC')}
if(!require(webshot)){ install.packages('webshot')}
if(!require(kableExtra)){install.packages('kableExtra')}
if(!require(magick)){install.packages('magick')}
if(!require(png)){install.packages('png')}
if(!require(jpeg)){install.packages('jpeg')}
if(!require('DataCombine')) {install.packages('DataCombine')}
if(!require(tinytex)){install.packages('tinytex')}
### tinytex::install_tinytex()


library(INQC)
library(zoo)
library(shiny)
library(shinydashboard)
library(htmlTable)
library(lubridate)
library(DT)
library(rstudioapi)
library(timeDate)
library(shinyFiles)
library(webshot)
library(kableExtra)
library(magick)
library(png)
library(jpeg)
library(DataCombine)

#####
calendR <- function(year = format(Sys.Date(), "%Y"),
                    month = NULL,
                    
                    start_date = NULL,
                    end_date = NULL,
                    
                    desired_order="",
                    ordered_colors="",
                    
                    start = c("S", "M"),
                    orientation = c("portrait", "landscape"),
                    
                    title,
                    title.size = 20,
                    title.col = "gray30",
                    
                    subtitle = "",
                    subtitle.size = 10,
                    subtitle.col = "gray30",
                    
                    text = "",
                    text.pos = NULL,
                    text.size = 4,
                    text.col = "white",
                    #text.col = "gray30",
                    
                    special.days = NULL,
                    special.col = "gray90",
                    #special.col = ordered_colors,
                    gradient = FALSE,
                    low.col = "white",
                    
                    col = "gray30",
                    #col = "white",
                    lwd = 0.5,
                    lty = 1,
                    
                    font.family = "sans",
                    font.style = "plain",
                    
                    day.size = 3,
                    days.col = "gray30",
                    #days.col = "white",
                    
                    weeknames,
                    # weeknames.col = "gray30",
                    weeknames.col = "white",
                    weeknames.size = 4.5,
                    
                    months.size = 10,
                    months.col = "gray30",
                    months.pos = 0.5,
                    mbg.col = "white",
                    
                    legend.pos = "none",
                    legend.title = "",
                    
                    bg.col = "white",
                    bg.img = "",
                    
                    margin = 1,
                    
                    lunar = FALSE,
                    lunar.col = "gray60",
                    #lunar.col = "white",
                    lunar.size = 7,
                    
                    pdf = FALSE,
                    doc_name = "",
                    papersize = "A4") {
  
  if(year < 0) {
    stop("You must be kidding. You don't need a calendar of a year Before Christ :)")
  }
  
  wend <- TRUE
  l <- TRUE
  
  if((!is.null(start_date) & is.null(end_date))) {
    stop("Provide an end date with the 'end_date' argument")
  }
  
  if((is.null(start_date) & !is.null(end_date))) {
    stop("Provide a start date with the 'start_date' argument")
  }
  
  if(is.character(special.days) & length(unique(na.omit(special.days))) != length(special.col)) {
    stop("The number of colors supplied on 'special.col' argument must be the same of length(unique(na.omit(special.days)))")
  }
  
  if (length(unique(start)) != 1) {
    start <- "S"
  }
  
  if (length(unique(orientation)) != 1) {
    orientation <- "landscape"
  }
  
  match.arg(start, c("S", "M"))
  match.arg(orientation, c("landscape", "portrait", "l", "p"))
  match.arg(papersize, c("A6", "A5", "A4", "A3", "A2", "A1", "A0"))
  
  
  if(!is.null(month)){
    if(month > 12) {
      stop("There are no more than 12 months in a year")
    }
    
    if(month <= 0) {
      stop("Months must be between 1 and 12")
    }
    
    if(is.character(month)) {
      stop("You must provide a month in a numeric format, between 1 and 12")
    }
  }
  
  months <- format(seq(as.Date("2016-01-01"), as.Date("2016-12-01"), by = "1 month"), "%B")
  
  if(text != "" && is.null(text.pos)){
    warning("Select the number of days for the text with the 'text.pos' argument")
  }
  
  if(text == "" && !is.null(text.pos)){
    warning("Add the text with the 'text' argument")
  }
  
  if(missing(weeknames)) {
    
    up <- function(x) {
      substr(x, 1, 1) <- toupper(substr(x, 1, 1))
      x
    }
    
    Day <- seq(as.Date("2020-08-23"), by = 1, len=7)
    weeknames <- c(up(weekdays(Day))[2:7], up(weekdays(Day))[1])
  }
  
  
  if(!is.null(start_date) & !is.null(end_date)){
    
    if(lunar == TRUE) {
      l <- FALSE
      warning("Lunar phases are only available for monthly calendars")
    }
    
    mindate <- as.Date(start_date)
    maxdate <- as.Date(end_date)
    weeknames <- substring(weeknames, 1, 3)
    
  } else {
    
    if(is.null(month)){
      
      mindate <- as.Date(format(as.Date(paste0(year, "-0", 01, "-01")), "%Y-%m-01"))
      maxdate <- as.Date(format(as.Date(paste0(year, "-12-", 31)), "%Y-%m-31"))
      weeknames <- substring(weeknames, 1, 3)
      
    } else {
      
      if(month >= 10){
        mindate <- as.Date(format(as.Date(paste0(year, "-", month, "-01")), "%Y-%m-01"))
      } else {
        mindate <- as.Date(format(as.Date(paste0(year, "-0", month, "-01")), "%Y-%m-01"))
      }
      
      maxdate <- seq(mindate, length = 2, by = "months")[2] - 1
    }
  }
  
  # set up tibble with all the dates.
  filler <- tibble(date = seq(mindate, maxdate, by = "1 day"))
  
  # Filling colors
  dates <- seq(mindate, maxdate, by = "1 day")
  fills <- numeric(length(dates))
  
  # Texts
  texts <- character(length(dates))
  texts[text.pos] <- text
  
  moon_m <- getMoonIllumination(date = dates, keep = c("fraction", "phase", "angle"))
  moon <- moon_m[, 2]
  right <- ifelse(moon_m[, 4] < 0, TRUE, FALSE)
  
  if(is.character(special.days)) {
    
    if(length(special.days) != length(dates)){
      
      if(special.days != "weekend") {
        stop("special.days must be a numeric vector, a character vector of the length of the number of days of the year or month or 'weekend'")
      } else {
        wend <- FALSE
      }
    }
    
    
    if(gradient == TRUE){
      warning("Gradient won't be created as 'special.days' is of type character. Set gradient = FALSE in this scenario to avoid this warning")
      
      if(legend.title != "" & legend.pos == "none"){
        warning("Legend title specified, but legend.pos == 'none', so no legend will be plotted")
      }
      
    } else {
      if(length(special.days) != length(dates) & (legend.pos != "none" | legend.title != "")) {
        legend.pos = "none"
        warning("gradient = FALSE, so no legend will be plotted")
      }
    }
    
  } else {
    
    if(gradient == FALSE){
      if(length(special.days) != length(dates) & (legend.pos != "none" | legend.title != "")) {
        legend.pos = "none"
        warning("gradient = FALSE, so no legend will be plotted")
      }
    } else {
      
      if(legend.title != "" & legend.pos == "none"){
        warning("Legend title specified, but legend.pos == 'none', so no legend will be plotted")
      }
    }
    
    if(any(special.days > length(dates))) {
      
      stop("No element of the 'special.days' vector can be greater than the number of days of the corresponding month or year")
    }
    
    if(gradient == TRUE & (length(special.days) != length(dates))) {
      stop("If gradient = TRUE, the length of 'special.days' must be the same as the number of days of the corresponding month or year")
    }
  }
  
  
  if(start == "M") {
    
    weekdays <- weeknames
    
    t1 <- tibble(date = dates, fill = fills) %>%
      right_join(filler, by = "date") %>% # fill in missing dates with NA
      mutate(dow = ifelse(as.numeric(format(date, "%w")) == 0, 6, as.numeric(format(date, "%w")) - 1)) %>%
      mutate(month = format(date, "%B")) %>%
      mutate(woy = as.numeric(format(date, "%W"))) %>%
      mutate(year = as.numeric(format(date, "%Y"))) %>%
      mutate(month = toupper(factor(month, levels = months, ordered = TRUE))) %>%
      # arrange(year, month) %>%
      mutate(monlabel = month)
    
    if (!is.null(month)) { # multi-year data set
      t1$monlabel <- paste(t1$month, t1$year)
    }
    
    t2 <- t1 %>%
      mutate(monlabel = factor(monlabel, ordered = TRUE)) %>%
      mutate(monlabel = fct_inorder(monlabel)) %>%
      mutate(monthweek = woy - min(woy),
             y = max(monthweek) - monthweek + 1) %>%
      mutate(weekend = ifelse(dow == 6 | dow == 5, 1, 0))
    
    
    if(is.null(special.days)) {
      special.col <- "white"
    } else {
      
      if(is.character(special.days)) {
        
        if (length(special.days) == length(dates)) {
          fills <- special.days
        } else {
          if (special.days == "weekend") {
            fills <- t2$weekend
          }
        }
        
      } else {
        
        if(gradient == TRUE) {
          fills <- special.days
        } else {
          fills[special.days] <- 1
        }
      }
    }
    
  } else {
    
    weekdays <- c(weeknames[7], weeknames[1:6])
    
    t1 <- tibble(date = dates, fill = fills) %>%
      right_join(filler, by = "date") %>% # fill in missing dates with NA
      mutate(dow = as.numeric(format(date, "%w"))) %>%
      mutate(month = format(date, "%B")) %>%
      mutate(woy = as.numeric(format(date, "%U"))) %>%
      mutate(year = as.numeric(format(date, "%Y"))) %>%
      mutate(month = toupper(factor(month, levels = months, ordered = TRUE))) %>%
      # arrange(year, month) %>%
      mutate(monlabel = month)
    
    if (!is.null(month)) { # Multi-year data set
      t1$monlabel <- paste(t1$month, t1$year)
    }
    
    t2 <- t1 %>%
      mutate(monlabel = factor(monlabel, ordered = TRUE)) %>%
      mutate(monlabel = fct_inorder(monlabel)) %>%
      mutate(monthweek = woy - min(woy),
             y = max(monthweek) - monthweek + 1) %>%
      mutate(weekend = ifelse(dow == 0 | dow == 6, 1, 0))
    
    
    if(is.null(special.days)) {
      special.col <- "white"
    } else {
      
      if(is.character(special.days)) {
        if (length(special.days) == length(dates)) {
          fills <- special.days
        } else {
          if (special.days == "weekend") {
            fills <- t2$weekend
          }
        }
      } else {
        
        if(gradient == TRUE) {
          fills <- special.days
        } else {
          fills[special.days] <- 1
        }
      }
    }
  }
  
  df <- data.frame(week = weekdays,
                   pos.x = 0:6,
                   pos.y = rep(max(t2$monthweek) + 1.75, 7))
  
  if(missing(title)) {
    
    if(!is.null(start_date) & !is.null(end_date)) {
      
      title <- paste0(format(as.Date(start_date), "%m"), "/", format(as.Date(start_date), "%Y"), " - ",
                      format(as.Date(end_date), "%m"), "/", format(as.Date(end_date), "%Y"))
      
    }else{
      
      if(is.null(month)) {
        title <- year
      } else {
        title <- levels(t2$monlabel)
      }
    }
  }
  
  
  if(is.null(month)) {
    
    if(lunar == TRUE & l != FALSE) {
      warning("Lunar phases are only available for monthly calendars")
    }
    
    # p <- ggplot(t2, aes(dow, y)) +
    #   geom_tile(aes(fill = fills), color = col, size = lwd, linetype = lty) + scale_colour_manual(values = ordered_colors) + scale_fill_discrete(breaks=desired_order)
    
    p <- ggplot(t2, aes(dow, y)) +
      geom_tile(aes(fill = fills), color = col, size = lwd, linetype = lty) + scale_fill_manual(values = ordered_colors, breaks= desired_order, labels = desired_order, na.value = "white", na.translate = FALSE)
    
    if(is.character(special.days) & wend & length(unique(special.days) == length(dates))) {
      #p <- p + scale_fill_manual(values = special.col, labels = levels(as.factor(fills)), na.value = "white", na.translate = FALSE)
      #p <- p + scale_fill_manual(values = ordered_colors, breaks= desired_order, labels = desired_order, na.value = "white", na.translate = FALSE)
      #p <- p + scale_color_manual(breaks= desired_order,values = ordered_colors,na.value = "white", na.translate = FALSE,name="Means")
      # scale_colour_manual(breaks = levels(DSm$variable),
      #                     values = c('red', 'green', 'blue'))
    } else {
      p <- p + scale_fill_gradient(low = low.col, high = special.col)
    }
    
    p <- p + facet_wrap( ~ monlabel, ncol = ifelse(orientation == "landscape" | orientation == "l", 4, 3), scales = "free") +
      ggtitle(title) +
      labs(subtitle = subtitle) +
      scale_x_continuous(expand = c(0.01, 0.01), position = "top",
                         breaks = seq(0, 6), labels = weekdays) +
      scale_y_continuous(expand = c(0.05, 0.05)) +
      geom_text(data = t2, aes(label = gsub("^0+", "", format(date, "%d"))),
                size = day.size, family = font.family,
                color = days.col, fontface = font.style) +
      labs(fill = legend.title) +
      theme(panel.background = element_rect(fill = NA, color = NA),
            strip.background = element_rect(fill = mbg.col, color = mbg.col),
            plot.background = element_rect(fill = bg.col),
            panel.grid = element_line(colour = ifelse(bg.img ==  "", bg.col, "transparent")),
            strip.text.x = element_text(hjust = months.pos, face = font.style, color = months.col, size = months.size),
            legend.title = element_text(),
            axis.ticks = element_blank(),
            axis.title = element_blank(),
            axis.text.y = element_blank(),
            axis.text.x = element_text(colour = weeknames.col, size = weeknames.size * 2.25),
            plot.title = element_text(hjust = 0.5, size = title.size, colour = title.col),
            plot.subtitle = element_text(hjust = 0.5, face = "italic", colour = subtitle.col, size = subtitle.size),
            legend.position = legend.pos,
            plot.margin = unit(c(1 * margin, 0.5 * margin, 1 * margin, 0.5 * margin), "cm"),
            text = element_text(family = font.family, face = font.style),
            strip.placement = "outsite")
    
    if(bg.img != "") {
      p <- ggbackground(p, bg.img)
    }
    
    # print(p)
    
  } else {
    
    tidymoons <- data.frame(
      x = t2$dow + 0.35,
      y =  t2$y + 0.3,
      ratio = moon,
      right = right
    )
    
    tidymoons2 <- data.frame(
      x = t2$dow + 0.35,
      y =  t2$y + 0.3,
      ratio = 1 - moon,
      right = !right
    )
    
    p <- ggplot(t2, aes(dow, y)) +
      geom_tile(aes(fill = fills), color = col, size = lwd, linetype = lty) + scale_fill_manual(values = ordered_colors, breaks= desired_order, labels = desired_order, na.value = "white", na.translate = FALSE)
    
    # p <- ggplot(t2, aes(dow, y)) +
    #   geom_tile(aes(fill = fills), color = col, size = lwd, linetype = lty) + scale_colour_manual(values = ordered_colors) + scale_fill_discrete(breaks=desired_order)
    # p <- ggplot(t2, aes(dow, y)) +
    #   geom_tile(aes(fill = fills), color = col, size = lwd, linetype = lty) + scale_fill_discrete(breaks=desired_order) + scale_fill_manual(values = ordered_colors, name = desired_order, 
    #                                                         guide = guide_legend(reverse = FALSE)) 
    # geom_tile(aes(fill = fills), color = col, size = lwd, linetype = lty)+ scale_fill_discrete(breaks=desired_order)
    
    if(lunar == TRUE){
      p <- p + geom_moon(data = tidymoons, aes(x, y, ratio = ratio, right = right), size = lunar.size, fill = "white") +
        geom_moon(data = tidymoons2, aes(x, y, ratio = ratio, right = right), size = lunar.size, fill = lunar.col)
    }
    
    
    if(is.character(special.days) & wend & length(unique(special.days) == length(dates))) {
      # p <- p + scale_fill_manual(values = special.col, labels = levels(as.factor(fills)), na.value = "white", na.translate = FALSE)
      #p <- p + scale_fill_manual(values = special.col, labels = desired_order, na.value = "white", na.translate = FALSE, guide = guide_legend(reverse = FALSE,order = 1))
      #p <- p + scale_color_manual(values = ordered_colors) + scale_fill_discrete(labels = desired_order,na.value = "white", na.translate = FALSE)
      #p <- p + scale_color_manual(breaks= desired_order,values = ordered_colors,na.value = "white", na.translate = FALSE,name="Means")
      #p <- p + scale_fill_manual(values = ordered_colors, breaks= desired_order, labels = desired_order, na.value = "white", na.translate = FALSE)
    } else {
      p <- p + scale_fill_gradient(low = low.col, high = special.col)
    }
    
    p <- p + ggtitle(title) +
      labs(subtitle = subtitle) +
      geom_text(data = df, aes(label = week, x = pos.x, y = pos.y), size = weeknames.size, family = font.family, color = weeknames.col, fontface = font.style) +
      geom_text(aes(label = texts), color = text.col, size = text.size, family = font.family) +
      # scale_x_continuous(expand = c(0.01, 0.01), position = "top",
      #                   breaks = seq(0, 6), labels = weekdays) +
      scale_y_continuous(expand = c(0.05, 0.05)) +
      geom_text(data = t2, aes(label = 1:nrow(filler), x = dow -0.4, y = y + 0.35), size = day.size, family = font.family, color = days.col, fontface = font.style) +
      labs(fill = legend.title) +
      theme(panel.background = element_rect(fill = NA, color = NA),
            strip.background = element_rect(fill = NA, color = NA),
            plot.background = element_rect(fill = bg.col),
            panel.grid = element_line(colour = ifelse(bg.img ==  "", bg.col, "transparent")),
            strip.text.x = element_text(hjust = 0, face = "bold", size = months.size),
            legend.title = element_text(),
            axis.ticks = element_blank(),
            axis.title = element_blank(),
            axis.text.y = element_blank(),
            axis.text.x = element_blank(),
            plot.title = element_text(hjust = 0.5, size = title.size, colour = title.col),
            plot.subtitle = element_text(hjust = 0.5, face = "italic", colour = subtitle.col, size = subtitle.size),
            legend.position = legend.pos,
            plot.margin = unit(c(1 * margin,  0.5 * margin, 1 * margin,  0.5 * margin), "cm"),
            text = element_text(family = font.family, face = font.style),
            strip.placement = "outsite")
    
    if(bg.img != "") {
      p <- ggbackground(p, bg.img)
    }
    
    # print(p)
    
  }
  
  if(pdf == FALSE & doc_name != ""){
    warning("Set pdf = TRUE to save the current calendar")
  }
  
  if(pdf == TRUE) {
    
    switch (papersize,
            A6 = {
              a <- 148
              b <- 105
              
            },
            A5 = {
              a <- 210
              b <- 148
              
            },
            A4 = {
              a <- 297
              b <- 210
            },
            A3 = {
              a <- 420
              b <- 297
            },
            A2 = {
              a <- 594
              b <- 420
            },
            A1 = {
              a <- 841
              b <- 594
            },
            A0 = {
              a <- 1189
              b <- 841
            },
    )
    
    
    if(doc_name == "") {
      if(!is.null(month)) {
        
        doc_name <- paste0("Calendar_", tolower(t2$month[1]), "_", year, ".pdf")
        
      } else {
        if(!is.null(start_date) & !is.null(end_date)) {
          doc_name <- paste0("Calendar_", start_date, "_", end_date, ".pdf")
        } else {
          doc_name <- paste0("Calendar_", year, ".pdf")
        }
      }
      
      
    } else {
      doc_name <- paste0(doc_name, ".pdf")
    }
    
    if(orientation == "landscape" | orientation == "l") {
      ggsave(filename = if(!file.exists(doc_name)) doc_name else stop("File does already exist!"),
             height = b, width = a, units = "mm")
    } else {
      ggsave(filename = if(!file.exists(doc_name)) doc_name else stop("File does already exist!"),
             width = b, height = a, units = "mm")
    }
  }
  
  return(p)
}
#####
bissextile<-function(year){
  if((year %% 4) == 0) {
    if((year %% 100) == 0) {
      if((year %% 400) == 0) {
        val=1
      } else {
        val=0
      }
    } else {
      val=1
    }
  } else {
    val=0
  }
  return(val)
}
######

######
station<-function(chemin='~/Documents/Tchad/Controle_Qualite/'){
  don<-read.table(paste0(chemin,'/stations.txt'),as.is = T)
  colnames(don)<-c('ID','STAT_NAME','LATITUDE','LONGITUDE','ALTITUDE','COUNTRY','ZONE')
  don<-as.data.frame(don)
  return(don)
}

plot_jpeg = function(path, add=FALSE,titre='')
  ### modified from https://stackoverflow.com/questions/9543343/plot-a-jpg-image-using-base-graphics-in-r
{
  require('jpeg')
  jpg = readJPEG(path, native=T) # read the file
  res = dim(jpg)[2:1] # get the resolution, [x, y]
  if (!add) # initialize an empty plot area if add==FALSE
   plot(1,1,xlim=c(1,res[1]),ylim=c(1,res[2]),asp=1,type='n',xaxs='i',yaxs='i',xaxt='n',yaxt='n',
        xlab='',ylab='',bty='n',main=titre,font.main=2,cex.main=3)
  rasterImage(jpg,1,1,res[1],res[2])
}
## lancer plusieurs stations


rsoi_station<-function(zone='Sahelian',fOnset=as.Date('1981-09-01'),xmm=20,yjours=3,njours=5,seche=0.85,mjours=10,pendant=30,available=360,entete='hoclm',
                       fCessation=as.Date('1981-04-01'),maxend=10,endjours=7,periode=10,seqseche=50,pet=5,cap=100,short='Aug'){

  if(file.exists('resultats/ensemble.txt')){ 
    file.remove('resultats/ensemble.txt')
  }
  
   stat<-read.table('stations.txt',as.is = T)
   colnames(stat)<-c('ID','STAT_NAME','LATITUDE','LONGITUDE','ALTITUDE','COUNTRY','ZONE')
   
    if(zone != 'All'){
      stat<-stat[which(stat$ZONE == zone),]
    }
   
   stat<-as.data.frame(stat)
   
   write.table(t(c('Year','Available','Onset_date','Seq_O','Seq_OF','Seq_OE','length_O','P_onset','J_onset','Cessation_date1','Cessation_date2',
                   'J_cessation1','J_cessation2','P_cessation1','P_cessation2','Seq_CT1','Seq_CT1F','Seq_CT1E','Seq_CT2','Seq_CT2F','Seq_CT2E','Seq_CM1',
                   'Seq_CM1F','Seq_CM1E','Seq_CM2','Seq_CM2F','Seq_CM2E','length1','length2','first1','end1','long1','first2','end2','long2','Id')),
               'resultats/ensemble.txt',append = T,row.names = F,col.names = F,quote = F,sep=',')

   
   for(id in as.numeric(as.character(stat$ID))){
   
     write.table(cbind(rsoi(paste0('donnees/',entete,id,'.txt'),fOnset=fOnset,xmm=xmm,yjours=yjours,njours=njours,seche=seche,mjours=mjours,pendant=pendant,available=available,
                            fCessation=fCessation,maxend=maxend,endjours=endjours,periode=periode,seqseche=seqseche,pet = pet,cap = cap,short=short),id),'resultats/ensemble.txt',
                 append = T,row.names = F,col.names = F,quote = F,sep=',')
   }
   file.copy('resultats/ensemble.txt', paste0('resultats/ensemble_',zone,'.txt'),overwrite = TRUE)
}
##########
ftable<-function(x,fOnset=as.Date('1981-09-01')){
  #@ x: an R-climdex formatted data.frame (if open = FALSE)  or the full path to a file containing the same (if open = TRUE)
  #fOnest: the first jour to be considered as possible RSOnset day, in format month-day, e.g. '09-01' for First September 
  # objective: conversion table between julian days and dates 
  
  ka<-miss(x)
  ka<-ka[order(ka[,1],ka[,2],ka[,3]),];names(ka)<-c('Year','Month','Day','RR','TX','TN')
  fday<-paste(ka[1,1],ka[1,2],ka[1,3],sep='-')
  lday<-paste(ka[nrow(ka),1],ka[nrow(ka),2],ka[nrow(ka),3],sep='-')
  calendar<-seq(as.Date(fday),as.Date(lday),by='1 days')
  ku<-data.frame(Year=as.numeric(substring(calendar,1,4)),Month=as.numeric(substring(calendar,6,7)),Day=as.numeric(substring(calendar,9,10)))
  kuka<-merge(ku,ka,all=TRUE)
  kuka<-kuka[order(kuka[,1],kuka[,2],kuka[,3]),]
  kuky<-putjulian(kuka)
  fOnset<-as.character(fOnset)
  if(as.numeric(substring(fOnset,6,7))==1 & as.numeric(substring(fOnset,9,10))==1){
    kuka<-putjulian(kuka)
  }else{
    kuka<-putjulian(kuka)
    val<-kuka$p[kuka$Month==as.numeric(as.character(substring(fOnset,6,7)))][as.numeric(substring(fOnset,9,10))]
    kuka$p<-kuka$p-val+1
    kuka$p[which(kuka$p < 0)]<-kuka$p[which(kuka$p < 0)]+366
    kuka$p[which(kuka$p == 0)]<-366
  }
  kuka<-as.data.frame(cbind(kuka,kuky$p))
  mat<-as.data.frame(kuka[,c(1,2,3,4,8)])
  colnames(mat)<-c('Year','Month','Day','pn','j')
  return(mat)
}
##### maxima length of dry spell ####
maxima<- function(done,maxi1){
  b<-rle(done)
fins <- cumsum(b$lengths)
debuts <- fins - b$lengths + 1
indices <- mapply(seq, debuts, fins)

ind <- unlist(indices[b$values == 0 & b$lengths == maxi1])

return(ind)
}
##########
library(DataCombine)

miss<-function(y){

  ka<-read.table(as.character(y),header = F,na.strings = c('-99.9','','-999.9'))
  tab<-seq.Date(as.Date(paste(ka$V1[1],ka$V2[1],ka$V3[1],sep = '-')),as.Date(paste(ka$V1[nrow(ka)],ka$V2[nrow(ka)],ka$V3[nrow(ka)],sep = '-')),
                by='day')
  if(nrow(ka)!=length(tab)){
    id<-which(!(tab %in% as.Date(paste(ka$V1,ka$V2,ka$V3,sep = '-'))))
    for(i in id){
      ka<-InsertRow(ka,NewRow = c(matrix(as.numeric(as.character(unlist(strsplit(as.character(tab[i]),'-')))),ncol=3,byrow=T),rep(-99.9,3)),
                    RowNum = i)
    }
  }
  return(ka)
  
}

##############
rsoi<-function(x,fOnset=as.Date('1981-09-01'),xmm=20,yjours=3,njours=5,seche=0.85,mjours=10,pendant=21,available=330,
               fCessation=as.Date('1981-04-01'),maxend=10,endjours=7,periode=10,seqseche=50,pet=5,cap=100,short='Aug'){

  #@ x: an R-climdex formatted data.frame (if open = FALSE)  or the full path to a file containing the same (if open = TRUE)
  #fOnest: the first jour to be considered as possible RSOnset day, in format month-day, e.g. '09-01' for First September 
  #(@ date: the first jour to be considered as possible RSOnset day, in julian days, e.g. 10 = 10/01)
  #@ xmm: cummulated rainfall in mm. to lauch the season
  #@ yjours: number of days for accumulation of xmm 
  # e.g: xmm = 10 , yjours = 5, will consider accums. of 10 mm in 5 days
  #@ seche: value in mm to declare a dry day (defaulted to 0, although in most ETCCDI stuff, the value is 1)  
  #@ mjours: maximum dry days after the potential onset
  #@ pendant: length of the sequence to count mjours
  # e.g. seche = 10, pendant = 21, will allow a maximum of 10 dry days in the 21 days following the potential onset
  #fCessation: first day (in format month-day) to look for the cessation, e.g. '04-01 for First April
  #(@ dateend: first day (julian) to look for the cessation)
  #@ maxend: milimeters accum. to declare cessation
  #@ endjours: perdiod of accum. for cessation
  # e.g., dateend = 240, maxen = 10 and endjours = 7, will look to the last day with 10 mm in 7 days after julian 240
  # available: minimum number of available rainfall values. Set to 360, extremely important to kee high, else the indices are not reliable
  # RETURNS: 
  # a data frame with year, onset, cessation, length (cessation - onset + 1)  and available years
  # NOTE: year with not enough values or with no valid onset or cessation are not returned  
  
  
  
  #Objective: computes rainy season onset, given the definition:   
  
  # date: in julian days. 
  # xmm in mm
  # yjours  
  #  Le jour après une "date" où "Xmm" dans "Yjours", avec un maximum de période "sèche" de D jours pendant le prochain "M jours"
  
  #  ex. Le jour après le 1er Avril où 20 mm dans 3  jours, avec un maximum de période sèche de 7  jours  pendant  le prochain 21 jours
  
  # date (as string, four digits, e.g. "0401"), xmm, yjours,seche,mjours, described in the above definition
  # x: data.frame with dates and rainfall. RClimdex format.    
  # minval: minimum rainfall values to compute the index  
  # available: minimum available raifall values in a year to be considered
  
  
  ## FIn  
  #  Le dernier jour de la période de 7  jours après le 1er  Septembre où le maximum de cumule de précipitation est de 10 mm
  
  ka<-miss(x)
  ka<-ka[order(ka[,1],ka[,2],ka[,3]),];names(ka)<-c('Year','Month','Day','RR','TX','TN')
  nas<-function(x){length(which(!is.na(x)))}
  kanas<-aggregate(ka$RR,by=list(ka$Year), FUN = nas);names(kanas)<-c('Year','Available')
  fday<-paste(ka[1,1],ka[1,2],ka[1,3],sep='-')
  lday<-paste(ka[nrow(ka),1],ka[nrow(ka),2],ka[nrow(ka),3],sep='-')
  calendar<-seq(as.Date(fday),as.Date(lday),by='1 days')
  ku<-data.frame(Year=as.numeric(substring(calendar,1,4)),Month=as.numeric(substring(calendar,6,7)),Day=as.numeric(substring(calendar,9,10)))
  kuka<-merge(ku,ka,all=TRUE)  
  kuka<-kuka[order(kuka[,1],kuka[,2],kuka[,3]),]
  
  kuke<-ftable(x,fOnset = fOnset)
  kuka<-as.data.frame(cbind(kuka,kuke[,c(4,5)]))
  fOnset<-as.character(fOnset)

  date<-1
  kuka$RR1<-kuka$RR
  kuka$RR1[kuka$RR1<=seche]<-0
 # kuka$YJOURS<-rollapply(kuka$RR1,yjours,sum,fill=NA,align='right')
  kuka$YJOURS<-rollapply(kuka$RR1,yjours,sum,fill=NA,align='left')
  trote<-function(x) {ifelse(max(with(rle(x), lengths[values <= 0])) <= mjours,1,0)}
  kuka$PENDANT<-rollapply(kuka$RR1,pendant,trote,fill=NA,align='left')
  
  #if(njours==0 | njours < yjours){
  if(njours==0){
    kuka$PENDANT4<-1
  }else{
    trote<-function(x) {ifelse(length(which(x > 0)) >= njours,1,0)}
    kuka$PENDANT4<-rollapply(kuka$RR1,njours,trote,fill=NA,align='left')
    #kuka$PENDANT4<-rollapply(kuka$RR1,njours,trote,fill=NA,align='right')
  }
  kuka$DATE<-ifelse(kuka$YJOURS > xmm & kuka$p >= date & kuka$PENDANT == 1 & kuka$PENDANT4 == 1, 1, 0)
  ki<-kuka[which(kuka$DATE == 1),]

  koko<-array(dim = c(length(as.numeric(substring(fday,1,4)):as.numeric(substring(lday,1,4))),6))
  i<-1
  for(ann in as.numeric(substring(fday,1,4)):as.numeric(substring(lday,1,4))){
    if( as.numeric(substring(fOnset,6,7))==1){
      id<-which(ki$Year==ann & ki$Month %in% seq(as.numeric(substring(fOnset,6,7)),as.numeric(substring(fCessation,6,7))) & 
                  ki$Day %in% seq(as.numeric(substring(fOnset,9,10)),31))
    }else if( as.numeric(substring(fCessation,6,7)) >  as.numeric(substring(fOnset,6,7))){
      id<-which(ki$Year==ann & ki$Month %in% seq(as.numeric(substring(fOnset,6,7)),12) &
                  ki$Day %in% seq(as.numeric(substring(fOnset,9,10)),31))
    }else{
      id1<-which(ki$Year==ann & ki$Month %in% seq(as.numeric(substring(fOnset,6,7)),12) & 
                   ki$Day %in% seq(as.numeric(substring(fOnset,9,10)),31))
      id2<-which(ki$Year==ann+1 & ki$Month %in% seq(1,(as.numeric(substring(fCessation,6,7))-1)) &
                   ki$Day %in% seq(as.numeric(substring(fOnset,9,10)),31))
      
      id<-c(id1,id2)
    }
    if(length(id)==0){
      koko[i,1]<-ann
      koko[i,2]<-NA
      koko[i,3]<-NA
    }else{
      koko[i,1]<-ann
      aa<-ki$Year[id[1]]
      mm<-ki$Month[id[1]]
      dd<-ki$Day[id[1]]
      
      if(as.numeric(substring(fCessation,6,7)) >  as.numeric(substring(fOnset,6,7)) & 
         as.Date(paste(ann,mm,dd,sep='-'))>=as.Date(paste(ann,as.numeric(substr(fCessation,6,7)),as.numeric(substr(fCessation,9,10)),sep = '-'))){
        koko[i,2]<-NA
        koko[i,3]<-NA
        koko[i,4]<-NA
        koko[i,5]<-NA
        koko[i,6]<-NA
      }else{
      ##### onset dry spell ######
      id1<-which(kuka$Year==aa & kuka$Month==mm & kuka$Day==dd)+1
      id2<-which(kuka$Year==aa & kuka$Month==mm & kuka$Day==dd)+seqseche+1
      res<-try(max(with(rle(kuka$RR1[id1:id2]),lengths[values <= 0])),silent = T)
      
      if( res=='-Inf'|inherits(res,'try-error') |
          is.na(res)){
        koko[i,3]<-0
      }else{
        koko[i,3]<- res
        id3<-seq(id1,id2)
        ind<-maxima(done = kuka$RR1[id3],maxi1 = res)
        aa1<-kuka$Year[id3[ind[1]]]
        mm1<-kuka$Month[id3[ind[1]]]
        dd1<-kuka$Day[id3[ind[1]]]
        if(mm1 < 10){
          mm1<-paste0(0,mm1) }
        if(dd1 < 10){
          dd1<-paste0(0,dd1) }
        koko[i,4]<-paste(aa1,mm1,dd1,sep = '-')
        
        aa1<-kuka$Year[id3[ind[length(ind)]]]
        mm1<-kuka$Month[id3[ind[length(ind)]]]
        dd1<-kuka$Day[id3[ind[length(ind)]]]
        if(mm1 < 10){
          mm1<-paste0(0,mm1) }
        if(dd1 < 10){
          dd1<-paste0(0,dd1) }
        koko[i,5]<-paste(aa1,mm1,dd1,sep = '-')
      }
      
      
      if(mm < 10){
        mm<-paste0(0,mm) }
      if(dd < 10){
        dd<-paste0(0,dd) }
      koko[i,2]<-paste(aa,mm,dd,sep = '-')
      if(is.na(koko[i,2])|is.na(koko[i,4])){
        koko[i,6]<-NA
      }else{
        koko[i,6]<-length(seq.Date(as.Date(koko[i,2]),
                                   as.Date(koko[i,4]),by='day'))
      }
      
      }
    }
    
    i<-i+1
  }
  koko<-as.data.frame(koko)
  colnames(koko)<-c('Year','Onset_date','Seq_O','Seq_OF','Seq_OE','length_O')
  
  sol<-array(dim = c(nrow(koko),2))
  
  for(i in 1:nrow(koko)){
    id<-which(as.numeric(strsplit(as.character(koko$Onset_date[i]),'-')[[1]][1])==as.numeric(kuka$Year) &
                as.numeric(strsplit(as.character(koko$Onset_date[i]),'-')[[1]][2])==as.numeric(kuka$Month) &
                as.numeric(strsplit(as.character(koko$Onset_date[i]),'-')[[1]][3])==as.numeric(kuka$Day))
    if(length(id)==0){
      sol[i,1]<-NA
      sol[i,2]<-NA
    }else{
      sol[i,1]<-kuka$pn[id]
      sol[i,2]<-kuka$j[id]
    }
  }

  koko<-as.data.frame(cbind(koko,sol))
  colnames(koko)<-c('Year','Onset_date','Seq_O','Seq_OF','Seq_OE','length_O','P_onset','J_onset')
  koko<-merge(koko,kanas,all.x=TRUE,all.y=FALSE);keep<-which(koko$Available >= available)
  koko<-koko[keep,]
  
  ## cessation
  
  dateend<-kuka$j[which(as.numeric(kuka$Year)==as.numeric(substring(fday,1,4)) &
                          kuka$Month==as.numeric(as.character(substring(fCessation,6,7))) &
                          kuka$Day==as.numeric(as.character(substring(fCessation,9,10))))]
  
  
  
    wb<-array(NA,c(length(kuka$RR1),1))
    init<-0
    for(i in 1:length(kuka$RR1)){
      if(is.na(kuka$RR1[i])){
        init<-init-pet
      }else{
        init<-init+(kuka$RR1[i]-pet)
      }
      if(init >= 0){
        wb[i,]<-init
      }else{
        wb[i,]<-0
      }
      if(wb[i,] >= cap){
        wb[i,]<-cap
      }
      init<-wb[i,]
    }
    kuka$WB=wb

    kuka$PERIODEND1<-rollapply(kuka$WB,5,sum,fill=NA,align='left',na.rm=T)
    kuka$DATEEND1<-ifelse(kuka$PERIODEND1 == 0 & kuka$j >= dateend,1,0)
    
    trote<-function(x) {ifelse(length(which(x == cap))>0,1,0)}
    kuka$PERIODEND3<-rollapply(kuka$WB,periode,trote,fill=NA,align='left')
    kuka$DATEEND3<-ifelse(kuka$PERIODEND3==0 & kuka$j >= dateend,1,0)
    
    # kuka$PERIODEND2<-rollapply(kuka$RR1,endjours,sum,fill=NA,align='left',na.rm=T)
    kuka$PERIODEND2<-rollapply(kuka$RR1,endjours,sum,fill=NA,align='right',na.rm=T)
    kuka$DATEEND2<-ifelse(kuka$PERIODEND2 > maxend & kuka$j >= dateend,1,0)
    
    ki<-kuka[kuka$j>=dateend,]
  julito<-c(31,28,31,30,31,30,31,31,30,31,30,31)
  
  kuko<-array(dim = c(length(as.numeric(substring(fday,1,4)):as.numeric(substring(lday,1,4))),7))
  i<-1
  
  mon<-c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
  end_month<-which(as.character(short)==mon)
  
  for(ann in as.numeric(substring(fday,1,4)):as.numeric(substring(lday,1,4))){
    
    if(as.numeric(substring(fCessation,6,7)) > end_month){
      id1<-which(ki$Year==ann & ki$Month %in% seq(as.numeric(substring(fOnset,6,7)),12) &
                   ki$Day %in% seq(as.numeric(substring(fOnset,9,10)),31))
      id2<-which(ki$Year==ann+1 & ki$Month %in% seq(1,end_month) &
                   ki$Day %in% seq(as.numeric(substring(fOnset,9,10)),31))
      id<-c(id1,id2)
    }else{
      id<-which(ki$Year==ann & ki$Month %in% seq(as.numeric(substring(fCessation,6,7)),end_month) &
                  ki$Day %in% seq(as.numeric(substring(fCessation,9,10)),31))
    }
    
    k1<-as.data.frame(ki[id,])
    
    if(length(id)==0){
      kuko[i,1]<-ann
      kuko[i,2]<-NA
      kuko[i,6]<-NA
      kuko[i,3]<-NA
      kuko[i,4]<-NA
      kuko[i,7]<-NA
      kuko[i,5]<-NA
    }else{
      kuko[i,1]<-ann
      ## Cessation def1: water balance #####
      idi<-which(k1$DATEEND1==1 & k1$DATEEND3==1)

      if(length(idi)==0){
        kuko[i,2]<-NA
        kuko[i,6]<-NA
        kuko[i,3]<-NA
      }else{
        kuko[i,2]<-k1[idi,]$j[1]
        aa<-k1[idi,]$Year[1]
        mm<-k1[idi,]$Month[1]
        dd<-k1[idi,]$Day[1]
        kuko[i,6]<-kuka$pn[which(kuka$Year==aa & kuka$Month==mm & kuka$Day==dd)]
        if(mm < 10){
          mm<-paste0(0,mm) }
        if(dd < 10){
          dd<-paste0(0,dd) }
        kuko[i,3]<-paste(aa,mm,dd,sep = '-')
      }
      
      
        idi<-which(k1$DATEEND2==1)
        if(length(idi)==0){
          kuko[i,4]<-NA
          kuko[i,7]<-NA
          kuko[i,5]<-NA
        }else{
          kuko[i,4]<-k1[idi,]$j[length(idi)]
          aa<-k1[idi,]$Year[length(idi)]
          mm<-k1[idi,]$Month[length(idi)]
          dd<-k1[idi,]$Day[length(idi)]
         
          kuko[i,7]<-kuka$pn[which(kuka$Year==aa & kuka$Month==mm & kuka$Day==dd)]
          if(mm < 10){
            mm<-paste0(0,mm) }
          if(dd < 10){
            dd<-paste0(0,dd) }
          kuko[i,5]<-paste(aa,mm,dd,sep = '-')
        
        }
  }
    
    i<-i+1
  }
  if(as.numeric(substring(fOnset,6,7)) > as.numeric(substring(fCessation,6,7))){
    
    keke<-as.data.frame(cbind((as.numeric(as.character(kuko[,1])))-1,as.character(kuko[,3]),as.character(kuko[,5]),
                              as.numeric(as.character(kuko[,2])),as.numeric(as.character(kuko[,4])),as.numeric(as.character(kuko[,6])),as.numeric(as.character(kuko[,7]))))
    names(keke)<-c('Year','Cessation_date1','Cessation_date2','J_cessation1','J_cessation2','P_cessation1','P_cessation2')
  }else{
    keke<-as.data.frame(cbind((as.numeric(as.character(kuko[,1]))),as.character(kuko[,3]),as.character(kuko[,5]),
                              as.numeric(as.character(kuko[,2])),as.numeric(as.character(kuko[,4])),as.numeric(as.character(kuko[,6])),as.numeric(as.character(kuko[,7]))))
    names(keke)<-c('Year','Cessation_date1','Cessation_date2','J_cessation1','J_cessation2','P_cessation1','P_cessation2')
    
  }
  
  
  keke<-merge(keke,kanas,all.x=TRUE,all.y=FALSE);keep<-which(keke$Available >= available)
  keke<-keke[keep,]
  kiko<-as.data.frame(merge(koko,keke,all=FALSE))
  nom<-names(kiko)
  ###### cessation dry spell ####
  for(i in 1:nrow(kiko)){
    ####### Togo ######
      id1<-which(kuka$Year==as.numeric(substr(kiko$Onset_date[i],1,4)) & 
                   kuka$Month==as.numeric(substr(kiko$Onset_date[i],6,7)) & 
                   kuka$Day==as.numeric(substr(kiko$Onset_date[i],9,10)))+seqseche
      id2<-which(kuka$Year==as.numeric(substr(kiko$Cessation_date1[i],1,4)) & 
                   kuka$Month==as.numeric(substr(kiko$Cessation_date1[i],6,7)) & 
                   kuka$Day==as.numeric(substr(kiko$Cessation_date1[i],9,10)))
      id3<-which(kuka$Year==as.numeric(substr(kiko$Cessation_date2[i],1,4)) & 
                   kuka$Month==as.numeric(substr(kiko$Cessation_date2[i],6,7)) & 
                   kuka$Day==as.numeric(substr(kiko$Cessation_date2[i],9,10)))

      
      res1<-try(max(with(rle(kuka$RR1[id1:id2]),lengths[values <= 0])),silent = T)
      res2<-try(max(with(rle(kuka$RR1[id1:id3]),lengths[values <= 0])),silent = T)
      
      if( res1=='-Inf'|inherits(res1,'try-error') |
          is.na(res1)){
        kiko[i,16]<-NA
        kiko[i,17]<-NA
        kiko[i,18]<-NA
      }else{
        kiko[i,16]<- res1
        id4<-seq(id1,id2)
        ind<-maxima(done = kuka$RR1[id4],maxi1 = res1)
        aa1<-kuka$Year[id4[ind[1]]]
        mm1<-kuka$Month[id4[ind[1]]]
        dd1<-kuka$Day[id4[ind[1]]]
        if(mm1 < 10){
          mm1<-paste0(0,mm1) }
        if(dd1 < 10){
          dd1<-paste0(0,dd1) }
        kiko[i,17]<-paste(aa1,mm1,dd1,sep = '-')
        
        aa1<-kuka$Year[id4[ind[length(ind)]]]
        mm1<-kuka$Month[id4[ind[length(ind)]]]
        dd1<-kuka$Day[id4[ind[length(ind)]]]
        if(mm1 < 10){
          mm1<-paste0(0,mm1) }
        if(dd1 < 10){
          dd1<-paste0(0,dd1) }
        kiko[i,18]<-paste(aa1,mm1,dd1,sep = '-')
        
      }
      
      if( res2=='-Inf'|inherits(res2,'try-error') |
          is.na(res2)){
        kiko[i,19]<-NA
        kiko[i,20]<-NA
        kiko[i,21]<-NA
      }else{
        kiko[i,19]<- res2
        id4<-seq(id1,id3)
        ind<-maxima(done = kuka$RR1[id4],maxi1 = res2)
        aa1<-kuka$Year[id4[ind[1]]]
        mm1<-kuka$Month[id4[ind[1]]]
        dd1<-kuka$Day[id4[ind[1]]]
        if(mm1 < 10){
          mm1<-paste0(0,mm1) }
        if(dd1 < 10){
          dd1<-paste0(0,dd1) }
        kiko[i,20]<-paste(aa1,mm1,dd1,sep = '-')
        
        aa1<-kuka$Year[id4[ind[length(ind)]]]
        mm1<-kuka$Month[id4[ind[length(ind)]]]
        dd1<-kuka$Day[id4[ind[length(ind)]]]
        if(mm1 < 10){
          mm1<-paste0(0,mm1) }
        if(dd1 < 10){
          dd1<-paste0(0,dd1) }
        kiko[i,21]<-paste(aa1,mm1,dd1,sep = '-')
      }
   
    
    #### Mali #####
    
    id1<-which(kuka$Year==as.numeric(substr(kiko$Cessation_date1[i],1,4)) & 
                 kuka$Month==as.numeric(substr(kiko$Cessation_date1[i],6,7)) & 
                 kuka$Day==as.numeric(substr(kiko$Cessation_date1[i],9,10)))-seqseche+1
    id2<-which(kuka$Year==as.numeric(substr(kiko$Cessation_date1[i],1,4)) & 
                 kuka$Month==as.numeric(substr(kiko$Cessation_date1[i],6,7)) & 
                 kuka$Day==as.numeric(substr(kiko$Cessation_date1[i],9,10)))
    
    id3<-which(kuka$Year==as.numeric(substr(kiko$Cessation_date2[i],1,4)) & 
                 kuka$Month==as.numeric(substr(kiko$Cessation_date2[i],6,7)) & 
                 kuka$Day==as.numeric(substr(kiko$Cessation_date2[i],9,10)))-seqseche+1
    id4<-which(kuka$Year==as.numeric(substr(kiko$Cessation_date2[i],1,4)) & 
                 kuka$Month==as.numeric(substr(kiko$Cessation_date2[i],6,7)) & 
                 kuka$Day==as.numeric(substr(kiko$Cessation_date2[i],9,10)))
    
    res1<-try(max(with(rle(kuka$RR1[id1:id2]),lengths[values <= 0])),silent = T)
    res2<-try(max(with(rle(kuka$RR1[id3:id4]),lengths[values <= 0])),silent = T)

    if( res1=='-Inf'|inherits(res1,'try-error') |
        is.na(res1)){
      kiko[i,22]<-NA
      kiko[i,23]<-NA
      kiko[i,24]<-NA
    }else{
      kiko[i,22]<- res1
      id5<-seq(id1,id2)
      ind<-maxima(done = kuka$RR1[id5],maxi1 = res1)
      aa1<-kuka$Year[id5[ind[1]]]
      mm1<-kuka$Month[id5[ind[1]]]
      dd1<-kuka$Day[id5[ind[1]]]
      if(mm1 < 10){
        mm1<-paste0(0,mm1) }
      if(dd1 < 10){
        dd1<-paste0(0,dd1) }
      kiko[i,23]<-paste(aa1,mm1,dd1,sep = '-')
      
      aa1<-kuka$Year[id5[ind[length(ind)]]]
      mm1<-kuka$Month[id5[ind[length(ind)]]]
      dd1<-kuka$Day[id5[ind[length(ind)]]]
      if(mm1 < 10){
        mm1<-paste0(0,mm1) }
      if(dd1 < 10){
        dd1<-paste0(0,dd1) }
      kiko[i,24]<-paste(aa1,mm1,dd1,sep = '-')
    }
    
    if( res2=='-Inf'|inherits(res2,'try-error') |
        is.na(res2)){
      kiko[i,25]<-NA
      kiko[i,26]<-NA
      kiko[i,27]<-NA
    }else{
      kiko[i,25]<- res2
      
      id5<-seq(id3,id4)
      ind<-maxima(done = kuka$RR1[id5],maxi1 = res2)
      aa1<-kuka$Year[id5[ind[1]]]
      mm1<-kuka$Month[id5[ind[1]]]
      dd1<-kuka$Day[id5[ind[1]]]
      if(mm1 < 10){
        mm1<-paste0(0,mm1) }
      if(dd1 < 10){
        dd1<-paste0(0,dd1) }
      kiko[i,26]<-paste(aa1,mm1,dd1,sep = '-')
      
      aa1<-kuka$Year[id5[ind[length(ind)]]]
      mm1<-kuka$Month[id5[ind[length(ind)]]]
      dd1<-kuka$Day[id5[ind[length(ind)]]]
      if(mm1 < 10){
        mm1<-paste0(0,mm1) }
      if(dd1 < 10){
        dd1<-paste0(0,dd1) }
      kiko[i,27]<-paste(aa1,mm1,dd1,sep = '-')
    }
  # }
  }
colnames(kiko)<-c(nom,'Seq_CT1','Seq_CT1F','Seq_CT1E','Seq_CT2','Seq_CT2F','Seq_CT2E','Seq_CM1','Seq_CM1F','Seq_CM1E','Seq_CM2',
                  'Seq_CM2F','Seq_CM2E')  
   
  for(i in 1:nrow(kiko)){
    kiko$length1[i]<-NA
    kiko$length2[i]<-NA
    kiko$first1[i]<-NA
    kiko$end1[i]<-NA
    kiko$long1[i]<-NA
    kiko$first2[i]<-NA
    kiko$end2[i]<-NA
    kiko$long2[i]<-NA
    
    if(is.na(kiko$Onset_date[i]) |is.na(kiko$Cessation_date1[i])){
      kiko$length1[i]<-NA
      kiko$first1[i]<-NA
      kiko$end1[i]<-NA
      kiko$long1[i]<-NA
    }else{
      vali1<-try(as.character(length(seq.Date(as.Date(kiko$Onset_date[i]),
                                              as.Date(kiko$Cessation_date1[i]),by='day'))),silent = T)
      if(inherits(vali1,'try-error')){
        kiko$length1[i]<-NA
      }else{
        kiko$length1[i]<-as.numeric(vali1)
      }
      id1<-which(kuka$Year == as.numeric(substr(kiko$Onset_date[i],1,4)) & kuka$Month == as.numeric(substr(kiko$Onset_date[i],6,7)) & kuka$Day == as.numeric(substr(kiko$Onset_date[i],9,10)))
      id2<-which( kuka$Year == as.numeric(substr(kiko$Cessation_date1[i],1,4)) & kuka$Month == as.numeric(substr(kiko$Cessation_date1[i],6,7)) &
                    kuka$Day == as.numeric(substr(kiko$Cessation_date1[i],9,10)))
      id4<-seq(id1,id2)
      maxi1<-try(max(with(rle(kuka$WB[id4]), lengths[values <= 0])),silent = T)
      
      if(maxi1<=5){
        kiko$first1[i]<-NA
        kiko$end1[i]<-NA
        kiko$long1[i]<-NA
      }else{
        b<-rle(kuka$WB[id4])
        fins <- cumsum(b$lengths)
        debuts <- fins - b$lengths + 1
        indices <- mapply(seq, debuts, fins)
        
        ind <- unlist(indices[b$values == 0 & b$lengths == maxi1])
        
        aa<-kuka$Year[id4[ind[1]]]
        mm<-kuka$Month[id4[ind[1]]]
        dd<-kuka$Day[id4[ind[1]]]
      
        if(mm < 10){
          mm<-paste0(0,mm) }
        if(dd < 10){
          dd<-paste0(0,dd) }
        kiko$first1[i]<-paste(aa,mm,dd,sep='-')
        aa<-kuka$Year[id4[ind[length(ind)]]]
        mm<-kuka$Month[id4[ind[length(ind)]]]
        dd<-kuka$Day[id4[ind[length(ind)]]]
        
        if(mm < 10){
          mm<-paste0(0,mm) }
        if(dd < 10){
          dd<-paste0(0,dd) }
        kiko$end1[i]<-paste(aa,mm,dd,sep='-')
        kiko$long1[i]<-maxi1      
      }
      
    }
    if(is.na(kiko$Onset_date[i]) |is.na(kiko$Cessation_date2[i])){
      kiko$length2[i]<-NA
      kiko$first2[i]<-NA
      kiko$end2[i]<-NA
      kiko$long2[i]<-NA
    }else{
      vali2<-try(as.character(length(seq.Date(as.Date(kiko$Onset_date[i]),
                                              as.Date(kiko$Cessation_date2[i]),by='day'))),silent = T)
      
      if(inherits(vali2,'try-error')){
        kiko$length2[i]<-NA
      }else{
        kiko$length2[i]<-as.numeric(vali2)
      }
      id1<-which(kuka$Year == as.numeric(substr(kiko$Onset_date[i],1,4)) & kuka$Month == as.numeric(substr(kiko$Onset_date[i],6,7)) & kuka$Day == as.numeric(substr(kiko$Onset_date[i],9,10)))
      id3<-which( kuka$Year == as.numeric(substr(kiko$Cessation_date2[i],1,4)) & kuka$Month == as.numeric(substr(kiko$Cessation_date2[i],6,7)) &
                    kuka$Day == as.numeric(substr(kiko$Cessation_date2[i],9,10)))
      
      id5<-seq(id1,id3)
      
      
      maxi2<-try(max(with(rle(kuka$WB[id5]), lengths[values <= 0])),silent = T)
      
      
      if(maxi2<=5){
        kiko$first2[i]<-NA
        kiko$end2[i]<-NA
        kiko$long2[i]<-NA
      }else{
        b<-rle(kuka$WB[id5])
        fins <- cumsum(b$lengths)
        debuts <- fins - b$lengths + 1
        indices <- mapply(seq, debuts, fins)
        
        ind <- unlist(indices[b$values == 0 & b$lengths == maxi2])
        
        aa<-kuka$Year[id5[ind[1]]]
        mm<-kuka$Month[id5[ind[1]]]
        dd<-kuka$Day[id5[ind[1]]]
        if(mm < 10){
          mm<-paste0(0,mm) }
        if(dd < 10){
          dd<-paste0(0,dd) }
        kiko$first2[i]<-paste(aa,mm,dd,sep='-')
        aa<-kuka$Year[id5[ind[length(ind)]]]
        mm<-kuka$Month[id5[ind[length(ind)]]]
        dd<-kuka$Day[id5[ind[length(ind)]]]
        
        if(mm < 10){
          mm<-paste0(0,mm) }
        if(dd < 10){
          dd<-paste0(0,dd) }
        kiko$end2[i]<-paste(aa,mm,dd,sep='-')
        kiko$long2[i]<-maxi2      
      }
    }
    }
  kiko<-kiko[order(kiko$Year),]
  
  return(kiko)
}

####### plot cdf ####
plot_fun<-function(x,y,fOnset=as.Date('1984-08-01'),fCessation=as.Date('1984-06-01'),short='Jul',choice=1){
  ka<-read.table(y,na.strings=c('-99.9',''))
  tab<-ftable(y,fOnset = fOnset)
  fday<-paste(ka[1,1],ka[1,2],ka[1,3],sep='-')
  julito<-c(31,28,31,30,31,30,31,31,30,31,30,31)
  mon<-c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
  end_month<-which(as.character(short)==mon)
  
  par(mfrow = c(1,2))
  ### Debut ####
  m<-mean(as.numeric(as.character(x$J_onset)),na.rm=T)
  s<-sd(as.numeric(as.character(x$J_onset)),na.rm=T)
  if(is.na(s) | is.na(m)){
    plot.ecdf(qnorm(seq(0.01,0.99,0.01), 0,0),
              main='Onset CDF',xlab='Julian days',ylab = '',xaxt='n',ylim=c(0,1),col='green')
    abline(h=0.33,col='blue')
    abline(h=0.67,col='red')
  }else{
  beg<-tab$j[which(as.numeric(substring(fday,1,4))==tab$Year &
                      as.numeric(substring(as.character(fOnset),6,7))==tab$Month &
                      as.numeric(substring(as.character(fOnset),9,10))==tab$Day)]
  
  ran<-range(qnorm(seq(0.01,0.99,0.01), m,s))
  if(min(ran)<beg){
   ran<-range(beg,max(ran))
  }
  
  if(min(ran) < 0){
    id<-round(seq(min(ran),max(ran),10),0)
    id1<-which(id > 0 & id <= 365)
    id2<-which(id > 0 & id > 365)
    plot.ecdf(qnorm(seq(0.01,0.99,0.01), m,s),
              main='Onset CDF',xlab='Julian days',ylab = '',xaxt='n',col='green')
    if(length(id1)!=0 & length(id2)!=0){
      axis(1,at=id,labels = c(id[which(id <0)]+365,id[id1],(id[id2]-365)+4))
    }else if(length(id1)!=0 & length(id2)==0){
      axis(1,at=id,labels = c(id[which(id <0)]+365,id[id1]+4))
    }else{
      axis(1,at=id,labels = c(id[which(id <0)]+365,(id[id2]-365)+4))
    }
    
  }else if(min(ran) > 0 & max(ran) > 365){
    id<-round(seq(min(ran),max(ran),length.out=length(qnorm(seq(0.01,0.99,0.01), m,s))),0)
    plot.ecdf(qnorm(seq(0.01,0.99,0.01), m,s),
              main='Onset CDF',xlab='Julian days',ylab = '',xaxt='n',col='green')
    axis(1,at=qnorm(seq(0.01,0.99,0.01), m,s),labels = c(id[which(id <= 365)],(id[which(id > 365)]-365)+4))
    
  }else{
    id<-round(seq(min(ran),max(ran),length.out=length(qnorm(seq(0.01,0.99,0.01), m,s))),0)
    plot.ecdf(qnorm(seq(0.01,0.99,0.01), m,s),
              main='Onset CDF',xlab='Julian days',ylab = '',xaxt='n',col='green')
    axis(1,at=qnorm(seq(0.01,0.99,0.01), m,s),labels = id+4)
  }
  
  abline(h=0.33,col='blue')
  abline(h=0.67,col='red')
  }
  ### Fin ####
  if(choice==1){
    m<-mean(as.numeric(as.character(x$J_cessation1)),na.rm=T)
    s<-sd(as.numeric(as.character(x$J_cessation1)),na.rm=T)
  }else{
    m<-mean(as.numeric(as.character(x$J_cessation2)),na.rm=T)
    s<-sd(as.numeric(as.character(x$J_cessation2)),na.rm=T)
  }
  if(is.na(m) | is.na(s)){
    plot.ecdf(qnorm(seq(0.01,0.99,0.01), 0,0),main='Cessation CDF',xlab='Julian days',ylab = '',xaxt='n',ylim=c(0,1))
    abline(h=0.33,col='blue')
    abline(h=0.67,col='red')
  }else{
  beg<-tab$j[which(as.numeric(substring(fday,1,4))==tab$Year &
                     as.numeric(substring(as.character(fCessation),6,7))==tab$Month &
                     as.numeric(substring(as.character(fCessation),9,10))==tab$Day)]
  end<-tab$j[which(as.numeric(substring(fday,1,4))==tab$Year &
                     as.numeric(end_month)==tab$Month &
                     as.numeric(julito[end_month])==tab$Day)]
  
  ran<-range(qnorm(seq(0.01,0.99,0.01), m,s))
  
  if(min(ran)<beg){
    ran<-range(beg,max(ran))
  }
  if(max(ran)>end){
    ran<-range(min(ran),end)
  }
  id<-round(seq(min(ran),max(ran),length.out=length(qnorm(seq(0.01,0.99,0.01), m,s))),0)
  plot.ecdf(qnorm(seq(0.01,0.99,0.01), m,s),main='Cessation CDF',xlab='Julian days',ylab = '',xaxt='n')
  if(max(ran) > 365){
    axis(1,at=qnorm(seq(0.01,0.99,0.01), m,s),labels = c(id[which(id <= 365)],(id[which(id > 365)]-365)+4))
  }else{
    axis(1,at=qnorm(seq(0.01,0.99,0.01), m,s),labels = id+4)
  }
  abline(h=0.33,col='blue')
  abline(h=0.67,col='red')
  }
}

#############
tablecal1<-function(x,y,fCessation=as.Date('1984-05-01'),fOnset=as.Date('1984-08-01'),seqseche=50,seche=0.85,short='Jul',pet=5,cap=100,choice=1){
  ## Input: 
  ##@ x: an object coming from rsoi output or equivalent, with year/julian for debut and cessation
  
  ka<-read.table(y,na.strings=c('-99.9',''))
  tab<-ftable(y,fOnset = fOnset)
  tab$V5<-ka$V4
  tab$V5[tab$V5 <= seche]<-0
  
  wb<-array(NA,c(length(tab$V5),1))
  init<-0
  for(i in 1:length(tab$V5)){
    if(is.na(tab$V5[i])){
      init<-init-pet
    }else{
      init<-init+(tab$V5[i]-pet)
    }
    
    if(init >= 0){
      wb[i,]<-init
    }else{
      wb[i,]<-0
    }
    if(wb[i,] >= cap){
      wb[i,]<-cap
    }
    init<-wb[i,]
  }
  tab$V6<-wb
  
  fday<-paste(ka[1,1],ka[1,2],ka[1,3],sep='-')
  lday<-paste(ka[nrow(ka),1],ka[nrow(ka),2],ka[nrow(ka),3],sep='-')
  
  julianos<-array(dim=c(3,4))
  max<-array(NA,c(1,2))
  for(i in c(5,6)){
     j=i-4
    if(i==5){
      media<-mean(as.numeric(as.character(x$P_onset)),na.rm=TRUE)
      desvi<-sd(as.numeric(as.character(x$P_onset)),na.rm=TRUE)
      max[1,j]<-max(as.numeric(as.character(x$P_onset)),na.rm=TRUE)
    }
    if(i==6){
      if(choice==1){
      media<-mean(as.numeric(as.character(x$P_cessation1)),na.rm=TRUE)
      desvi<-sd(as.numeric(as.character(x$P_cessation1)),na.rm=TRUE)
      max[1,j]<-max(as.numeric(as.character(x$P_cessation1)),na.rm=TRUE)
      }else{
        media<-mean(as.numeric(as.character(x$P_cessation2)),na.rm=TRUE)
        desvi<-sd(as.numeric(as.character(x$P_cessation2)),na.rm=TRUE)
        max[1,j]<-max(as.numeric(as.character(x$P_cessation2)),na.rm=TRUE)
      }
    }
    julianos[j,]<-round(qnorm(c(0.0005,0.33,0.67,0.99),media,desvi))
  }
  
  if(length(which(is.na(julianos[2,])))==4 | length(which(is.na(julianos[1,])))==4){
    fechas<-matrix(NA,nrow=19,ncol=6)
  }else{
  
  if(julianos[1,1] <= 0 | julianos[1,1] < tab$pn[which(as.numeric(substring(fday,1,4))==tab$Year &
                                                      as.numeric(substring(as.character(fOnset),6,7))==tab$Month &
                                                      as.numeric(substring(as.character(fOnset),9,10))==tab$Day)])
  { julianos[1,1]<-tab$pn[which(as.numeric(substring(fday,1,4))==tab$Year &
                                 as.numeric(substring(as.character(fOnset),6,7))==tab$Month &
                                 as.numeric(substring(as.character(fOnset),9,10))==tab$Day)]}
  
  if(julianos[2,1] <= 0 | julianos[2,1] < tab$pn[which(as.numeric(substring(fday,1,4))==tab$Year &
                                                      as.numeric(substring(as.character(fCessation),6,7))==tab$Month &
                                                      as.numeric(substring(as.character(fCessation),9,10))==tab$Day)])
  { julianos[2,1]<-tab$pn[which(as.numeric(substring(fday,1,4))==tab$Year &
                                 as.numeric(substring(as.character(fCessation),6,7))==tab$Month &
                                 as.numeric(substring(as.character(fCessation),9,10))==tab$Day)]}
  
  if(julianos[1,4] > tab$pn[which(as.numeric(substring(fday,1,4))==tab$Year &
                                 as.numeric(substring(as.character(fCessation),6,7))==tab$Month &
                                 as.numeric(substring(as.character(fCessation),9,10))==tab$Day)])
  { julianos[1,4]<-tab$pn[which(as.numeric(substring(fday,1,4))==tab$Year &
                                 as.numeric(substring(as.character(fCessation),6,7))==tab$Month &
                                 as.numeric(substring(as.character(fCessation),9,10))==tab$Day)]-1}
  if(julianos[1,4] < julianos[1,3]){
    julianos[1,3]<-julianos[1,4]-2
  }
  
  for(k in c(1,2)){
    id<-which(julianos[k,] > julianos[k,4])
    if(length(id) != 0) {
      if(julianos[k,id] > julianos[k,id+1]) { julianos[k,id]<-julianos[k,id+1]}
    }
    id<-which(julianos[k,] < julianos[k,1])
    if(length(id) != 0){
      if(julianos[k,id] < julianos[k,id+1]){ julianos[k,id]<-julianos[k,id+1]}
    }
  }
    
  julito<-c(31,28,31,30,31,30,31,31,30,31,30,31)
  mon<-c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
  end_month<-which(as.character(short)==mon)
  
  
  maxf<-tab$pn[which(as.numeric(substring(fday,1,4))==tab$Year &
                      end_month==tab$Month &
                      julito[end_month]==tab$Day)]
  
  id<-which(julianos[2,] > maxf)
  julianos[2,id]<-maxf
  
  if(julianos[2,4] > 366){ julianos[2,4]<-max[1,2]}
  if(julianos[1,4] > 366){ julianos[1,4]<-max[1,1]}
  
  if(tab$Month[which(tab$pn==julianos[2,4])][1] > end_month){julianos[2,4]<-max[1,2]}
  
  
  jolines<-array(dim=c(3,6))
  jolines[,1]<-julianos[,1]
  jolines[,2]<-julianos[,2]-1
  jolines[,3]<-julianos[,2]
  jolines[,4]<-julianos[,3]
  jolines[,5]<-julianos[,3]+1
  jolines[,6]<-julianos[,4]
  
  for(k in c(1,2)){
    id<-which(jolines[k,] > jolines[k,6])
    if(length(id) != 0) {
      if(jolines[k,id] > jolines[k,id+1]) { jolines[k,id]<-jolines[k,id+1]}
    }
    id<-which(jolines[k,] < jolines[k,1])
    if(length(id) != 0){
      if(jolines[k,id] < jolines[k,id+1]){ jolines[k,id]<-jolines[k,id+1]}
    }
  }
  jolines[3,]<-jolines[2,]-jolines[1,]+1
  

  fechas<-array(dim=c(20,6))
  fechas[3,]<-paste0('|    ',as.numeric(jolines[3,]))
  
  for(k in 1:2){
    for(kk in 1:6){
      
      mes<-tab$Month[which(as.numeric(tab$pn)==as.numeric(jolines[k,kk]))][1]
      dia<-tab$Day[which(as.numeric(tab$pn)==as.numeric(jolines[k,kk]))][1]
      
      mes1<-mon[mes]
      fechas[k,kk]<-paste0(' |  ',dia,'-',mes1)
      
      ###### Onset dry spell definition #####
      if(k==1){
        mes<-tab$Month[which(as.numeric(tab$pn)==as.numeric(jolines[k,kk]))][1]
        dia<-tab$Day[which(as.numeric(tab$pn)==as.numeric(jolines[k,kk]))][1]
        
        val<-array(NA,c(length(as.numeric(substring(fday,1,4)):as.numeric(substring(lday,1,4))),3))
        i<-1
      for(an in as.numeric(substring(fday,1,4)):as.numeric(substring(lday,1,4))){
        
          id1<-which(tab$Year==an & tab$Month==mes & tab$Day==dia)+1
          id2<-which(tab$Year==an & tab$Month==mes & tab$Day==dia)+seqseche
          res<-try(max(with(rle(tab$V5[id1:id2]),lengths[values <= 0])),silent = T)
        
          if( res=='-Inf'|inherits(res,'try-error') |
              is.na(res)){
            val[i,1]<-0
            val[i,2]<-NA
            val[i,3]<-NA
          }else{
            val[i,1]<- res
            id3<-seq(id1,id2)
            ind<-maxima(done = tab$V5[id3],maxi1 = res)
            aa1<-tab$Year[id3[ind[1]]]
            mm1<-tab$Month[id3[ind[1]]]
            dd1<-tab$Day[id3[ind[1]]]
            if(mm1 < 10){
              mm1<-paste0(0,mm1) }
            if(dd1 < 10){
              dd1<-paste0(0,dd1) }
            val[i,2]<-paste(aa1,mm1,dd1,sep = '-')
            
            aa1<-tab$Year[id3[ind[length(ind)]]]
            mm1<-tab$Month[id3[ind[length(ind)]]]
            dd1<-tab$Day[id3[ind[length(ind)]]]
            if(mm1 < 10){
              mm1<-paste0(0,mm1) }
            if(dd1 < 10){
              dd1<-paste0(0,dd1) }
            val[i,3]<-paste(aa1,mm1,dd1,sep = '-')
            
          }
        
        i<-i+1
      }
    fechas[4,kk]<-paste0(' |  ',round(mean(as.numeric(val[,1]),na.rm = T),0))
    fechas[5,kk]<-paste0(' |  ',max(as.numeric(val[,1]),na.rm=T))
    id<-which(max(as.numeric(val[,1]),na.rm=T)==val[,1])
    if(length(id)>1){
      fechas[6,kk]<-paste0(' |  *',val[id[length(id)],2])
      fechas[7,kk]<-paste0(' |  *',val[id[length(id)],3])
    }else{
      fechas[6,kk]<-paste0(' |  ',val[id,2])
      fechas[7,kk]<-paste0(' |  ',val[id,3])
    }
    
    
      }
      
      ###### Cessation dry spell definition #####
      if(k==2){
        mes<-tab$Month[which(as.numeric(tab$pn)==as.numeric(jolines[k,kk]))][1]
        dia<-tab$Day[which(as.numeric(tab$pn)==as.numeric(jolines[k,kk]))][1]
        
        val<-array(NA,c(length(as.numeric(substring(fday,1,4)):as.numeric(substring(lday,1,4))),6))
        i<-1
        for(an in as.numeric(substring(fday,1,4)):as.numeric(substring(lday,1,4))){
  
          ###### Def1: Mali definition #######
          if(as.numeric(substr(fOnset,6,7)) > as.numeric(substr(fCessation,6,7))){
            if(mes %in% seq(as.numeric(substr(fOnset,6,7)),12)){
              id1<-which(tab$Year==an & tab$Month==mes & tab$Day==dia)-seqseche+1
            }else{
              id1<-which(tab$Year==an+1 & tab$Month==mes & tab$Day==dia)-seqseche+1
            }
          }else{
            id1<-which(tab$Year==an & tab$Month==mes & tab$Day==dia)-seqseche+1
          }
          
          if(as.numeric(substr(fOnset,6,7)) > as.numeric(substr(fCessation,6,7))){
            if(mes %in% seq(as.numeric(substr(fOnset,6,7)),12)){
              id2<-which(tab$Year==an & tab$Month==mes & tab$Day==dia)
            }else{
              id2<-which(tab$Year==an+1 & tab$Month==mes & tab$Day==dia)
            }
          }else{
            id2<-which(tab$Year==an & tab$Month==mes & tab$Day==dia)
          }
          
            res<-try(max(with(rle(tab$V5[id1:id2]),lengths[values <= 0])),silent = T)
            
          if( res=='-Inf'|inherits(res,'try-error') |
             is.na(res)){
            val[i,1]<-0
            val[i,2]<-NA
            val[i,3]<-NA
          }else{
            val[i,1]<- res
            id3<-seq(id1,id2)
            ind<-maxima(done = tab$V5[id3],maxi1 = res)
            aa1<-tab$Year[id3[ind[1]]]
            mm1<-tab$Month[id3[ind[1]]]
            dd1<-tab$Day[id3[ind[1]]]
            if(mm1 < 10){
              mm1<-paste0(0,mm1) }
            if(dd1 < 10){
              dd1<-paste0(0,dd1) }
            val[i,2]<-paste(aa1,mm1,dd1,sep = '-')
            
            aa1<-tab$Year[id3[ind[length(ind)]]]
            mm1<-tab$Month[id3[ind[length(ind)]]]
            dd1<-tab$Day[id3[ind[length(ind)]]]
            if(mm1 < 10){
              mm1<-paste0(0,mm1) }
            if(dd1 < 10){
              dd1<-paste0(0,dd1) }
            val[i,3]<-paste(aa1,mm1,dd1,sep = '-')
          }
         
            ####### Def2: Togo definition ####### 
          mes2<-tab$Month[which(as.numeric(tab$pn)==as.numeric(jolines[1,kk]))][1]
          dia2<-tab$Day[which(as.numeric(tab$pn)==as.numeric(jolines[1,kk]))][1]
          
          if(as.numeric(substr(fOnset,6,7)) > as.numeric(substr(fCessation,6,7))){
            if(mes2 %in% seq(as.numeric(substr(fOnset,6,7)),12)){
              id1<-which(tab$Year==an & tab$Month==mes2 & tab$Day==dia2)+seqseche
            }else{
              id1<-which(tab$Year==an+1 & tab$Month==mes2 & tab$Day==dia2)+seqseche
            }
          }else{
            id1<-which(tab$Year==an & tab$Month==mes2 & tab$Day==dia2)+seqseche
          }
          
          
          if(as.numeric(substr(fOnset,6,7)) > as.numeric(substr(fCessation,6,7))){
            if(mes %in% seq(as.numeric(substr(fOnset,6,7)),12)){
              id2<-which(tab$Year==an & tab$Month==mes & tab$Day==dia)
            }else{
              id2<-which(tab$Year==an+1 & tab$Month==mes & tab$Day==dia)
            }
          }else{
            id2<-which(tab$Year==an & tab$Month==mes & tab$Day==dia)
          }
          
          
          res<-try(max(with(rle(tab$V5[id1:id2]),lengths[values <= 0])),silent = T)
          
          if( res=='-Inf'|inherits(res,'try-error') |
              is.na(res)){
            val[i,4]<-0
            val[i,5]<-NA
            val[i,6]<-NA
          }else{
            val[i,4]<- res
            id3<-seq(id1,id2)
            ind<-maxima(done = tab$V5[id3],maxi1 = res)
            aa1<-tab$Year[id3[ind[1]]]
            mm1<-tab$Month[id3[ind[1]]]
            dd1<-tab$Day[id3[ind[1]]]
            if(mm1 < 10){
              mm1<-paste0(0,mm1) }
            if(dd1 < 10){
              dd1<-paste0(0,dd1) }
            val[i,5]<-paste(aa1,mm1,dd1,sep = '-')
            
            aa1<-tab$Year[id3[ind[length(ind)]]]
            mm1<-tab$Month[id3[ind[length(ind)]]]
            dd1<-tab$Day[id3[ind[length(ind)]]]
            if(mm1 < 10){
              mm1<-paste0(0,mm1) }
            if(dd1 < 10){
              dd1<-paste0(0,dd1) }
            val[i,6]<-paste(aa1,mm1,dd1,sep = '-')
          }
          i<-i+1
        }
        fechas[8,kk]<-paste0(' |  ',round(mean(as.numeric(val[,1]),na.rm = T),0))
        fechas[9,kk]<-paste0(' |  ',max(as.numeric(val[,1]),na.rm=T))
        id<-which(max(as.numeric(val[,1]),na.rm=T)==val[,1])
        if(length(id)>1){
          fechas[10,kk]<-paste0(' |  *',val[id[length(id)],2])
          fechas[11,kk]<-paste0(' |  *',val[id[length(id)],3])
        }else{
          fechas[10,kk]<-paste0(' |  ',val[id,2])
          fechas[11,kk]<-paste0(' |  ',val[id,3])
        }
      
      
        fechas[12,kk]<-paste0(' |  ',round(mean(as.numeric(val[,4]),na.rm = T),0))
        fechas[13,kk]<-paste0(' |  ',max(as.numeric(val[,4]),na.rm=T))
        id<-which(max(as.numeric(val[,4]),na.rm=T)==val[,4])
        if(length(id)>1){
          fechas[14,kk]<-paste0(' |  ',val[id[length(id)],5])
          fechas[15,kk]<-paste0(' |  ',val[id[length(id)],6])
        }else{
          fechas[14,kk]<-paste0(' |  ',val[id,5])
          fechas[15,kk]<-paste0(' |  ',val[id,6])
        }
        
        }
      
      
    }
  }
  ##### bilan hydrique et cumule de precipitation ##
  for(kk in 1:6){
    mes1<-tab$Month[which(as.numeric(tab$pn)==as.numeric(jolines[1,kk]))][1]
    dia1<-tab$Day[which(as.numeric(tab$pn)==as.numeric(jolines[1,kk]))][1]
    mes2<-tab$Month[which(as.numeric(tab$pn)==as.numeric(jolines[2,kk]))][1]
    dia2<-tab$Day[which(as.numeric(tab$pn)==as.numeric(jolines[2,kk]))][1]
    
    val<-array(NA,c(length(as.numeric(substring(fday,1,4)):as.numeric(substring(lday,1,4))),4))
    i<-1
    for(an in as.numeric(substring(fday,1,4)):(as.numeric(substring(lday,1,4))-1)){
      if(as.numeric(substr(fOnset,6,7)) > as.numeric(substr(fCessation,6,7))){
        if(mes1 %in% seq(as.numeric(substr(fOnset,6,7)),12)){
          id1<-which(tab$Year==an & tab$Month==mes1 & tab$Day==dia1)
        }else{
          id1<-which(tab$Year==an+1 & tab$Month==mes1 & tab$Day==dia1)
        }
      }else{
        id1<-which(tab$Year==an & tab$Month==mes1 & tab$Day==dia1)
      }
      
      
      if(as.numeric(substr(fOnset,6,7)) > as.numeric(substr(fCessation,6,7))){
        if(mes2 %in% seq(as.numeric(substr(fOnset,6,7)),12)){
          id2<-which(tab$Year==an & tab$Month==mes2 & tab$Day==dia2)
        }else{
          id2<-which(tab$Year==an+1 & tab$Month==mes2 & tab$Day==dia2)
        }
      }else{
        id2<-which(tab$Year==an & tab$Month==mes2 & tab$Day==dia2)
      }
      
      v<-try(max(with(rle(tab$V6[id1:id2]),lengths[values <= 0])),silent = T)
      
      if(inherits(v,'try-error')){
        
        next
        
      }else{
      if(v =='-Inf' | is.na(v)){
        val[i,1]<-0
        val[i,2]<-NA
        val[i,3]<-NA
      }else{
        val[i,1]<- v
        id3<-seq(id1,id2)
        ind<-maxima(done = tab$V6[id3],maxi1 = v)
        aa1<-tab$Year[id3[ind[1]]]
        mm1<-tab$Month[id3[ind[1]]]
        dd1<-tab$Day[id3[ind[1]]]
        if(mm1 < 10){
          mm1<-paste0(0,mm1) }
        if(dd1 < 10){
          dd1<-paste0(0,dd1) }
        val[i,2]<-paste(aa1,mm1,dd1,sep = '-')
        
        aa1<-tab$Year[id3[ind[length(ind)]]]
        mm1<-tab$Month[id3[ind[length(ind)]]]
        dd1<-tab$Day[id3[ind[length(ind)]]]
        if(mm1 < 10){
          mm1<-paste0(0,mm1) }
        if(dd1 < 10){
          dd1<-paste0(0,dd1) }
        val[i,3]<-paste(aa1,mm1,dd1,sep = '-')
      }
      
      val[i,4]<-sum(as.numeric(tab$V5[id1:id2]),na.rm = T)
      
      i<-i+1
    }
  }
    fechas[16,kk]<-paste0(' |  ',round(mean(as.numeric(val[,1]),na.rm = T),0))
    fechas[17,kk]<-paste0(' |  ',max(as.numeric(val[,1]),na.rm=T))
    id<-which(max(as.numeric(val[,1]),na.rm=T)==as.numeric(val[,1]))
    if(length(id)>1){
      fechas[18,kk]<-paste0(' |  *',val[id[length(id)],2])
      fechas[19,kk]<-paste0(' |  *',val[id[length(id)],3])
    }else{
      fechas[18,kk]<-paste0(' |  ',val[id,2])
      fechas[19,kk]<-paste0(' |  ',val[id,3])
    }
    
    fechas[20,kk]<-paste0(' |  ',round(mean(as.numeric(as.character(val[,4])),na.rm=T),1))
    
  }
  }

  htmlTable::htmlTable((fechas),cgroup=c('Early ','Normal','Late'),n.cgroup=c(2,3),header=rep(c('First','Last'),3),
                       rnames=c('Onset','Cessation','Length','Average maximum duration of the onset dry period','Maximum of the maximum duration of the onset dry period','Start','End','Average maximum duration of the cessation dry period (Def1)', 'Maximum of the maximum duration of cessation dry period (Def1)','Start','End',
                                'Average maximum duration of the cessation dry period (Def2)', 'Maximum of the maximum duration of cessation dry period (Def2)','Start','End','Average maximum duration of the soil dry period','Maximum of maximum duraton of soil dry period','Start','End','Cumulative rainfall'))
  }

rainy_duration<-function(x,choice=1){
  length<-array(dim=c(3,2))
  if(choice==1){
    media<-mean(as.numeric(as.character(x$length1)),na.rm=TRUE)
    desvi<-sd(as.numeric(as.character(x$length1)),na.rm=TRUE)
  }else{
    media<-mean(as.numeric(as.character(x$length2)),na.rm=TRUE)
    desvi<-sd(as.numeric(as.character(x$length2)),na.rm=TRUE)
  }
  
  length[1,1:2]<-c('<',round(qnorm(0.33,media,desvi),0))
  length[2,1:2]<-round(qnorm(c(0.33,0.67),media,desvi),0)
  length[3,1:2]<-c(round(qnorm(0.67,media,desvi),0),'<')
  
  htmlTable((length),header=c('Rainy season length (days)',''),
            rnames=c('short','normal','long'))
}
########## 
late_seeding<-function(x,y,crop,fOnset=as.Date('1981-09-01'),fCessation=as.Date('1981-04-01'),short='Sep',choice=1){
  
  ka<-miss(y)
  tab<-ftable(y,fOnset = fOnset)
  fday<-paste(ka[1,1],ka[1,2],ka[1,3],sep='-')
  
  julito<-c(31,28,31,30,31,30,31,31,30,31,30,31)
  mon<-c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
  end_month<-which(as.character(short)==mon)
  
  
  if(choice==1){
    media<-mean(as.numeric(as.character(x$P_cessation1)),na.rm=TRUE)
    desvi<-sd(as.numeric(as.character(x$P_cessation1)),na.rm=TRUE)
  }else{
    media<-mean(as.numeric(as.character(x$P_cessation2)),na.rm=TRUE)
    desvi<-sd(as.numeric(as.character(x$P_cessation2)),na.rm=TRUE)
  }

  end<-round(qnorm(0.67,media,desvi),0)
  media<-mean(as.numeric(as.character(x$P_onset)),na.rm=TRUE)
  desvi<-sd(as.numeric(as.character(x$P_onset)),na.rm=TRUE)
  beg<-round(qnorm(0.33,media,desvi),0)
  fechas<-array(dim = c(nrow(crop),7))
  
  if(is.na(end) | is.na(beg)){
    fechas[1:nrow(crop),1]<-as.character(crop[1:nrow(crop),1])
    fechas[1:nrow(crop),2]<-as.character(crop[1:nrow(crop),2])
    fechas[1:nrow(crop),3]<-paste(crop[1:nrow(crop),3],'days',sep=' ')
    fechas[1:nrow(crop),4:7]<-NA
  }else{
  maxf<-tab$pn[which(as.numeric(substring(fday,1,4))==tab$Year &
                       end_month==tab$Month &
                       julito[end_month]==tab$Day)]
  if(end > maxf) end<-maxf
  
  for(i in 1:nrow(crop)){
    ###### sowing date #####
    vali<-end-as.numeric(crop[i,3])
    mes<-tab$Month[which(as.numeric(tab$pn)==vali)][1]
    dia<-tab$Day[which(as.numeric(tab$pn)==vali)][1]
    
    
    fechas[i,1]<-as.character(crop[i,1])
    fechas[i,2]<-as.character(crop[i,2])
    fechas[i,3]<-paste(crop[i,3],'days',sep=' ')
  
    
    if(beg <= 0 | beg < tab$pn[which(as.numeric(substring(fday,1,4))==tab$Year &
                                    as.numeric(substring(as.character(fOnset),6,7))==tab$Month &
                                    as.numeric(substring(as.character(fOnset),9,10))==tab$Day)]){
      fechas[i,4]<-paste(substring(as.character(fOnset),9,10),mon[as.numeric(substring(as.character(fOnset),6,7))],sep = '-')
      beg <- tab$pn[which(as.numeric(substring(fday,1,4))==tab$Year &
                           as.numeric(substring(as.character(fOnset),6,7))==tab$Month &
                           as.numeric(substring(as.character(fOnset),9,10))==tab$Day)]
    }else{
      if(tab$Day[which(as.numeric(tab$pn)==beg)][1] < 10){
        fechas[i,4]<-paste(paste0('0',tab$Day[which(as.numeric(tab$pn)==beg)][1]),mon[tab$Month[which(as.numeric(tab$pn)==beg)][1]],sep = '-')
      }else{
        fechas[i,4]<-paste(tab$Day[which(as.numeric(tab$pn)==beg)][1],mon[tab$Month[which(as.numeric(tab$pn)==beg)][1]],sep = '-')
      }
    }

    if((is.na(dia) | is.na(mes) | (vali < beg))){
     fechas[i,4]<-"NA-NA"
      fechas[i,5]<-"NA-NA"
      fechas[i,6]<-"NA-NA"
      fechas[i,7]<-"NA-NA"
    }else{
      if(mes==2 & dia==29) dia=28
      if(dia < 10){
        fechas[i,5]<-paste0(paste0('0',dia),'-',mon[mes])
      }else{
        fechas[i,5]<-paste0(dia,'-',mon[mes])
      }
  
    if(dia %in% julito){
      dia<-1
      if(mes==12){
        mes<-1
      }else{
        mes<-mes+1
      }
      fechas[i,6]<-paste(substring(seq.Date(as.Date(as.character(paste(as.numeric(substring(fday,1,4)),mes,dia,sep = '-'))),
                                            by='day',length.out = as.numeric(crop[i,3]))[as.numeric(crop[i,3])],9,10),
                         mon[as.numeric(as.character(substring(seq.Date(as.Date(as.character(paste(as.numeric(substring(fday,1,4)),mes,dia,sep = '-'))),
                                                                        by='day',length.out = as.numeric(crop[i,3]))[as.numeric(crop[i,3])],6,7)))],sep = '-')
    }else{
      fechas[i,6]<-paste(substring(seq.Date(as.Date(as.character(paste(as.numeric(substring(fday,1,4)),mes,dia+1,sep = '-'))),
                                            by='day',length.out = as.numeric(crop[i,3]))[as.numeric(crop[i,3])],9,10),
                         mon[as.numeric(as.character(substring(seq.Date(as.Date(as.character(paste(as.numeric(substring(fday,1,4)),mes,dia+1,sep = '-'))),
                                                                        by='day',length.out = as.numeric(crop[i,3]))[as.numeric(crop[i,3])],6,7)))],sep = '-')
    }
      
      id<-which(strsplit(fechas[i,6],'-')[[1]][2]==mon)
      if(as.numeric(strsplit(fechas[i,6],'-')[[1]][1]) == julito[id]){
        if(id==12){
          fechas[i,7]<-paste0('01-',mon[1])
        }else{
          fechas[i,7]<-paste0('01-',mon[id+1])
        }
      }else{
        if(as.numeric(strsplit(fechas[i,6],'-')[[1]][1])+1 < 10){
          fechas[i,7]<-paste(paste0('0',as.numeric(strsplit(fechas[i,6],'-')[[1]][1])+1),strsplit(fechas[i,6],'-')[[1]][2],sep = '-')
        }else{
          fechas[i,7]<-paste(as.numeric(strsplit(fechas[i,6],'-')[[1]][1])+1,strsplit(fechas[i,6],'-')[[1]][2],sep = '-') 
        }
      }
    }
  }
  }
  

 htmlTable::htmlTable((fechas),header=c('Crops ','Varieties ','Length of cropping cycle ','Early start of sowing ',
                                        'Latest start of sowing date ',
                                        'Latest end of growing date ','Latest start of harvesting ')
           )
  
}


#######
calendrier<-function(res,vit,short='Dec'){
  #res: résultats du tablecal1
  #vit: résultats du late_seeding
  mois<-c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
  id<-which(mois==short)
  m<-12-id+1
  year<-as.numeric(format(Sys.Date(), "%Y"))
  sol<-bissextile(year)
  if(sol==0){
    julito<-c(31,28,31,30,31,30,31,31,30,31,30,31)
  }else{
    julito<-c(31,29,31,30,31,30,31,31,30,31,30,31)
  }
  
  if(m == 1){
    start_date <- as.Date(paste0(year,'-',m,'-1'))
    end_date <- as.Date(paste0(year,'-',id,'-',julito[id]))
  }else{
    start_date <- as.Date(paste0(year,'-',id,'-1'))
    end_date <- as.Date(paste0(year+1,'-',m,'-',julito[m]))
  }
  
  custom_dates<-seq(as.Date(start_date), as.Date(end_date), by = "1 day")
  myfills <- rep(NA, length(custom_dates))
  
  #### early onset ####
  if(m != 1 & which(mois==strsplit(strsplit(res[1,1],' ')[[1]][4],'-')[[1]][2]) <= m){
    start_early<-as.Date(paste0(strsplit(res[1,1],' ')[[1]][4],'-',year+1),format = '%d-%b-%Y')
  }else{
    start_early<-as.Date(paste0(strsplit(res[1,1],' ')[[1]][4],'-',year),format = '%d-%b-%Y')
  }
  
  if(m != 1 & which(mois==strsplit(strsplit(res[1,2],' ')[[1]][4],'-')[[1]][2]) <= m){
    end_early<-as.Date(paste0(strsplit(res[1,2],' ')[[1]][4],'-',year+1),format = '%d-%b-%Y')
  }else{
    end_early<-as.Date(paste0(strsplit(res[1,2],' ')[[1]][4],'-',year),format = '%d-%b-%Y')
  }
  
  #### normal onset ####
  if(m != 1 & which(mois==strsplit(strsplit(res[1,3],' ')[[1]][4],'-')[[1]][2]) <= m){
    start_normal<-as.Date(paste0(strsplit(res[1,3],' ')[[1]][4],'-',year+1),format = '%d-%b-%Y')
  }else{
    start_normal<-as.Date(paste0(strsplit(res[1,3],' ')[[1]][4],'-',year),format = '%d-%b-%Y')
  }
  if(m != 1 & which(mois==strsplit(strsplit(res[1,4],' ')[[1]][4],'-')[[1]][2]) <= m){
    end_normal<-as.Date(paste0(strsplit(res[1,4],' ')[[1]][4],'-',year+1),format = '%d-%b-%Y')
  }else{
    end_normal<-as.Date(paste0(strsplit(res[1,4],' ')[[1]][4],'-',year),format = '%d-%b-%Y')
  }
  ##### late onset ####
  if(m != 1 & which(mois==strsplit(strsplit(res[1,5],' ')[[1]][4],'-')[[1]][2]) <= m){
    start_late<-as.Date(paste0(strsplit(res[1,5],' ')[[1]][4],'-',year+1),format = '%d-%b-%Y')
  }else{
    start_late<-as.Date(paste0(strsplit(res[1,5],' ')[[1]][4],'-',year),format = '%d-%b-%Y')
  }
  if(m != 1 & which(mois==strsplit(strsplit(res[1,6],' ')[[1]][4],'-')[[1]][2]) <= m){
    end_late<-as.Date(paste0(strsplit(res[1,6],' ')[[1]][4],'-',year+1),format = '%d-%b-%Y')
  }else{
    end_late<-as.Date(paste0(strsplit(res[1,6],' ')[[1]][4],'-',year),format = '%d-%b-%Y')
  }
  
  early1 <- length(seq(as.Date(start_date), as.Date(start_early), by = "1 day"))
  early2 <- length(seq(as.Date(start_date), as.Date(end_early), by = "1 day"))
  myfills[c(early1:early2)]<-"Inicio temprano"
  
  normal1<-length(seq(as.Date(start_date), as.Date(start_normal), by = "1 day"))
  normal2 <- length(seq(as.Date(start_date), as.Date(end_normal), by = "1 day"))
  myfills[c(normal1:normal2)]<-"Inicio normal"
  
  late1<-length(seq(as.Date(start_date), as.Date(start_late), by = "1 day"))
  late2 <- length(seq(as.Date(start_date), as.Date(end_late), by = "1 day"))
  myfills[c(late1:late2)]<-"Inicio tardío"
  
  #### early cessation ####
  if(m != 1 & which(mois==strsplit(strsplit(res[2,1],' ')[[1]][4],'-')[[1]][2]) <= m){
    start_early<-as.Date(paste0(strsplit(res[2,1],' ')[[1]][4],'-',year+1),format = '%d-%b-%Y')
  }else{
    start_early<-as.Date(paste0(strsplit(res[2,1],' ')[[1]][4],'-',year),format = '%d-%b-%Y')
  }
  
  if(m != 1 & which(mois==strsplit(strsplit(res[2,2],' ')[[1]][4],'-')[[1]][2]) <= m){
    end_early<-as.Date(paste0(strsplit(res[2,2],' ')[[1]][4],'-',year+1),format = '%d-%b-%Y')
  }else{
    end_early<-as.Date(paste0(strsplit(res[2,2],' ')[[1]][4],'-',year),format = '%d-%b-%Y')
  }
  #### normal cessation ####
  if(m != 1 & which(mois==strsplit(strsplit(res[2,3],' ')[[1]][4],'-')[[1]][2]) <= m){
    start_normal<-as.Date(paste0(strsplit(res[2,3],' ')[[1]][4],'-',year+1),format = '%d-%b-%Y')
  }else{
    start_normal<-as.Date(paste0(strsplit(res[2,3],' ')[[1]][4],'-',year),format = '%d-%b-%Y')
  }
  if(m != 1 & which(mois==strsplit(strsplit(res[2,4],' ')[[1]][4],'-')[[1]][2]) <= m){
    end_normal<-as.Date(paste0(strsplit(res[2,4],' ')[[1]][4],'-',year+1),format = '%d-%b-%Y')
  }else{
    end_normal<-as.Date(paste0(strsplit(res[2,4],' ')[[1]][4],'-',year),format = '%d-%b-%Y')
  }
  ##### late onset ####
  if(m != 1 & which(mois==strsplit(strsplit(res[2,5],' ')[[1]][4],'-')[[1]][2]) <= m){
    start_late<-as.Date(paste0(strsplit(res[2,5],' ')[[1]][4],'-',year+1),format = '%d-%b-%Y')
  }else{
    start_late<-as.Date(paste0(strsplit(res[2,5],' ')[[1]][4],'-',year),format = '%d-%b-%Y')
  }
  if(m != 1 & which(mois==strsplit(strsplit(res[2,6],' ')[[1]][4],'-')[[1]][2]) <= m){
    end_late<-as.Date(paste0(strsplit(res[2,6],' ')[[1]][4],'-',year+1),format = '%d-%b-%Y')
  }else{
    end_late<-as.Date(paste0(strsplit(res[2,6],' ')[[1]][4],'-',year),format = '%d-%b-%Y')
  }
  
  early1 <- length(seq(as.Date(start_date), as.Date(start_early), by = "1 day"))
  early2 <- length(seq(as.Date(start_date), as.Date(end_early), by = "1 day"))
  myfills[c(early1:early2)]<-"Ceso temprano"
  
  normal1<-length(seq(as.Date(start_date), as.Date(start_normal), by = "1 day"))
  normal2 <- length(seq(as.Date(start_date), as.Date(end_normal), by = "1 day"))
  myfills[c(normal1:normal2)]<-"Ceso normal"
  
  late1<-length(seq(as.Date(start_date), as.Date(start_late), by = "1 day"))
  late2 <- length(seq(as.Date(start_date), as.Date(end_late), by = "1 day"))
  myfills[c(late1:late2)]<-"Ceso tardío"
  
  ###### latest date for sowing #####
  if(m != 1 & which(mois==strsplit(vit[1,4],'-')[[1]][2]) <= m){
    start_sowing<-as.Date(paste0(vit[1,4],'-',year+1),format = '%d-%b-%Y')
  }else{
    start_sowing<-as.Date(paste0(vit[1,4],'-',year),format = '%d-%b-%Y')
  }
  
  sowing<-length(seq(as.Date(start_date), as.Date(start_sowing), by = "1 day"))
  myfills[sowing]<-"Inicio temprano"
  
  for(n in 1:nrow(vit)){
    if(m != 1 & which(mois==strsplit(vit[n,5],'-')[[1]][2]) <= m){
      d1<-as.Date(paste0(vit[n,5],'-',year+1),format = '%d-%b-%Y')
    }else{
      d1<-as.Date(paste0(vit[n,5],'-',year),format = '%d-%b-%Y')
    }
    
    vari1<-length(seq(as.Date(start_date), as.Date(d1), by = "1 day"))
    myfills[vari1]<-paste0("Última siembra para ",vit[n,1]," (",strsplit(vit[n,3]," ")[[1]][1]," dìas)")
    
    d2<-as.Date(as.Date(start_sowing)+as.numeric(strsplit(vit[n,3]," ")[[1]][1]))
    vari2<-length(seq(as.Date(start_date), as.Date(d2), by = "1 day"))
    myfills[vari2]<-paste0("Cosecha temprana para ",vit[n,1]," (",strsplit(vit[n,3]," ")[[1]][1]," dìas)")
  }
  
  if(m != 1 & which(mois==strsplit(vit[1,7],'-')[[1]][2]) <= m){
    start_harvesting<-as.Date(paste0(vit[1,7],'-',year+1),format = '%d-%b-%Y')
  }else{
    start_harvesting<-as.Date(paste0(vit[1,7],'-',year),format = '%d-%b-%Y')
  }
  harvesting<-length(seq(as.Date(start_date), as.Date(start_harvesting), by = "1 day"))
  myfills[harvesting]<-"Última cosecha"
  
  # Desired order and colors
  desired_order <- c("Inicio temprano", "Inicio normal", "Inicio tardío", "Ceso temprano", "Ceso normal", "Ceso tardío", "Inicio de siembra",
                     paste0("Última siembra para ",vit[1:nrow(vit),1]," (",strsplit(vit[1:nrow(vit),3]," días")," dìas)"),
                     paste0("Cosecha temprana para ",vit[1:nrow(vit),1]," (",strsplit(vit[1:nrow(vit),3]," días")," dìas)"),"Última cosecha") 
  
  # Order the colors based on the desired order
  #ordered_colors <- c("green","green3","green4","chocolate2","chocolate","chocolate4", "darkred", "brown1","brown3","darkblue")[order(desired_order)]
  ordered_colors <- c("green","green3","green4","gold","gold3","gold4", "magenta", paste0("skyblue",1:nrow(vit)),paste0("pink",1:nrow(vit)),"red")
  
  calendR(start_date  = start_date, end_date  = end_date,special.col = ordered_colors,ordered_colors = ordered_colors,
          special.days = myfills, legend.pos = "right", title="Calendario de temporada de lluvias y cultivos",desired_order = desired_order)
}
########
growing_calendar<-function(x,y,crop,fOnset=as.Date('1984-08-01'),short='Jul',choice=1){

  ka<-miss(y)
  tab<-ftable(y,fOnset=fOnset)
  
  fday<-paste(ka[1,1],ka[1,2],ka[1,3],sep='-')

  julito<-c(31,28,31,30,31,30,31,31,30,31,30,31)
  mois<-c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
  end_month<-which(as.character(short)==mois)
  
  mon<-c(rep('Jan',3),rep('Feb',3),rep('Mar',3),rep('Apr',3),rep('May',3),rep('Jun',3),rep('Jul',3),
         rep('Aug',3),rep('Sep',3),rep('Oct',3),rep('Nov',3),rep('Dec',3))
  nom<-c(rep('J ',3),rep('F ',3),rep('M ',3),rep('A ',3),rep('M ',3),rep('J ',3),rep('J ',3),
         rep('A ',3),rep('S ',3),rep('O ',3),rep('N ',3),rep('D ',3))
  dek<-seq(1,12*3,1)
  calendar<-rep(dek,nrow(crop))
  dim(calendar)<-c(length(dek),nrow(crop))
  calendar<-t(calendar)
  colnames(calendar)<-nom
  rownames(calendar)<-paste0(crop[,1],'   |     ',crop[,2])
  if(choice==1){
    media<-mean(as.numeric(as.character(x$P_cessation1)),na.rm=TRUE)
    desvi<-sd(as.numeric(as.character(x$P_cessation1)),na.rm=TRUE)
  }else{
    media<-mean(as.numeric(as.character(x$P_cessation2)),na.rm=TRUE)
    desvi<-sd(as.numeric(as.character(x$P_cessation2)),na.rm=TRUE)
  }
  
  
  end<-round(qnorm(0.67,media,desvi),0)
  media<-mean(as.numeric(as.character(x$P_onset)),na.rm=TRUE)
  desvi<-sd(as.numeric(as.character(x$P_onset)),na.rm=TRUE)
  beg<-round(qnorm(0.33,media,desvi),0)
  
  if(is.na(beg) | is.na(end)){
    sowing<-NULL
    growing<-NULL
    harvesting<-NULL
    sarclage1<-NULL
    sarclage2<-NULL
    sarclage3<-NULL
    sarclage4<-NULL
    sarclage5<-NULL
    preparation<-NULL
  }else{
  maxf<-tab$pn[which(as.numeric(substring(fday,1,4))==tab$Year &
                       end_month==tab$Month &
                       julito[end_month]==tab$Day)]
  if(end > maxf) end<-maxf

  
  if(beg < tab$pn[which(as.numeric(substring(fday,1,4))==tab$Year &
                       as.numeric(substring(as.character(fOnset),6,7))==tab$Month &
                       as.numeric(substring(as.character(fOnset),9,10))==tab$Day)])
  { beg <- tab$pn[which(as.numeric(substring(fday,1,4))==tab$Year &
                          as.numeric(substring(as.character(fOnset),6,7))==tab$Month &
                          as.numeric(substring(as.character(fOnset),9,10))==tab$Day)]}

  sowing<-NULL
  growing<-NULL
  harvesting<-NULL
  sarclage1<-NULL
  sarclage2<-NULL
  sarclage3<-NULL
  sarclage4<-NULL
  sarclage5<-NULL
  preparation<-NULL

  dk<-function(mes,dia=dia1){
    id<-which(mes==mon)
    if(dia < 11){
      val<-id[1]
    }
    if(dia > 10 & dia < 21){
      val<-id[2]
    }
     if(dia > 20){
      val<-id[3]
    }
    return(val)
  }

  for(i in 1:nrow(crop)){
    vali<-end-as.numeric(crop[i,3])

    
    mes1<-tab$Month[which(as.numeric(tab$pn)==vali)][1]
    dia1<-tab$Day[which(as.numeric(tab$pn)==vali)][1]
    
    

    if(beg <= 0){
      dia2<-as.numeric(substring(as.character(fOnset),9,10))
      mes2<-as.numeric(substring(as.character(fOnset),6,7))
    }else{
      
      dia2<-tab$Day[which(as.numeric(tab$pn)==beg)][1]
      mes2<-tab$Month[which(as.numeric(tab$pn)==beg)][1]
    }
    

    if((is.na(mes1) | is.na(dia1) | (vali < beg))){
      sowing[i]<-0
      growing[i]<-0
      harvesting[i]<-0
      sarclage1[i]<-0
      sarclage2[i]<-0
      sarclage3[i]<-0
      sarclage4[i]<-0
      sarclage5[i]<-0
      preparation[i]<-0
    }else{
      if(mes1==2 & dia1==29) dia1=28
      mes<-mois[mes1]
      lsp<-dk(mes,dia = dia1)

      if(dia1 %in% julito){
        dia<-1
        if(mes1==12){
          mes<-1
        }else{
          mes<-mes1+1
        }
        leg<-paste(substring(seq.Date(as.Date(as.character(paste(as.numeric(substring(fday,1,4)),mes,dia,sep = '-'))),
                                              by='day',length.out = as.numeric(crop[i,3]))[as.numeric(crop[i,3])],9,10),
                           mois[as.numeric(as.character(substring(seq.Date(as.Date(as.character(paste(as.numeric(substring(fday,1,4)),mes,dia,sep = '-'))),
                                                                          by='day',length.out = as.numeric(crop[i,3]))[as.numeric(crop[i,3])],6,7)))],sep = '-')
      }else{
        leg<-paste(substring(seq.Date(as.Date(as.character(paste(as.numeric(substring(fday,1,4)),mes1,dia1+1,sep = '-'))),
                                              by='day',length.out = as.numeric(crop[i,3]))[as.numeric(crop[i,3])],9,10),
                           mois[as.numeric(as.character(substring(seq.Date(as.Date(as.character(paste(as.numeric(substring(fday,1,4)),mes1,dia1+1,sep = '-'))),
                                                                          by='day',length.out = as.numeric(crop[i,3]))[as.numeric(crop[i,3])],6,7)))],sep = '-')
      }

      mes<-strsplit(leg,'-')[[1]][2]
      dia<-as.numeric(strsplit(leg,'-')[[1]][1])
      legi<-dk(mes,dia = dia)
      

    mes<-mois[mes2]
    begi<-dk(mes,dia = dia2)
    n<-sum(with(rle(seq(begi-6,begi-1)),lengths[values <= 0]))
    m<-sum(with(rle(seq(begi-6,begi-1)),lengths[values > 0]))
    if(n>0 & m==0){
      preparation[i]<-list(c(seq(length(dek)-n+1,length(dek))))
    }else if(n>0 & m!=0){
      preparation[i]<-list(c(seq(length(dek)-n+1,length(dek)),seq(1,m)))
    }else{
      preparation[i]<-list(c(seq(begi-6,begi-1)))
    }
   
    
    if(lsp < begi){
      sowing[i]<-list(c(seq(begi,36),seq(1,lsp)))
    }else{
    sowing[i]<-list(seq(begi,lsp))
    }

    if(lsp==36){
      growing[i]<-list(c(seq(1,legi)))
    }else if((lsp+1) > legi){
      growing[i]<-list(c(seq(lsp+1,36),seq(1,legi)))
    }else{
      growing[i]<-list(c(seq(lsp+1,legi)))
    }


    sarclage1[i]<-list(growing[[i]][1]+crop[i,4])
    if(is.na(sarclage1[i])){
      sarclage1[i]<-sarclage1[i]
    }else if(as.numeric(sarclage1[i])>36) {
      sarclage1[i]<-as.numeric(sarclage1[i])-36
}
    sarclage2[i]<-list(sarclage1[[i]][1]+crop[i,5])
    sarclage3[i]<-list(sarclage1[[i]][1]+crop[i,6])
    sarclage4[i]<-list(sarclage1[[i]][1]+crop[i,7])
    sarclage5[i]<-list(sarclage1[[i]][1]+crop[i,8])
  

   harvesting[i]<-list(which(c(seq(1,12*3)) %in% c(sowing[[i]],growing[[i]])==FALSE))
   
   if(length(which(preparation[[i]] %in% growing[[i]])>0)){
     preparation[i]<-NA
   }
  }
  }
}

  m<-12*3
  cols<-array(NA,c(nrow(crop),m))
  for(j in 1:nrow(crop)){
    p<-1
    for(n in 1:m){
      if(n %in% sowing[[j]]){
        cols[j,p]<-'background-color:Blue'
      }
      if(0 %in% sowing[[j]]){
        cols[j,p]<-'background-color:White'
      }
      if(n %in% growing[[j]]){
        cols[j,p]<-'background-color:Green'
      }
      if(0 %in% growing[[j]]){
        cols[j,p]<-'background-color:White'
      }
      if(n %in% harvesting[[j]]){
        cols[j,p]<-'background-color:Yellow'
      }
      if(0 %in% harvesting[[j]]){
        cols[j,p]<-'background-color:White'
      }
      if(n %in% preparation[[j]]){
        cols[j,p]<-'background-color:Maroon'
      }
      if(n %in% sarclage1[[j]]){
        cols[j,p]<-'background-color:Pink'
      }
      if(n %in% sarclage2[[j]]){
        cols[j,p]<-'background-color:Pink'
      }
      if(n %in% sarclage3[[j]]){
        cols[j,p]<-'background-color:Pink'
      }
      if(n %in% sarclage4[[j]]){
        cols[j,p]<-'background-color:Pink'
      }
      if(n %in% sarclage5[[j]]){
        cols[j,p]<-'background-color:Pink'
      }
      if(0 %in% preparation[[j]]){
        cols[j,p]<-'background-color:White'
      }
      if(0 %in% sarclage1[[j]]){
        cols[j,p]<-'background-color:White'
      }
      
      if(0 %in% sarclage2[[j]]){
        cols[j,p]<-'background-color:White'
      }
      if(0 %in% sarclage3[[j]]){
        cols[j,p]<-'background-color:White'
      }
      if(0 %in% sarclage4[[j]]){
        cols[j,p]<-'background-color:White'
      }
      if(0 %in% sarclage5[[j]]){
        cols[j,p]<-'background-color:White'
      }
      p<-p+1
    }
  }
  htmlTable::htmlTable(calendar,css.cell=cols)
}
