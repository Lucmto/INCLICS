### THIS CODE IS MADE by LUC RANDRIAMAROLAZA, ENRIC AGUILAR and JOSE GUIJJARO, Centre for Climate Change, C3, URV, Tarragona, Spain - Directorate General of Meteorology, Madagascar, Agencia Estatal de Meteorología (AEMET), Spain  
### It is provided free under the terms of the GNU Lesser General Public License as published by the Free Software Foundation,
# version 3.0 of the License. It is distributed under the terms of this license 'as-is' and has not been designed or prepared to meet any Licensee's particular requirements. 
# The author and its institution make no warranty, either express or implied, including but not limited to, warranties of merchantability or fitness for a particular
# purpose. In no event will they will be liable for any indirect, special, consequential or other damages attributed to the Licensee's use of The Library. 
# In downloading The Library you understand and agree to these terms and those of the associated LGP License. See the GNU Lesser General Public License for more details.
# <http://www.gnu.org/licenses/lgpl.html> or contact the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

if(!require(shiny)){install.packages('shiny')}
if(!require(shinydashboard)){install.packages('shinydashboard')}
if(!require(rstudioapi)){install.packages('rstudioapi')}
if(!require(shinyFiles)){install.packages('shinyFiles')}
if(!require(htmlTable)){install.packages('htmlTable')}
if(!require(INQC)){install.packages('INQC')}
if(!require(data.table)){install.packages('data.table')}
if(!require(utils)){install.packages('utils')}
if(!require(climatol)){install.packages('climatol')}
if(!require(ClimInd)){install.packages('ClimInd')}
if(!require(chron)){install.packages('chron')}
if(!require(climdex.pcic)){install.packages('climdex.pcic')}
if(!require(anytime)){install.packages('anytime')}
if(!require(zyp)){install.packages('zyp')}
if(!require(grid)){install.packages('grid')}
if(!require(gridExtra)){install.packages('gridExtra')}
if(!require(utile.visuals)){install.packages('utile.visuals')}
if(!require(zoo)){install.packages('zoo')}
if(!require(jpeg)){install.packages('jpeg')}
if(!require(graphics)){install.packages('graphics')}
if(!require(rlang)){install.packages('rlang')}
if(!require(webshot)){ install.packages('webshot')}
if(!require(kableExtra)){install.packages('kableExtra')}
if(!require(magick)){install.packages('magick')}
if(!require(png)){install.packages('png')}
if(!require(rmarkdown)){install.packages('rmarkdown')}
if(!require(knitr)){install.packages('knitr')}
if(!require(timeDate)){install.packages('timeDate')}
if(!require(lubridate)){install.packages('lubridate')}
if(!require(DT)){install.packages('DT')}
if(!require(tinytex)){install.packages('tinytex')}
if(!require(readr)){install.packages('reader')}
if(!require(stringr)){install.packages('stringr')}
if(!require(rex)){install.packages('rex')}
if(!require(DataCombine)){install.packages('DataCombine')}
if(!require(raster)){install.packages('raster')}
if(!require(rgdal)){install.packages('rgdal')}
if(!require(maptools)){install.packages('maptools')}
if(!require(RColorBrewer)){install.packages('RColorBrewer')}
if(!require(shinyWidgets)){install.packages('shinyWidgets')}
if(!require(shinybusy)){install.packages('shinybusy')}
if(!require(shinythemes)){install.packages('shinythemes')}
if(!require(markdown)){install.packages('markdown')}
if(!require(ggplot2)){install.packages('ggplot2')}
if(!require(shiny.i18n)){install.packages('shiny.i18n')}


library(ggplot2)
library(shinythemes)
library(shinybusy)
library(shinyWidgets)
library(utile.visuals)
library(gridExtra)
library(grid)
library(ClimInd)
library(chron)
library(climdex.pcic)
library(anytime)
library(zyp)
library(readr)
library(stringr)
library(rex)
library(DataCombine)
library(markdown)
options(warn=-1)

library(zoo)
library(shiny)
library(shinydashboard)
library(rstudioapi)
library(shinyFiles)
library(htmlTable)
library(INQC)
library(data.table)
library(utils)
library(climatol)
library(jpeg)
library(graphics)

library(knitr)
library(rmarkdown)
library(webshot)
library(kableExtra)
library(magick)
library(png)
library(lubridate)
library(DT)
library(timeDate)
library(tinytex)

library(raster)
library(rgdal)
library(maptools)
library(RColorBrewer)
library(shiny.i18n)


chemin<-getwd()
print(chemin)
source('inqc_climatol_climateindices.R')
sta <- station(chemin='../Controle_Qualite/')
shp<-shape(chemin='../script/')
dem<-mnt(chemin='../script/')
i18n <- Translator$new(translation_json_path='../script/translation.json')
translator <- Translator$new(translation_json_path='../script/translation.json')
i18n$set_translation_language('Français')
file.copy('../Controle_Qualite/stations.txt','./../climate_indices/',overwrite = T)


ui <-dashboardPage(
  dashboardHeader(
    titleWidth = 490,
    tags$li(class= "dropdown",
      radioButtons(
        inputId='selected_language',
        label='',
        #choices = i18n$get_languages(),
        choices=c('Français'='Français','English'='English','Espagnol'='Espagnol'),
        selected = i18n$get_key_translation(),
        inline = TRUE,
      )
    ),
    title = tagList(shiny.i18n::usei18n(i18n),i18n$t('INCLICS: INqc - CLimatol - Indices Climatiques - Spcc'))
  ),
  
    dashboardSidebar(
      width = 490,
      fluidRow(
        column(6,
        actionButton("manual1", tagList(shiny.i18n::usei18n(i18n),i18n$t("Guide d'Utilisateur")),style='padding:10px; font-size:100%; width:140px;
                                            color: black; background-color: gray90; border-color: black')
               ),
        column(6,actionButton('refresh1',i18n$t('Recharger la session'),style='padding:10px; font-size:100%; width:140px;
                                            color: black; background-color: gray90; border-color: black')
               )
      ),
      br(),
      dropdownButton(
        inputId = "mydropdown",
        label = i18n$t("CONTROLE QUALITE AVEC INQC"),
        icon = NULL,
        status = "primary",
        circle = FALSE,
        size = "lg",
        
        fluidRow(
          column(7,
                 shinyFilesButton("station", i18n$t("Choisir une liste de station") ,
                                  title = i18n$t("Sélectionner une liste de station:"), multiple = FALSE,
                                  buttonType = "default", class = NULL,style='padding:13px; font-size:140%')
          ),
          column(5,actionButton("inqc", i18n$t("Lancer INQC"),style='padding:13px; font-size:140%'),
                 add_busy_bar(color = "red", height = "8px")
          )
        ),
        
        fluidRow(
          column(6,
                 actionButton('summary',i18n$t('Visualiser les resultats'),style='padding:13px; font-size:140%')
          ),
          column(6,
                 actionButton('reforme',i18n$t('QC en format Rclimdex'),style='padding:15px; font-size:140%'),
                 add_busy_bar(color = "red", height = "8px")
          )
        )
      ),
      br(),
      br(),
      br(),
      br(),
      br(),
      br(),
      br(),
      br(),
      dropdownButton(
        inputId = "mydropdown",
        label = i18n$t("HOMOGENEISATION AVEC CLIMATOL"),
        icon = NULL,
        status = "primary",
        circle = FALSE,
        size = "lg",
        
        fluidRow(
          column(6,
                 numericInput('deb',tags$span(style="color: black;",i18n$t("Annee de debut")),value = 1983)
          ),
          column(6,
                 numericInput('fin',tags$span(style="color: black;",i18n$t("Annee de fin")),value = 2020)
          )
        ),
        fluidRow(  
          column(6,
                 actionButton('prep',i18n$t('Preparer les donnees'),style='padding:13px; font-size:140%'),
                 add_busy_bar(color = "red", height = "8px")
          ),
          column(6,
                 actionButton('homogenisation',i18n$t('Lancer Climatol'),style='padding:13px; font-size:140%'),
                 add_busy_bar(color = "red", height = "8px")
          )
        )
      ),
      br(),
      br(),
      br(),
      br(),
      br(),
      br(),
      br(),
      br(),
      br(),
      dropdownButton(
        inputId = "mydropdown",
        label = i18n$t("INDICES CLIMATIQUES"),
        icon = NULL,
        status = "primary",
        circle = FALSE,
        size = "lg",
        
        fluidRow(
          column(6,
                 numericInput('base1',tags$span(style="color: black;",i18n$t("Reference annee debut")),value = 1971)
          ),
          column(6,
                 numericInput('base2',tags$span(style="color: black;",i18n$t("Reference annee fin")),value = 2000) 
          )
        ),
        fluidRow(
          column(6,
                 actionButton('indices',i18n$t('Commencer le calcul'),style='padding:13px; font-size:140%'),
                 add_busy_bar(color = "red", height = "8px")
          ),
          column(6,
                 actionButton('figure',i18n$t('Afficher les figures'),style='padding:13px; font-size:140%')
          )
        )
      ),
      br(),
      br(),
      br(),
      br(),
      br(),
      br(),
      br(),
      br(),
      br(),
      dropdownButton(
        inputId = "mydropdown",
        label = i18n$t("SAISON PLUVIEUSE ET CALENDRIER DE CULTURE"),
        icon = NULL,
        status = "primary",
        circle = FALSE,
        size = "lg",
        
        fluidRow(
          column(12,
                 actionButton('spcc','SPCC',style='padding:13px; font-size:120%; width:410px')
          )
        )
      )
      
    ),
    dashboardBody(
      tags$head(includeCSS('www/custom1.css')),
      fluidRow(
        column(12,
               uiOutput('mytext21')),
      ),
      fluidRow(
        column(12,
               uiOutput('mylogo1'),
               br(),
               
        )
        
      ),
      br(),
      uiOutput('mytext'),
      br(),
      br(),
      br(),
      uiOutput('portada', height = "600px"),
      br(),
      uiOutput("instrucciones"),
      conditionalPanel('input.station',
                       fluidRow(
                         column(6,
                                actionButton("tab",i18n$t('Liste des stations'),style='padding:13px; font-size:80%')
                         ),
                         column(6,
                                actionButton("carte",i18n$t('Cartographie des stations'),style='padding:13px; font-size:80%'))
                       )),
      conditionalPanel('input.tab',
                       tableOutput('myTable')),
      conditionalPanel('input.carte',
                       sliderInput("slider", label = "", min = 400, max = 500, value = 400),
                       imageOutput('mycarte')),
      uiOutput('mytext4'),
      verbatimTextOutput('inqc_out'),
      uiOutput('mytext2'),
      uiOutput('mytext20'),
      conditionalPanel('input.summary',
                       fluidRow(
                         column(4,
                                selectInput('var',label = i18n$t('Choisir un element'),choices=c('RR','TX','TN'),selected = 'RR')
                         ),
                         column(4,
                                selectInput('nom',i18n$t('Choisir une station'),choices=sta$STAT_NAME)
                         ),
                         column(4,
                                selectInput("res",'',choices='')
                         )
                       )
      ),
      fluidRow(
        column(12,
               conditionalPanel(condition = 'output.val1',
                                tabPanel('',dataTableOutput("mytable1"))
               )
        )
      ),
      fluidRow(
        column(12, 
               conditionalPanel(condition = 'output.val2',
                                tabPanel('',dataTableOutput("mytable2")))
        )
      ),
      
      fluidRow(
        column(12,
               conditionalPanel(condition = 'output.val3',
                                   tabPanel('',dataTableOutput("mytable3")))
        )
      ),
      
      fluidRow(
        column(12,
               conditionalPanel(condition = 'output.val4',
                                   tabPanel('',dataTableOutput("mytable4")))
               
        )
      ),
      uiOutput('mytext5'),
      verbatimTextOutput('mytext18'),
      uiOutput('mytext23'),
      uiOutput('mytext19'),
      uiOutput('mytext14'),
      uiOutput('mytext24'),
      conditionalPanel('input.homogenisation',
                       fluidRow(
                         column(6,
                                actionButton('teste',i18n$t('Tester les données'),style='padding:13px; font-size:140%')),
                         add_busy_bar(color = "red", height = "8px"),
                         
                         column(6,
                                actionButton('hom',i18n$t('Homogéneiser les données'),style='padding:13px; font-size:140%')),
                         add_busy_bar(color = "red", height = "8px"),
                       )),
      verbatimTextOutput('mytext16'),
      verbatimTextOutput('mytext6'),
      uiOutput('mytext11'),
      uiOutput('mytext22'),
      verbatimTextOutput('mytext12'),
      uiOutput('mytext15'),
      conditionalPanel('input.indices',
                       fluidRow(
                         column(6,
                                selectInput('entete',i18n$t('Choisir entête'),choices=c('hoclm','QC_'),selected='hoclm')
                         ),
                         column(6,
                                actionButton('valide',i18n$t('Calculer les indices'),style='padding:15px; font-size:80%')
                         )
                       )
      ),
      conditionalPanel('input.figure',
                       fluidRow(
                         column(4,
                                selectInput('entete1',i18n$t('Choisir entête'),choices=c('hoclm','QC_'),selected='hoclm')
                         ),
                         column(4,
                                selectInput('anar',i18n$t('Choisir une station'),choices=sta$STAT_NAME)
                         ),
                         column(4,
                                selectInput('index','',choices = '')
                         )
                       ),
                       fluidRow(
                         column(6,
                                plotOutput('myplot')      
                         ),
                         column(6,
                                plotOutput('myplot1')  
                         )
                       ),
                       fluidRow(
                         column(6,
                                uiOutput('mytext30'))
                       )
      ),
      
      uiOutput('mytext17'),
      uiOutput('mytext10')
      
    )
)
server <- shinyServer(function(input, output,session) {
  # 
  ind <- reactive({
    indice(chemin='../climate_indices/',langue=input$selected_language)
  })
  
  observeEvent(input$selected_language, {
    # Call the "updateSelectInput" and edit what needed
    updateSelectInput(session, "index", 
                      label = i18n$t('Choisir un index'),
                      choices = ind()[,2])
  })
  
  i19n <- reactive({
    selected <- input$selected_language
    if (length(selected) > 0 && selected %in% translator$get_languages()) {
      translator$set_translation_language(selected)
    }
    translator
  })
  
  observeEvent(input$selected_language, {
    update_lang(input$selected_language, session)
  })
  
  translations = data.frame(
    id=paste('id',1:4,sep = '_'),
    Français=c("Erreurs_certaines","Presque_erreurs","Valeurs_aberrantes","Collectivement_suspect"),
    English=c("True_errors","Almost_errors","Outliers","Collectively_suspicious"),
    Espagnol=c("Errores_ciertos","Casi_errores","Valores_aberrantes","Colectivamente_sospechosos")
  )
  
  
  observeEvent(input$selected_language, {
    # Call the "updateSelectInput" and edit what needed
    updateSelectInput(session, "res", 
                      label = i18n$t("Choisir le type de resultats"),
                      choices = setNames(translations$id, translations[,input$selected_language]))
  })
  
  datasetInput1 <- reactive({
    switch(eval(parse(text=paste('translations$',input$selected_language,'[which(input$res==translations$id)]'))),
           Erreurs_certaines="Erreurs_certaines",
           True_errors="True_errors",
           Errores_ciertos="Errores_ciertos")
  })
  output$val1<-reactive({
    datasetInput1()
  })
  
  outputOptions(output, "val1", suspendWhenHidden = FALSE)
  
  
  datasetInput2 <- reactive({
    switch(eval(parse(text=paste('translations$',input$selected_language,'[which(input$res==translations$id)]'))),
           Presque_erreurs="Presque_erreurs",
           Almost_errors="Almost_errors",
           Casi_errores="Casi_errores")
  })
  output$val2<-reactive({
    datasetInput2()
  })
  
  outputOptions(output, "val2", suspendWhenHidden = FALSE)
  
  
  datasetInput3 <- reactive({
    switch(eval(parse(text=paste('translations$',input$selected_language,'[which(input$res==translations$id)]'))),
           Valeurs_aberrantes="Valeurs_aberrantes",
           Outliers="Outliers",
           Valores_aberrantes="Valores_aberrantes")
  })
  output$val3<-reactive({
    datasetInput3()
  })
  
  outputOptions(output, "val3", suspendWhenHidden = FALSE)
  
  
  datasetInput4 <- reactive({
    switch(eval(parse(text=paste('translations$',input$selected_language,'[which(input$res==translations$id)]'))),
           Collectivement_suspect="Collectivement_suspect",
           Collectively_suspicious="Collectively_suspicious",
           Colectivamente_sospechosos="Colectivamente_sospechosos")
  })
  output$val4<-reactive({
    datasetInput4()
  })
  
  outputOptions(output, "val4", suspendWhenHidden = FALSE)
  
  ranges <- reactiveValues(x = NULL, y = NULL)
  
 output$mytext21<-renderUI({
     HTML(paste(i19n()$t("<strong>OUTIL DE SERVICE CLIMATIQUE POUR L'AGRICULTURE</strong> développé par:"),' ',sep="<br/>"))
 })
 
 output$portada <- renderUI({
   img(src = "imagen_portada1.png", height = 180, width = 1200)
 })
 
  output$mylogo1<-renderUI({
    img(src = "logo_new.png",height='100',width='1000')
  })
  
  output$mytext<-renderUI(
    HTML(i19n()$t("INCLICS est une application cree par LUC RANDRIAMAROLAZA(a,b), ENRIC AGUILAR(a) et JOSE A. GUIJJARO(c)<br/><br/>a) Centre for Climate Change, C3, URV, Tarragona, Espagne<br/><br/>b) Direction Generale de la Meteorologie, Madagascar<br/><br/>c) Agencia Estatal de Meteorología (AEMET), Espagne<br/> <br/> <br/>L'objectif est d'avoir un simple outil qui permet d'assurer la qualite des produits climatiques. Ceci est le cas du service climatique envers le secteur Agriculture.<br/> <br/>Cet logiciel est distribue sous LGPL licence. Visite http://www.gnu.org/licenses/lgpl.htm pour plus d'information.<br/> "))    
  )
  
  observeEvent(input$manual1,{
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector='#mytext')
      removeUI(selector='#portada')
    }
    
    global$refresh <- FALSE
  })
  
  output$instrucciones <- reactive({
    if(!is.null(req(input$manual1))){
        includeMarkdown(paste0("../script/Manual_INCLICS_",input$selected_language,".RMD"))
    }
  })
  
  volumes = c("UserFolder"='./../Controle_Qualite/')
  observe({
    shinyFileChoose(input, "station", roots = volumes, session = session)
  })
  
  liste_station<-reactive({
    if(!is.null(req(input$station))){
      as.character(parseFilePaths(volumes, input$station)$datapath)
    }
  })
  
  dat<-reactive({
    dat<-read.table(liste_station(),as.is=T)
    dat<-dat[-1,]
    colnames(dat)<-c('ID','STAT_NAME','LATITUDE','LONGITUDE','ALTITUDE','COUNTRY')
    dat<-as.data.frame(dat)
    dat
  })
  
  global <- reactiveValues(refresh = FALSE)
  
  observeEvent(input$station,{
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector = '#instrucciones')
      removeUI(selector='#mytext')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytext3')
      removeUI(selector='#portada')
    }
    global$refresh <- FALSE
  })
  
  output$myTable <- renderUI({
    if(!is.null(req(input$tab))){
      output$aa <- renderDataTable(dat())
      dataTableOutput("aa")
    }
  })
  
  output$mycarte<-renderImage({
    if(!is.null(req(input$carte))){
      removeUI(selector='#myTable')
      removeUI(selector='#mytext4')
      removeUI(selector='#portada')
      #plot_carte(chemin='./../Controle_Qualite/',dem,shp,dat(),pts)
      plot_carte(chemin='./../Controle_Qualite/',dem,dat(),shp)
      setwd('./../Controle_Qualite/')
      img<-image_read('carte.jpeg')
      tmpfile <- img %>%
        image_scale(input$slider) %>%
        image_write('carte.jpeg', format = 'jpeg',)
      list(src = 'carte.jpeg', contentType = "image/jpeg", deleteFile = FALSE)
    }
  })
  
  output$mytext4<-renderUI({
    if(!is.null(req(input$tab))){
      HTML(i19n()$t("Apres avoir bien confirme ce metadata<br/>vous pouvez maintenant demarrer le QC en appuyant sur \"Lancer INQC\".<br/> <br/>Veuillez attendre que des messages s'affichent."))
    }
  })
  
  
  observeEvent(input$inqc,{
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector='#mytext')
      removeUI(selector='#myTable')
      removeUI(selector='#mytext4')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytext3')
      removeUI(selector='#mycarte')
      removeUI(selector='#portada')
      removeUI(
        selector = 'div:has(>> #tab)'
      )
      removeUI(
        selector = 'div:has(>> #carte)'
      )
      removeUI(
        selector = 'div:has(>> #slider)'
      )
      
    }
    global$refresh <- FALSE
  })
  
  output$inqc_out<-renderPrint({
    if(!is.null(req(input$inqc))){
      setwd('./../Controle_Qualite/')
      transform(stationlist = 'stations.txt')
      inqc('./')
    }
  })
  
  output$mytext2<-renderUI({
    if(!is.null(req(input$inqc))){
      HTML(i19n()$t("Le controle de la qualite des donnees est fini.<br/> <br/>Vous pouvez visualiser les resultats en appuyant sur \"Visulaser les resultats\"<br/> <br/>Puis créer le QC en format RClimdex en appuyant sur QC en format RClimdex"))
    }
  })
  
  #### Visualisation de types d'erreurs ######
  
  observeEvent(input$summary,{
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector='#mytext')
      removeUI(selector='#mytext2')
      removeUI(selector='#inqc_out')
      removeUI(selector='#mytext4')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytext3')
      removeUI(selector='#myTable')
      removeUI(selector='#mycarte')
      removeUI(selector='#portada')
      removeUI(
        selector = 'div:has(>> #tab)'
      )
      removeUI(
        selector = 'div:has(>> #carte)'
      )
      removeUI(
        selector = 'div:has(>> #slider)'
      )
      
    }
    global$refresh <- FALSE
    
    setwd('./../Controle_Qualite/')
    anar<-reactive({ 
      id<-which(dat()$STAT_NAME == input$nom)
      paste0('QCConsolidated/',input$var,'_STAID',dat()$ID[id],'.txt')
    })
    
    output$mytable1 <- renderDataTable({
      A<-read.table(anar(),header=F,skip = 2,sep = ',')
      idi<-which(A$V5 == 1)
      B<-A[idi,3:4]
      B<-cbind(as.numeric(substr(B[,1],1,4)), as.numeric(substr(B[,1],5,6)),as.numeric(substr(B[,1],7,8)),B[,2]/10)
      colnames(B)<-c('Annee','Mois','Jour',input$var)
      B<-as.data.table(B)
    })  
    
    output$mytable2 <-renderDataTable({
      A<-read.table(anar(),header=F,skip = 2,sep = ',')
      idi<-which(A$V5 == 2)
      B<-A[idi,3:4]
      B<-cbind(as.numeric(substr(B[,1],1,4)), as.numeric(substr(B[,1],5,6)),as.numeric(substr(B[,1],7,8)),B[,2]/10)
      colnames(B)<-c('Annee','Mois','Jour',input$var)
      B<-as.data.table(B)
    })
    
    output$mytable3 <-renderDataTable({
      A<-read.table(anar(),header=F,skip = 2,sep = ',')
      idi<-which(A$V5 == 3)
      B<-A[idi,3:4]
      
      B<-cbind(as.numeric(substr(B[,1],1,4)), as.numeric(substr(B[,1],5,6)),as.numeric(substr(B[,1],7,8)),B[,2]/10)
      colnames(B)<-c('Annee','Mois','Jour',input$var)
      B<-as.data.table(B)
    })
    
    output$mytable4 <-renderDataTable({
      A<-read.table(anar(),header=F,skip = 2,sep = ',')
      idi<-which(A$V5 == 4)
      B<-A[idi,3:4]
      
      B<-cbind(as.numeric(substr(B[,1],1,4)), as.numeric(substr(B[,1],5,6)),as.numeric(substr(B[,1],7,8)),B[,2]/10)
      colnames(B)<-c('Annee','Mois','Jour',input$var)
      
      B<-as.data.table(B)
    })
  })
  
  output$mytext5<-renderUI({
    if(!is.null(req(input$summary))){
      HTML(i19n()$t("Veuillez corriger les erreurs et revenir vers l'etape 3. Pour faire, veuillez rebooter le logiciel en appuyant sur \"Recharger le logiciel\".<br/> <br/>Sinon, Creer les donnees pour Climatol en appuyant sur \"preparer les donnees\" apres lancer Climatol en appuyant sur \"Lancer Climatol\" pour homogeneiser les donnees QC.\"<br/> <br/>Veuillez attendre que des messages s'affichent."))
    }
  })
  
  #### Transformation en format RClimdex ####
  observeEvent(input$reforme,{
    setwd('./../Controle_Qualite/')
    reform(homefolder='./../Controle_Qualite/',stationlist = 'stations.txt',txlevel=1,tnlevel=1,rrlevel=1)
    })
  
  output$mytext20<-renderUI({
    if(!is.null(req(input$reforme))){
      HTML(i19n()$t("La transformation en format Rclimdex de QC est fini."))
    }
  })
  
  observeEvent(input$reforme,{
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector='#mytext')
      removeUI(selector='#mytext2')
      removeUI(selector='#inqc_out')
      removeUI(selector='#mytext4')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytext3')
      removeUI(selector='#myTable')
      removeUI(selector='#mytable1')
      removeUI(selector='#mytable2')
      removeUI(selector='#mytable3')
      removeUI(selector='#mytable4')
      removeUI(selector='#mytext5')
      removeUI(selector='#portada')
      removeUI(selector = '#mycarte')
      removeUI(
        selector = 'div:has(>> #var)'
      )
      removeUI(
        selector ='div:has(>> #nom)'
      )
      removeUI(
        selector = 'div:has(>> #res)'
      )
    }
    global$refresh <- FALSE
  })
  
  
  ### préparation des données
  observeEvent(input$prep,{
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector = '#instrucciones')
      removeUI(selector='#mytext')
      removeUI(selector='#mytext2')
      removeUI(selector='#inqc_out')
      removeUI(selector='#mytext4')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytext3')
      removeUI(selector='#myTable')
      removeUI(selector='#mytable1')
      removeUI(selector='#mytable2')
      removeUI(selector='#mytable3')
      removeUI(selector='#mytable4')
      removeUI(selector='#mytext5')
      removeUI(selector='#mytext20')
      removeUI(selector='#mycarte')
      removeUI(selector='#portada')
      removeUI(
        selector = 'div:has(>> #var)'
      )
      removeUI(
        selector ='div:has(>> #nom)'
      )
      removeUI(
        selector = 'div:has(>> #res)'
      )
      removeUI(
        selector = 'div:has(>> #tab)'
      )
      removeUI(
        selector = 'div:has(>> #carte)'
      )
      removeUI(
        selector = 'div:has(>> #slider)'
      )
    }
    global$refresh <- FALSE
  })
  
  output$mytext18<-renderPrint({
    if(!is.null(req(input$prep))){
      setwd('./../homogenisation/')
      files.in.dir <- list.files(".", include.dirs = F,full.names = T)
      files.to.keep <- 'ClimateEngine'
      files.to.remove <- list(files.in.dir[!(files.in.dir %in% grep(paste(files.to.keep,collapse = "|"), files.in.dir, value=TRUE))])
      do.call(unlink, files.to.remove)
      preparation(deb=input$deb,fin = input$fin)
    }
  })
  
  output$mytext23<-renderUI({
    if(!is.null(req(input$prep))){
      HTML(i19n()$t("La preparation des donnees est terminee."))
    }
  })
  
  
  ## homogénéisation 
  observeEvent(input$homogenisation,{
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector = '#instrucciones')
      removeUI(selector='#mytext')
      removeUI(selector='#mytext2')
      removeUI(selector='#inqc_out')
      removeUI(selector='#mytext4')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytext3')
      removeUI(selector='#myTable')
      removeUI(selector='#mytable1')
      removeUI(selector='#mytable2')
      removeUI(selector='#mytable3')
      removeUI(selector='#mytable4')
      removeUI(selector='#mytext5')
      removeUI(selector='#mytext18')
      removeUI(selector='#mytext19')
      removeUI(selector='#mytext20')
      removeUI(selector='#mytext23')
      removeUI(selector='#mycarte')
      removeUI(selector='#mytext14')
      removeUI(selector='#portada')
      removeUI(
        selector = 'div:has(>> #tab)'
      )
      removeUI(
        selector = 'div:has(>> #carte)'
      )
      removeUI(
        selector = 'div:has(>> #slider)'
      )
      removeUI(
        selector = 'div:has(>> #var)'
      )
      removeUI(
        selector ='div:has(>> #nom)'
      )
      removeUI(
        selector = 'div:has(>> #res)'
      )
    }
    global$refresh <- FALSE
    
  })
  
  output$mytext14<-renderUI({
    if(!is.null(req(input$prep))){
      HTML(i19n()$t("<br/>Lancer Climatol."))
    }
  })
  
  output$mytext24<-renderUI({
    if(!is.null(req(input$homogenisation))){
      removeUI(selector = '#mytext14')
      removeUI(selector='#portada')
   HTML(i19n()$t("- Tout d'abord, tester les donnees s'il existe des donnees manquantes<br/> <br/>- Veuillez bien lire les messages affichees<br/><br/>- En cas de données manquantes, veuillez creer des donnees de reference avec la plateforme \"ClimateEngine\"<br/> <br/>- Copier les donnees de reference dans le repertoire principal (c-a-d homogenisation)<br/> <br/>- Puis recharger le logiciel ou la session<br/> <br/>- Appuyer sur \"preparer les donnees\"<br/> <br/>- Appuyer sur \"lancer climatol<br/> <br/>- Enfin homogeneiser les données."))
    }
  })
  
  output$mytext16<-renderPrint({
    if(!is.null(req(input$teste))){
      removeUI(selector='#mytext14')
      removeUI(selector='#portada')
      setwd('./../homogenisation/')
      home<-try(manquantes(deb = as.numeric(input$deb),fin = as.numeric(input$fin)),silent = T)
    }
  })
  
  output$mytext6<-renderPrint({
    if(!is.null(req(input$hom))){
      removeUI(selector='#mytext16')
      removeUI(selector='#mytext24')
      removeUI(selector='#portada')
      setwd('./../homogenisation/')
      home<-try(homogenisation(deb=input$deb,fin=input$fin),silent=T)
    }
  })

  
  output$mytext11<-renderUI({
    if(!is.null(req(input$hoclm))){
      removeUI(selector='#mytext16')
      removeUI(selector='#mytext24')
      removeUI(selector='#portada')
      removeUI(
        selector = 'div:has(>> #teste)'
      )
      removeUI(
        selector = 'div:has(>> #hom)'
      )
      HTML(i19n()$t("Climatol a fini d'homogeneiser les donnees.<br/> <br/>- Vous pouvez continuer sur \"INDICES CLIMATIQUES\" et SPCC"))
    }
  })
  ### indices du changement climatique 
  
  observeEvent(input$indices, {
    
    global$refresh <- TRUE
    
    if(global$refresh) {
      removeUI(selector = '#instrucciones')
      removeUI(selector='#mytext')
      removeUI(selector='#mytext2')
      removeUI(selector='#inqc_out')
      removeUI(selector='#mytext4')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytext3')
      removeUI(selector='#myTable')
      removeUI(selector='#mytable1')
      removeUI(selector='#mytable2')
      removeUI(selector='#mytable3')
      removeUI(selector='#mytable4')
      removeUI(selector='#mytext5')
      removeUI(selector='#mytext11')
      removeUI(selector='#mytext14')
      removeUI(selector='#mytext6')
      removeUI(selector='#mytext16')
      removeUI(selector='#mytext18')
      removeUI(selector='#mytext20')
      removeUI(selector = '#mytext24')
      removeUI(selector='#portada')
      removeUI(selector = '#mycarte')
      removeUI(
        selector = 'div:has(>> #tab)'
      )
      removeUI(
        selector = 'div:has(>> #carte)'
      )
      removeUI(
        selector = 'div:has(>> #slider)'
      )
      removeUI(
        selector = 'div:has(>> #var)'
      )
      removeUI(
        selector ='div:has(>> #nom)'
      )
      removeUI(
        selector = 'div:has(>> #res)'
      )
      removeUI(
        selector = 'div:has(>> #teste)'
      )
      removeUI(
        selector = 'div:has(>> #hom)'
      )
    }
    global$refresh <- FALSE
    
  })
  
  output$mytext22<-renderUI({
    if(!is.null(req(input$indices))){
      HTML(i19n()$t("Veuillez choisir l'entête des données et appuyer sur \"Calculer les indices\" pour le lancer.<br/> <br/>Veuillez attendre que des messages s\"affichent."))
    }
  })
  
  output$mytext12<-renderPrint({
    if(!is.null(req(input$valide))){
      setwd('./../climate_indices/')
      objectclimdex(infolder='donnees',prefix=as.character(input$entete),outfolder='climdexobject',mindata=1000,NH=FALSE,
                    base1=input$base1,base2=input$base2)
      computeclimdex(prefix=as.character(input$entete),outfolder='climdexindices',infolder='climdexobject',
                     plotfolder='climindplot')
      iternormRCL(infolder='donnees',outfolder='koppen',prefix=as.character(input$entete),fyear=input$deb,lyear=input$fin,mindata=10000)
      ll<-list.files('donnees/',input$entete)
      if(!dir.exists('./saison/')) dir.create('./saison/',recursive = T)
      for(fichier in ll){
        calculation(x=paste0('donnees/',fichier),sta = as.numeric(as.character(station('./')$LATITUDE)),
                    anarana=paste0('./saison/debutfin',strsplit(fichier,'.txt'),'.txt'))
      }
    }
    
    
  
    observeEvent(input$valide, {
      removeUI(selector='#mytext22')
      removeUI(selector='#portada')
      removeUI(
        selector = 'div:has(>> #entete)'
      )
      removeUI(
        selector = 'div:has(>> #valide)'
      )
    })
    
    output$mytext15<-renderUI({
      if(!is.null(req(input$valide))){
        HTML(i19n()$t("Le calcul des indices est termine.<br/> <br/>Vous pouvez maintenant afficher les indices en appuyant sur \"Afficher les figures\""))
      }
    })
  })
  
  # affichage des figures
  observeEvent(input$figure,{
    
    global$refresh <- TRUE
    
    if(global$refresh) {
      removeUI(selector='#mytext')
      removeUI(selector='#mytext2')
      removeUI(selector='#inqc_out')
      removeUI(selector='#mytext4')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytext3')
      removeUI(selector='#myTable')
      removeUI(selector='#mytable1')
      removeUI(selector='#mytable2')
      removeUI(selector='#mytable3')
      removeUI(selector='#mytable4')
      removeUI(selector='#mytext5')
      removeUI(selector='#mytext11')
      removeUI(selector='#mytext14')
      removeUI(selector='#mytext6')
      removeUI(selector='#mytext15')
      removeUI(selector='#mytext12')
      removeUI(selector='#mytext16')
      removeUI(selector='#mytext18')
      removeUI(selector='#mytext22')
      removeUI(selector='#mytext20')
      removeUI(selector='#portada')
      removeUI(selector = '#mycarte')
      removeUI(
        selector = 'div:has(>> #var)'
      )
      removeUI(
        selector ='div:has(>> #nom)'
      )
      removeUI(
        selector = 'div:has(>> #res)'
      )
      removeUI(
        selector = 'div:has(>> #entete)'
      )
      removeUI(
        selector = 'div:has(>> #valide)'
      )
    }
    global$refresh <- FALSE
    setwd('./../climate_indices/')
    station_new(chemin='koppen/',entete=as.character(input$entete),stat=sta,dir.out='./../spcc/')
  })
  
  output$myplot<-renderPlot({
    if(!is.null(req(input$figure))){
      setwd('./../climate_indices/')
      id<-which(as.character(input$anar) == as.character(station('./')$STAT_NAME))
      plot_jpeg(paste0('koppen/',input$entete1,as.character(station('./')$ID[id]),'.jpg'))
    }
  })
  
  output$myplot1<-renderPlot({
    if(!is.null(req(input$figure))){
      setwd('./../climate_indices/')
       id<-which(as.character(station('./')$STAT_NAME) == as.character(input$anar))
      id1<-which(as.character(input$index) == as.character(indice('./',langue = input$selected_language)[,2]))
      plot_jpeg(paste0('climindplot/',input$entete1,as.character(station('./')$ID[id]),'_ANN_climdex.',as.character(indice('./')[id1,1]),'.jpg'))
    }
  })
  
  output$mytext30<-renderUI({
    if(!is.null(req(input$figure))){
      setwd('./../climate_indices/')
      id<-which(as.character(station('./')$STAT_NAME) == as.character(input$anar))
      done<-read.table(paste0('./saison/debutfin',input$entete1,as.character(station('./')$ID[id]),'.txt'),as.is = T,header = T,sep = '\t')
      debut<-done[nrow(done),1]
      fin<-done[nrow(done),2]
      HTML(paste(i19n()$t('La saison de pluie avec la méthode anomalie cumulée sont:'),'  ',
                 i19n()$t('Début: '),debut, i19n()$t('Fin: '),fin,sep = "<br/>"))
    }
  })
  
  output$mytext17<-renderUI({
    if(!is.null(req(input$figure))){
      setwd('./../climate_indices/')
      did1<-which(as.character(input$index) == as.character(def_indice('./',langue=input$selected_language)[,2]))
      HTML(paste('<h2>',as.character(def_indice('./',langue=input$selected_language)[did1,3]),'</h2>',' ',
      i19n()$t("Si vous avez fini d'analyser les figures<br/> <br/>Vous pouvez analyser la saison pluvieuse et developper les calendriers culturaux en appuyant sur \"SPCC\"")))
      
      # HTML(paste('<h2>',as.character(def_indice('./',langue=input$selected_language)[did1,3]),'</h2>',' '))
      # HTML(i19n()$t("Si vous avez fini d'analyser les figures<br/> <br/>Vous pouvez analyser la saison pluvieuse et developper les calendriers culturaux en appuyant sur \"SPCC\""))
    }
  })
  
  # Saison pluvieuse et calendrier de cultures
  observeEvent(input$spcc, {
    global$refresh <- TRUE
    if(global$refresh) {
      removeUI(selector = '#instrucciones')
      removeUI(selector='#mytext')
      removeUI(selector='#mytext2')
      removeUI(selector='#inqc_out')
      removeUI(selector='#mytext4')
      removeUI(selector='#mytext1')
      removeUI(selector='#mytext3')
      removeUI(selector='#myTable')
      removeUI(selector='#mytable1')
      removeUI(selector='#mytable2')
      removeUI(selector='#mytable3')
      removeUI(selector='#mytable4')
      removeUI(selector='#mytext5')
      removeUI(selector='#mytext11')
      removeUI(selector='#mytext14')
      removeUI(selector='#mytext6')
      removeUI(selector='#mytext15')
      removeUI(selector='#mytext12')
      removeUI(selector='#myplot')
      removeUI(selector='#myplot1')
      removeUI(selector='#mytext16')
      removeUI(selector='#mytext17')
      removeUI(selector='#mytext18')
      removeUI(selector='#portada')
      removeUI(selector = '#mycarte')
      removeUI(
        selector = 'div:has(>> #var)'
      )
      removeUI(
        selector ='div:has(>> #nom)'
      )
      removeUI(
        selector = 'div:has(>> #res)'
      )
      removeUI(
        selector = 'div:has(>> #entete1)'
      )
      removeUI(
        selector = 'div:has(>> #anar)'
      )
      removeUI(
        selector = 'div:has(>> #index)'
      )
    }
    global$refresh <- FALSE
    
  })
  
  observe({
    if(!is.null(req(input$spcc))){
      rstudioapi::jobRunScript(path = paste0(chemin,'/app_',input$selected_language,'.R'))
    }
  })
  
  output$mytext10<-renderUI({
    if(!is.null(req(input$spcc))){
      HTML(i19n()$t("Veuillez verifier que le SPCC est active dans un de votre navigateur.<br/> <br/>Si vous voulez revenir sur la page d'acceuil, appuyer sur \"Recharger la session\"<br/><br/>Si Vous voulez le stopper, il faut fermer la fenetre et arreter la session dans \"jobs\""))
    }
  })
  
  observe({
    if(!is.null(req(input$refresh1))){
      session$reload()
    }
  })
 })

shinyApp(ui, server)

# shinyApp(ui, server,options=c(launch.browser = .rs.invokeShinyPaneViewer))
